#!/bin/sh
qdel $@
