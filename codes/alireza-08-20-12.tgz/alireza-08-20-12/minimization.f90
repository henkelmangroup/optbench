!*****************************************************************************************
subroutine minimize(iproc,atoms,paropt)
    use mod_atoms, only: typ_atoms
    use mod_opt, only: typ_paropt
    use energyandforces, only: calenergyforces !,calpseudohess
    implicit none
    integer, intent(in):: iproc !, n, nr
    !real(8), intent(inout):: x(n), f(n), epot
    type(typ_atoms), intent(inout):: atoms
    type(typ_paropt), intent(inout):: paropt
    !local variables
    integer:: n, nr, istat, m, nwork, iat, info, i
    integer, allocatable:: ipiv(:)
    real(8), allocatable:: diag(:), work(:), xr(:), fr(:)
    real(8):: drift(3)
    character(10):: fnmd
    character(50):: comment
    paropt%converged=.false.
    n=3*atoms%nat
    nr=atoms%ndof
    if(paropt%lprint) write(*,'(a,a,1x,i3)') 'begin of minimization using ',trim(paropt%approach),iproc
    if(paropt%approach=='unknown') then
        if(iproc==0) write(*,*) 'The minimize routine returns becuase method is not specified.'
        return
    endif
    allocate(xr(nr),fr(nr))
    !if(paropt%lprint) call report_param(paropt)
    paropt%iflag=0
    !-------------------------------------------------------------------------------------
    if(trim(paropt%approach)=='sd') then
        nwork=2*nr
        allocate(work(nwork),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating diag.'
        do
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            call sdminimum(iproc,nr,xr,fr,atoms%epot,paropt,nwork,work)
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0) exit
        enddo
        deallocate(work,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating work.'
    endif
    !-------------------------------------------------------------------------------------
    if(trim(paropt%approach)=='sdcg') then
        nwork=2*nr+nr
        allocate(work(nwork),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating diag.'
        if(paropt%nfail<0) paropt%nfail=5
        paropt%ifail=0
        do
        do
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            call sdminimum(iproc,nr,xr,fr,atoms%epot,paropt,nwork,work)
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0 .or. paropt%sdsaturated) exit
        enddo
        do 
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            !write(24,*) paropt%fmax
            call cgminimum(iproc,n,nr,xr,fr,atoms%epot,paropt,nwork,work)
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0) exit
        enddo
        if(paropt%converged) exit
        paropt%ifail=paropt%ifail+1
        if(paropt%ifail>=paropt%nfail) then
            write(*,'(a)') 'WARNING: too many failures of SDCG'
            exit
        endif
        enddo !end of loop over ifail
        deallocate(work,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating work.'
    endif
    !-------------------------------------------------------------------------------------
    if(trim(paropt%approach)=='nlbfgs') then
        m=9
        paropt%DIAGCO=.false.
        allocate(diag(nr),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating diag.'
        allocate(work(nr*(2*m+1)+2*m),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating work.'
        do
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            !call fire(iproc,nr,xr,atoms%epot,fr,work,paropt)
            call nlbfgs(nr,m,xr,atoms%epot,fr,diag,work,paropt)
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0) exit
            !if(paropt%iflag<0 .or. paropt%converged) exit
        enddo
        deallocate(diag,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating diag.'
        deallocate(work,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating work.'
    endif
    !-------------------------------------------------------------------------------------
    if(trim(paropt%approach)=='bfgs') then
        nwork=nr*nr+3*nr+3*nr*nr+3*nr
        allocate(work(nwork),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating work.'
        do
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            call mybfgs(iproc,nr,xr,atoms%epot,fr,nwork,work,paropt)
            !if(iproc==0) write(*,*) 'TESET ',paropt%iflag,paropt%converged
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0) exit
            !if(paropt%iflag<0 .or. paropt%converged) exit
        enddo
        deallocate(work,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating work.'
    endif
    !-------------------------------------------------------------------------------------
    if(trim(paropt%approach)=='fire') then
        allocate(work(3*nr),stat=istat)
        if(istat/=0) stop 'ERROR: failure allocating work.'
        do
            call calenergyforces(iproc,n,atoms%rat,atoms%fat,atoms%epot)
            call x_to_xr(n,atoms%rat,atoms%fat,atoms%bemoved,nr,xr,fr)
            call test_convergence(nr,fr,paropt)
            call fire(iproc,nr,xr,atoms%epot,fr,work,paropt)
            call xr_to_x(nr,xr,n,atoms%bemoved,atoms%rat)
            if(paropt%iflag<=0) exit
            !if(paropt%iflag<0 .or. paropt%converged) exit
        enddo
        deallocate(work,stat=istat);if(istat/=0) stop 'ERROR: failure deallocating work.'
    endif
    !-------------------------------------------------------------------------------------
    deallocate(xr)
    if(paropt%lprint) write(*,'(a,a,1x,i3)') 'end of minimization using ',trim(paropt%approach),iproc
end subroutine minimize
!*****************************************************************************************
subroutine test_convergence(n,f,paropt)
    use mod_opt, only: typ_paropt
    implicit none
    integer, intent(in):: n
    real(8), intent(in):: f(n)
    type(typ_paropt), intent(inout):: paropt
    !local variables
    !real(8):: fmax
    call calmaxforcecomponent(n,f,paropt%fmax)
    if(paropt%fmax<paropt%fmaxtol) then
        paropt%converged=.true.
    else
        paropt%converged=.false.
    endif
end subroutine test_convergence
!*****************************************************************************************
subroutine x_to_xr(n,x,f,bemoved,nr,xr,fr)
    !use mod_atoms, only: 
    implicit none
    integer, intent(in):: n, nr
    real(8), intent(in):: x(n), f(n)
    logical, intent(in):: bemoved(3,n/3)
    real(8), intent(inout):: xr(nr), fr(nr)
    !local variables
    integer:: i, j, ixyz, iat
    j=0
    do i=1,n
        iat=(i-1)/3+1
        ixyz=mod(i-1,3)+1
        if(bemoved(ixyz,iat)) then
            j=j+1
            if(j>nr) stop 'ERROR: j>nr in subroutine x_to_xr'
            xr(j)=x(i)
            fr(j)=f(i)
        endif
    enddo
end subroutine x_to_xr
!*****************************************************************************************
subroutine xr_to_x(nr,xr,n,bemoved,x)
    !use mod_atoms, only: 
    implicit none
    integer, intent(in):: n, nr
    real(8), intent(in):: xr(nr)
    logical, intent(in):: bemoved(3,n/3)
    real(8), intent(inout):: x(n)
    !local variables
    integer:: i, j, ixyz, iat
    j=0
    do i=1,n
        iat=(i-1)/3+1
        ixyz=mod(i-1,3)+1
        if(bemoved(ixyz,iat)) then
            j=j+1
            if(j>nr) stop 'ERROR: j>nr in subroutine xr_to_x'
            x(i)=xr(j)
        endif
    enddo
end subroutine xr_to_x
!*****************************************************************************************
subroutine report_param(paropt)
    use mod_opt, only: typ_paropt
    implicit none
    type(typ_paropt), intent(inout):: paropt
    !local variables
    write(*,'(a,2x,a)'  ) 'optimization parameters:       method ',trim(paropt%approach)
    write(*,'(a,2x,a)'  ) 'optimization parameters:   precaution ',trim(paropt%precaution)
    write(*,'(a,es10.2)') 'optimization parameters:       alphax ',paropt%alphax
    write(*,'(a,es10.2)') 'optimization parameters:      fmaxtol ',paropt%fmaxtol
    write(*,'(a,es10.2)') 'optimization parameters:        dxmax ',paropt%dxmax
    write(*,'(a,es10.2)') 'optimization parameters:      condnum ',paropt%condnum
    write(*,'(a,es10.2)') 'optimization parameters: fnrmtolsatur ',paropt%fnrmtolsatur
    write(*,'(a,es10.2)') 'optimization parameters:     dt_start ',paropt%dt_start
    write(*,'(a,1x,i3)' ) 'optimization parameters:       nsatur ',paropt%nsatur
    write(*,'(a,1x,i5)' ) 'optimization parameters:          nit ',paropt%nit
    write(*,'(a,1x,l)'  ) 'optimization parameters:       lprint ',paropt%lprint
    paropt%param_reported=.true.
end subroutine report_param
!*****************************************************************************************
