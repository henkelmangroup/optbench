!*****************************************************************************************
subroutine calnorm(n,v,vnrm)
    implicit none
    integer, intent(in):: n
    real(8), intent(in):: v(n)
    real(8), intent(out):: vnrm
    !local variables
    integer:: i
    vnrm=0.d0
    do i=1,n
        vnrm=vnrm+v(i)**2
    enddo
    vnrm=sqrt(vnrm)
end subroutine calnorm
!*****************************************************************************************
subroutine calmaxforcecomponent(n,v,vmax)
    implicit none
    integer, intent(in):: n
    real(8), intent(in):: v(n)
    real(8), intent(out):: vmax
    !local variables
    integer:: i
    vmax=0.d0
    do i=1,n
        vmax=max(vmax,abs(v(i)))
    enddo
end subroutine calmaxforcecomponent
!*****************************************************************************************
