!*****************************************************************************************
program geopt
    use mod_interface
    use mod_opt, only: typ_paropt
    use mod_atoms, only: typ_atoms
    use energyandforces, only: init_energyandforces, count_ef, calenergyforces
    implicit none
    integer:: iat, iproc, nproc, ierr, nat_t
    real(8):: epotold, DNRM2, fnrm, count_initial, time1, time2
    type(typ_paropt):: paropt, paropt_prec
    type(typ_atoms):: atoms
    character(56):: comment
    character(256):: comment1, comment2
    logical:: two_level_geopt=.true.
    iproc=0 ; nproc=1
    call readxyznat('posinp.xyz',atoms%nat)
    !call allocateatomsarrays(nproc)
    call atom_allocate(atoms,sat=.true.,rat=.true.,fat=.true.,bemoved=.true.)
    call readxyz('posinp.xyz',atoms%nat,atoms%rat,atoms%sat,comment1,comment2,atoms%bemoved)
    call set_ndof(atoms)
    !atoms%bemoved(1:3,1:nat)=.true.
    read(comment1,*) nat_t !,unitsfnposinp
    !write(*,*) comment2
    !stop
    read(comment2,*) atoms%boundcond,atoms%cellvec(1,1),atoms%cellvec(2,2),atoms%cellvec(3,3),atoms%cellvec(1,2),atoms%cellvec(1,3),atoms%cellvec(2,3)
    atoms%cellvec(2,1)=0.d0 ; atoms%cellvec(3,1)=0.d0 ; atoms%cellvec(3,2)=0.d0
    paropt%eps=1.d-8
    call init_energyandforces
    call cpu_time(time1)
    call read_input('input.paropt',paropt)
    paropt%funits=5.d0
    paropt%lprint=.true.
    if(two_level_geopt) then
        paropt_prec%lprint=.true.
        paropt_prec%sdsaturation='yes'
        paropt_prec%funits=6.d0
        call read_input('input.paropt_prec',paropt_prec)
    endif
    count_initial=count_ef
    if(two_level_geopt) then
        call minimize(iproc,atoms,paropt_prec)
    endif
    call minimize(iproc,atoms,paropt)
    fnrm=DNRM2(3*atoms%nat,atoms%fat,1)
    write(comment,'(a13,es24.15,a8,es11.3)') ' angstroemd0 ',atoms%epot,'  fnrm= ',fnrm
    if(iproc==0) then
        call writexyz('final_posout.xyz','new',atoms%nat,atoms%rat,atoms%bemoved,atoms%sat,& 
            atoms%cellvec,atoms%boundcond,comment)
    endif
    call cpu_time(time2)
    if(iproc==0) then
        write(*,'(a,l,i7,es10.3)') 'converged ',paropt%converged,int(count_ef-count_initial),time2-time1
    endif
    call atom_deallocate(atoms,sat=.true.,rat=.true.,fat=.true.,bemoved=.true.)
end program geopt
!*****************************************************************************************
subroutine read_input(filename,paropt)
    use mod_opt, only: typ_paropt
    implicit none
    character(*):: filename
    type(typ_paropt), intent(inout):: paropt
    !local variables
    integer:: ioserr
    open(unit=1, file=trim(filename),status='old',iostat=ioserr)
    if(ioserr/=0) then;write(*,'(2a)') 'ERROR: failure openning ',trim(filename);stop;endif
    read(1,*) paropt%approach
    read(1,*) paropt%alphax
    read(1,*) paropt%fmaxtol
    read(1,*) paropt%condnum
    read(1,*) paropt%precaution
    read(1,*) paropt%nit
    read(1,*) paropt%dt_start
    read(1,*) paropt%dxmax
    read(1,*) paropt%nsatur
    close(1)
end subroutine read_input
!*****************************************************************************************
