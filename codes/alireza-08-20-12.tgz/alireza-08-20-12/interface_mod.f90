!***************************************************************************************************
module mod_interface
    implicit none
interface
subroutine atom_allocate(atoms,sat,rat,vat,amass,fat,bemoved,qat)
    use mod_atoms, only: typ_atoms
    implicit none
    type(typ_atoms), intent(inout):: atoms
    logical, optional, intent(in):: sat, rat, vat, amass, fat, bemoved, qat
end subroutine atom_allocate
subroutine atom_deallocate(atoms,sat,rat,vat,amass,fat,bemoved,qat)
    use mod_atoms, only: typ_atoms
    implicit none
    type(typ_atoms), intent(inout):: atoms
    logical, optional, intent(in):: sat, rat, vat, amass, fat, bemoved, qat
end subroutine atom_deallocate
subroutine writexyz(filename,fn_position,nat,rat,bemoved,sat,cellvec,boundcond,comment)
    implicit none
    integer, intent(in):: nat
    real(8), intent(in):: rat(3,nat)
    logical, intent(in):: bemoved(3,nat)
    character(5), intent(in):: sat(nat)
    real(8), intent(in):: cellvec(3,3)
    character(*), intent(in):: filename, fn_position, boundcond, comment
end subroutine writexyz
subroutine readxyz(filename,nat,rat,sat,comment1,comment2,atom_motion)
    implicit none
    integer:: nat
    real(8):: rat(3,nat)
    character(5):: sat(nat)
    character(*):: filename, comment1, comment2
    logical:: atom_motion(3,nat)
end subroutine readxyz
subroutine sdminimum(iproc,nr,x,f,epot,paropt,nwork,work)
    use mod_opt, only: typ_paropt
    implicit none
    integer, intent(in):: iproc, nr, nwork
    real(8), intent(inout):: x(nr), f(nr), work(nwork)
    real(8), intent(in):: epot
    type(typ_paropt), intent(inout):: paropt
end subroutine sdminimum
subroutine cgminimum(iproc,n,nr,x,f,epot,paropt,nwork,work)
    use mod_opt, only: typ_paropt
    !use energyandforces
    implicit none
    type(typ_paropt):: paropt
    integer:: iproc, n, nr, nwork
    real(8):: x(n), f(n), epot, work(nwork)
end subroutine cgminimum
subroutine fire(iproc,n,x,epot,f,work,paropt)
    use mod_opt, only: typ_paropt
    implicit none
    integer, intent(in):: n, iproc
    real(8), intent(inout):: x(n), epot, f(n)
    real(8), intent(inout):: work(3*n)
    type(typ_paropt), intent(inout):: paropt
end subroutine fire
subroutine mybfgs(iproc,nr,x,epot,f,nwork,work,paropt)
    use mod_opt, only: typ_paropt
    implicit none
    integer:: iproc, nr, nwork
    real(8):: x(nr), f(nr), epot, work(nwork)
    integer, allocatable:: ipiv(:)
    !real(8), allocatable::eval(:),umat(:)
    type(typ_paropt):: paropt
end subroutine mybfgs
end interface
    !+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
end module mod_interface
!***************************************************************************************************
