!*****************************************************************************************
subroutine mybfgs(iproc,nr,x,epot,f,nwork,work,paropt)
    use mod_opt, only: typ_paropt
    implicit none
    integer:: iproc, nr, nwork
    real(8):: x(nr), f(nr), epot, work(nwork)
    integer, allocatable:: ipiv(:)
    !real(8), allocatable::eval(:),umat(:)
    type(typ_paropt):: paropt
    !local variables
    real(8):: DDOT, de, fnrm, fmax, beta, fnrmsatur
    real(8):: tt1, tt2, tt3, tt4, tt5, tt6
    !real(8), save:: epotold !, alpha !, alphamax !, zeta !, evalmin !, evalmax !, fnrmitm1
    !logical, save:: reset_hess
    !integer, save:: isatur
    !integer, save:: ifnrminc
    character(14):: filename
    character(56):: comment
    real(8):: prefactor
    integer:: mf, my, ms, nrsqtwo, iw1, iw2, iw3, iw4, info, i, j, l, mx, increment
    if(nwork/=nr*nr+3*nr+3*nr*nr+3*nr) then
        stop 'ERROR: size of work array is insufficient.'
    endif
    nrsqtwo=nr*nr*2
    mf=nr*nr+1       !for force of previous iteration in wiki notation
    my=mf+nr         !for y_k in wiki notation
    ms=my+nr         !for s_k in wiki notation
    iw1=ms+nr        !work array to keep the hessian untouched
    iw2=iw1+nr*nr    !for work array of DSYTRF
    iw3=iw2+nrsqtwo  !for p_k in wiki notation
    mx =iw3+nr       !for position of previous iteration
    iw4=mx+nr        !for eigenvalues of inverse og hessian
    call calnorm(nr,f,fnrm)
    !call calmaxforcecomponent(nr,f,fmax)
    fmax=paropt%fmax
    if(paropt%iflag==0) then
        paropt%iflag=1
        paropt%iter=0
        paropt%epotold=epot
        paropt%alpha=8.d-1
        paropt%reset_hess=.false.
        paropt%alphamax=0.95d0
        paropt%zeta=min(1.d-1/(paropt%alphax*fmax),1.d0)
        if(paropt%zeta<1.d-3) stop 'ERROR: input configuration does not seem fine.'
        paropt%isatur=0
        paropt%evalmin=paropt%alphax ; paropt%evalmax=1.d1*paropt%alphax !just to avoid problem
        paropt%fnrmitm1=1.d50
        paropt%ifnrminc=0
        if(paropt%funits<0.d0) paropt%funits=1.d0
        if(paropt%nit<0) paropt%nit=1000
    else
        paropt%iter=paropt%iter+1
    endif
    if(trim(paropt%precaution)=='high') then
        prefactor=10.d-2
        increment=1
    elseif(trim(paropt%precaution)=='normal') then
        prefactor=12.d-2
        increment=2
    elseif(trim(paropt%precaution)=='low') then
        prefactor=14.d-2
        increment=3
    else
        stop 'ERROR: precaution from typ_paropt is not set'
    endif
    !df1=fnrm-paropt%fnrmitm1
    !if(df1<0.d0) then
    if(fnrm<1.05d0*paropt%fnrmitm1) then
        paropt%ifnrminc=0
    else
        paropt%ifnrminc=paropt%ifnrminc+1
    endif
    fnrmsatur=paropt%funits*prefactor*min(50.d0,max(2.5d0,sqrt(real(nr,8))))
    !fnrmsatur=min(4.d-2,max(2.d-3,8.d-4*sqrt(real(nr,8)))) !I am not sure
    !fnrmsatur=min(30.d0,max(1.5d0,6.d-1*sqrt(real(nr,8)))) !LJ38
    if(paropt%iter>5 .and. fnrm<fnrmsatur) then
        if(paropt%ifnrminc==0) then
            paropt%isatur=min(paropt%isatur+increment,99)
        endif
    else
        paropt%isatur=0
    endif
    de=epot-paropt%epotold
    !if(iproc==0) write(*,'(a10,i4,es23.15,es11.3,2es12.5,2es12.4,i3)') &
    !    'BFGSMIN   ',paropt%iter,epot,de,fnrm,fmax,paropt%zeta,paropt%alpha,paropt%isatur
    !if(paropt%lprint) write(*,'(a4,i3.3,1x,i5,es23.12,es11.3,2es12.5,2es12.4,i3,a)') &
    if(paropt%lprint) write(*,'(a4,i3.3,1x,i5,es23.15,es11.3,2es12.5,2es12.4,i3,a)') &
        'MIN:',iproc,paropt%iter,epot,de,fnrm,fmax,paropt%zeta,paropt%alpha,paropt%isatur,' BFGS'
    !write(74,'(i5)') nr/3
    !do i=1,nr,3
    !    write(74,'(3es23.13)') x(i),x(i+1),x(i+2)
    !enddo
    !stop

    !write(filename,'(a6,i4.4,a4)') 'posout',paropt%iter,'.xyz'
    !write(comment,'(a13,es24.15,a8,es11.3)') ' angstroemd0 ',epot,'  fnrm= ',fnrm
    !if(iproc==0) call writexyz(filename,'new',nr/3,x,comment)
    !if(paropt%iter==602) then
    !    do i=1,nr/3
    !        write(31,*) x(i*3-2),x(i*3-1),x(i*3-0)
    !    enddo
    !    stop
    !endif
    !if(fmax<paropt%fmaxtol) then
    if(paropt%converged) then
        paropt%iflag=0
        !if(paropt%lprint) write(*,'(a,i4,es23.12,2es12.5)') &
        if(paropt%lprint) write(*,'(a,i4,es23.15,2es12.5)') &
            'BFGS FINISHED: itbfgs,epot,fnrm,fmax ',paropt%iter,epot,fnrm,fmax
        return
    endif
    if(paropt%iter==paropt%nit) then
        paropt%iflag=0
        write(*,'(a)') 'BFGS: NO CONVERGENCE '
        return
    endif

    !if(de>0.d0 .and. paropt%zeta>1.d-1) then
    if(de>2.d-3) then
    !if(de>4.d-4) then
        epot=paropt%epotold
        x(1:nr)=work(mx:mx-1+nr)
        f(1:nr)=work(mf:mf-1+nr)
        paropt%reset_hess=.true.
        !paropt%alpha=max(paropt%alpha*0.5d0/1.1d0,1.d-2)
        paropt%zeta=max(paropt%zeta*2.d-1,1.d-3)
        paropt%isatur=0
    else
        !paropt%zeta=1.d0
        !if(paropt%zeta>1.d-1) paropt%zeta=min(paropt%zeta*1.1d0,1.d0)
        paropt%zeta=min(paropt%zeta*1.1d0,1.d0)
        !paropt%isatur=paropt%isatur+1
        paropt%fnrmitm1=fnrm
    endif
    if(paropt%iter>0) then
        work(ms:ms-1+nr)=x(1:nr)-work(mx:mx-1+nr)
        work(my:my-1+nr)=work(mf:mf-1+nr)-f(1:nr)
        !tt1=DDOT(nr,work(my),1,work(ms),1)
        tt1=DDOT(nr,work(mf),1,work(ms),1)
    else
        tt1=1.d0 !just some positive value
    endif
    if(paropt%iter==0 .or. paropt%reset_hess .or. tt1<0.d0 .or. paropt%ifnrminc>3) then
        paropt%reset_hess=.false.
        paropt%ifnrminc=0
        paropt%isatur=0
        !if(paropt%isatur>=10) then
        !    paropt%reset_hess=.false.
        !    !paropt%alpha=5.d-1
        !endif
        work(1:nr*nr)=0.d0
        do i=1,nr
            work(i+(i-1)*nr)=paropt%zeta*paropt%alphax
        enddo
        work(iw3:iw3-1+nr)=paropt%zeta*paropt%alphax*f(1:nr)
    else
        do i=1,nr
            tt2=0.d0
            do j=1,nr
                tt2=tt2+work(i+(j-1)*nr)*work(my-1+j)
            enddo
            work(iw2-1+i)=tt2
        enddo
        tt2=DDOT(nr,work(my),1,work(iw2),1)
        if(paropt%lprint) write(21,*) paropt%iter,tt1,tt2
        !tt1=max(tt1,1.d-2)
        do i=1,nr
            do j=i,nr
                l=i+(j-1)*nr
                work(l)=work(l)+(tt1+tt2)*work(ms-1+i)*work(ms-1+j)/tt1**2- &
                    (work(iw2-1+i)*work(ms-1+j)+work(iw2-1+j)*work(ms-1+i))/tt1
                work(j+(i-1)*nr)=work(l)
            enddo
        enddo
        !do i=1,nr
        !    tt2=0.d0
        !    do j=1,nr
        !        tt2=tt2+work(j+(i-1)*nr)*f(j)
        !    enddo
        !    work(iw3-1+i)=tt2
        !enddo
        !write(31,*) paropt%zeta
        work(iw1:iw1-1+nr*nr)=work(1:nr*nr)
        call DSYEV('V','L',nr,work(iw1),nr,work(iw4),work(iw2),nrsqtwo,info)
        if(info/=0) stop 'DSYEV'
        tt1=work(iw4+0)    ; tt2=work(iw4+1)    ; tt3=work(iw4+2)
        tt4=work(iw4+nr-3) ; tt5=work(iw4+nr-2) ; tt6=work(iw4+nr-1)
        if(paropt%lprint) write(41,'(i5,6es15.5)') paropt%iter,tt1,tt2,tt3,tt4,tt5,tt6
        paropt%evalmin=tt1 ; paropt%evalmax=tt6
        work(iw3:iw3-1+nr)=0.d0
        beta=1.d0+paropt%condnum*min((paropt%isatur/6)/15.d0,1.d0)
        beta=1.d0/(beta*paropt%alphax)
        !do j=1,nr
        !    if(work(iw4-1+j)>0.d0) then
        !        tt3=work(iw4-1+j)
        !        exit
        !    enddo
        !enddo
        tt3=paropt%alphax*0.5d0
        do j=1,nr
            tt1=DDOT(nr,work(iw1+nr*(j-1)),1,f,1)
            if(work(iw4-1+j)<tt3) then
                tt4=tt3
            else
                tt4=work(iw4-1+j)
            endif
            tt2=1.d0/sqrt(1.d0/tt4**2+beta**2)
            do i=1,nr
                work(iw3-1+i)=work(iw3-1+i)+tt1*work(iw1-1+i+nr*(j-1))*tt2
            enddo
        enddo
    endif !provided paropt%iter==0 .or. paropt%reset_hess .or. tt1<0.d0
    if(paropt%evalmin<0.d0 .and. abs(paropt%evalmin)>paropt%alphax*1.d-1) then
        paropt%reset_hess=.true.
        epot=paropt%epotold
        x(1:nr)=work(mx:mx-1+nr)
        f(1:nr)=work(mf:mf-1+nr)
        work(iw3:iw3-1+nr)=0.d0
        paropt%isatur=0
        paropt%evalmin=paropt%alphax ; paropt%evalmax=1.d1*paropt%alphax !just to avoid problem
    endif
    paropt%epotold=epot
    work(mf:mf-1+nr)=f(1:nr)
    work(mx:mx-1+nr)=x(1:nr)
    !if(fnrm<1.d0) then
    !    paropt%isatur=paropt%isatur+1
    !else
    !    paropt%isatur=0
    !endif
    paropt%alpha=min(paropt%alphamax,paropt%alpha*1.1d0)
    x(1:nr)=x(1:nr)+paropt%alpha*work(iw3:iw3-1+nr)
end subroutine mybfgs
!*****************************************************************************************
