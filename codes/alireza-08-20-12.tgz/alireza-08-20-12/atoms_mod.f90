!*****************************************************************************************
module mod_atoms
    implicit none
    type typ_atoms
        integer:: nat=-1 !number of atoms
        integer:: ndof=-1 !number of degrees of freedom
        real(8):: cellvec(3,3)=-1.d0 !cell vectors
        real(8):: epot=0.d0 !potential energy
        real(8):: ekin=0.d0 !kinetic energy
        real(8):: etot=0.d0 !total energy
        character(20):: boundcond='unknown'
        character(5), allocatable:: sat(:) !symbol of atoms
        real(8), allocatable:: rat(:,:) !atomic positions
        real(8), allocatable:: vat(:,:) !atomic velocities
        real(8), allocatable:: amass(:) !atomic mass
        real(8), allocatable:: fat(:,:) !atomic forces
        logical, allocatable:: bemoved(:,:) !status to be moved or not
        real(8), allocatable:: qat(:) !atomic charges
    end type typ_atoms
end module mod_atoms
!*****************************************************************************************
subroutine set_ndof(atoms)
    use mod_atoms, only: typ_atoms
    implicit none
    type(typ_atoms), intent(inout):: atoms
    !local variables
    integer:: iat
    atoms%ndof=0
    do iat=1,atoms%nat
        if(atoms%bemoved(1,iat)) atoms%ndof=atoms%ndof+1
        if(atoms%bemoved(2,iat)) atoms%ndof=atoms%ndof+1
        if(atoms%bemoved(3,iat)) atoms%ndof=atoms%ndof+1
    enddo
end subroutine set_ndof
!*****************************************************************************************
subroutine bemoved2string(bemoved,str_motion)
    implicit none
    logical:: bemoved(3)
    character(3):: str_motion
    if(bemoved(1)) then
        str_motion='T'
    else
        str_motion='F'
    endif
    if(bemoved(2)) then
        str_motion=trim(str_motion)//'T'
    else
        str_motion=trim(str_motion)//'F'
    endif
    if(bemoved(3)) then
        str_motion=trim(str_motion)//'T'
    else
        str_motion=trim(str_motion)//'F'
    endif
end subroutine bemoved2string
!*****************************************************************************************
subroutine string2bemoved(str_motion,bemoved)
    implicit none
    character(3):: str_motion
    logical:: bemoved(3)
    if(str_motion(1:1)=='T') then
        bemoved(1)=.true.
    elseif(str_motion(1:1)=='F') then
        bemoved(1)=.false.
    else
        stop 'ERROR: incorrect symbol for atomic motion'
    endif
    if(str_motion(2:2)=='T') then
        bemoved(2)=.true.
    elseif(str_motion(2:2)=='F') then
        bemoved(2)=.false.
    else
        stop 'ERROR: incorrect symbol for atomic motion'
    endif
    if(str_motion(3:3)=='T') then
        bemoved(3)=.true.
    elseif(str_motion(3:3)=='F') then
        bemoved(3)=.false.
    else
        stop 'ERROR: incorrect symbol for atomic motion'
    endif
end subroutine string2bemoved
!*****************************************************************************************
subroutine atom_allocate(atoms,sat,rat,vat,amass,fat,bemoved,qat)
    use mod_atoms, only: typ_atoms
    implicit none
    type(typ_atoms), intent(inout):: atoms
    logical, optional, intent(in):: sat, rat, vat, amass, fat, bemoved, qat
    !local variables
    integer:: iat
    if(atoms%nat<1) stop 'ERROR: atoms%nat must be larger than zero'
    !if(.not. present(sat)) sat=.false.
    !if(.not. present(rat)) rat=.false.
    !if(.not. present(vat)) vat=.false.
    !if(.not. present(amass)) amass=.false.
    !if(.not. present(fat)) fat=.false.
    !if(.not. present(bemoved)) bemoved=.false.
    !if(.not. present(qat)) qat=.false.
    if(present(sat) .and. sat) then
        if(allocated(atoms%sat)) stop 'ERROR: sat is already allocated'
        allocate(atoms%sat(atoms%nat))
        do iat=1,atoms%nat
            atoms%sat(iat)=''
        enddo
    endif
    if(present(rat) .and. rat) then
        if(allocated(atoms%rat)) stop 'ERROR: rat is already allocated'
        allocate(atoms%rat(3,atoms%nat))
        do iat=1,atoms%nat
            atoms%rat(1,iat)=0.d0
            atoms%rat(2,iat)=0.d0
            atoms%rat(3,iat)=0.d0
        enddo
    endif
    if(present(vat) .and. vat) then
        if(allocated(atoms%vat)) stop 'ERROR: vat is already allocated'
        allocate(atoms%vat(3,atoms%nat))
        do iat=1,atoms%nat
            atoms%vat(1,iat)=0.d0
            atoms%vat(2,iat)=0.d0
            atoms%vat(3,iat)=0.d0
        enddo
    endif
    if(present(amass) .and. amass) then
        if(allocated(atoms%amass)) stop 'ERROR: amass is already allocated'
        allocate(atoms%amass(atoms%nat))
        do iat=1,atoms%nat
            atoms%amass(iat)=0.d0
        enddo
    endif
    if(present(fat) .and. fat) then
        if(allocated(atoms%fat)) stop 'ERROR: fat is already allocated'
        allocate(atoms%fat(3,atoms%nat))
        do iat=1,atoms%nat
            atoms%fat(1,iat)=0.d0
            atoms%fat(2,iat)=0.d0
            atoms%fat(3,iat)=0.d0
        enddo
    endif
    if(present(bemoved) .and. bemoved) then
        if(allocated(atoms%bemoved)) stop 'ERROR: bemoved is already allocated'
        allocate(atoms%bemoved(3,atoms%nat))
        do iat=1,atoms%nat
            atoms%bemoved(1,iat)=.false.
            atoms%bemoved(2,iat)=.false.
            atoms%bemoved(3,iat)=.false.
        enddo
    endif
    if(present(qat) .and. qat) then
        if(allocated(atoms%qat)) stop 'ERROR: qat is already allocated'
        allocate(atoms%qat(atoms%nat))
        do iat=1,atoms%nat
            atoms%qat(iat)=0.d0
        enddo
    endif
end subroutine atom_allocate
!*****************************************************************************************
subroutine atom_deallocate(atoms,sat,rat,vat,amass,fat,bemoved,qat)
    use mod_atoms, only: typ_atoms
    implicit none
    type(typ_atoms), intent(inout):: atoms
    logical, optional, intent(in):: sat, rat, vat, amass, fat, bemoved, qat
    !local variables
    !integer::
    if(present(sat) .and. sat) then
        if(.not. allocated(atoms%sat)) stop 'ERROR: sat is not allocated'
        deallocate(atoms%sat)
    endif
    if(present(rat) .and. rat) then
        if(.not. allocated(atoms%rat)) stop 'ERROR: rat is not allocated'
        deallocate(atoms%rat)
    endif
    if(present(vat) .and. vat) then
        if(.not. allocated(atoms%vat)) stop 'ERROR: vat is not allocated'
        deallocate(atoms%vat)
    endif
    if(present(amass) .and. amass) then
        if(.not. allocated(atoms%amass)) stop 'ERROR: amass is not allocated'
        deallocate(atoms%amass)
    endif
    if(present(fat) .and. fat) then
        if(.not. allocated(atoms%fat)) stop 'ERROR: fat is not allocated'
        deallocate(atoms%fat)
    endif
    if(present(bemoved) .and. bemoved) then
        if(.not. allocated(atoms%bemoved)) stop 'ERROR: bemoved is not allocated'
        deallocate(atoms%bemoved)
    endif
    if(present(qat) .and. qat) then
        if(.not. allocated(atoms%qat)) stop 'ERROR: qat is not allocated'
        deallocate(atoms%qat)
    endif
end subroutine atom_deallocate
!*****************************************************************************************
