subroutine dmacrys_setup
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_get_natoms(num_atoms_out)
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_initialize_gmin
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

! calculate the potential using dmacrys
subroutine dmacrys_potential(X,GRAD,EREAL,GRADT)
    DOUBLE PRECISION X(*), GRAD(*), EREAL
    LOGICAL GRADT
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_dump_lowest()
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_takestep(np)
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_dump(filename, coords)
    USE COMMONS, ONLY: NATOMS
    DOUBLE PRECISION :: COORDS(3*NATOMS)
    CHARACTER(*) :: filename
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_reduce_cell_rigid(coords,cell_has_chaned)
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_genrandom(coords)
    DOUBLE PRECISION COORDS(*)
    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine

subroutine dmacrys_minimize(n,m,xcoords,diagco,eps,mflag,energy,itmax,itdone,reset, np)
    use commons, only : natoms, dmacryst
    use genrigid

    integer :: n,m,itmax,itdone,np
    double precision :: xcoords(3*natoms), eps,energy
    logical :: diagco, reset,  mflag

    print *,'ERROR: you are using dmacrys with a non-dmacrys binary'
    stop
end subroutine
