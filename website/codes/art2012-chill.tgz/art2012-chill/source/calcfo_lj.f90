SUBROUTINE LJcalcforce(N, R, F, U, BX, BY, BZ, U0, EPS, SIGMA, R_CUTOFF)
  IMPLICIT NONE
  INTEGER N
  REAL(KIND=8) R(3*N)
  REAL(KIND=8) F(3*N)
  REAL(KIND=8) U(1)
  REAL(KIND=8) BX, BY, BZ
  REAL(KIND=8) U0
  REAL(KIND=8) EPS
  REAL(KIND=8) SIGMA
  REAL(KIND=8) R_CUTOFF, RCsq
  REAL(KIND=8) R_IJ_X, R_IJ_Y, R_IJ_Z, R_IJ
  REAL(KIND=8) iRsq, iRs2, iRs6, iRs12
  REAL(KIND=8) UU, DUU,UU_SHIFT
  INTEGER I,J
  RCsq=R_CUTOFF*R_CUTOFF
  iRs2=SIGMA*SIGMA/(RCsq)
  iRs6=iRs2*iRs2*iRs2
  iRs12=iRs6*iRs6
  UU_SHIFT=(iRs12-iRs6)
  U=DBLE(0.0)
  F=DBLE(0.0)
  DO I=1, N-1
    DO J=I+1, N
      R_IJ_X=R(I)-R(J)
      R_IJ_Y=R(N+I)-R(N+J)
      R_IJ_Z=R(2*N+I)-R(2*N+J)

      R_IJ_X=R_IJ_X-BX*DNINT(R_IJ_X/BX)
      R_IJ_Y=R_IJ_Y-BY*DNINT(R_IJ_Y/BY)
      R_IJ_Z=R_IJ_Z-BZ*DNINT(R_IJ_Z/BZ)
      R_IJ=R_IJ_X*R_IJ_X+R_IJ_Y*R_IJ_Y+R_IJ_Z*R_IJ_Z
      IF(R_IJ<=RCsq) THEN
        iRsq=DBLE(1.0)/R_IJ
        iRs2=SIGMA*SIGMA*iRsq
        iRs6=iRs2*iRs2*iRs2
        iRs12=iRs6*iRs6
        UU=(iRs12-iRs6)
        DUU=(DBLE(12.0)*iRs12-DBLE(6.0)*iRs6)*iRsq
        F(I)     =F(I)+DUU*R_IJ_X
        F(N+I)   =F(N+I)+DUU*R_IJ_Y
        F(2*N+I) =F(2*N+I)+DUU*R_IJ_Z
        F(J)     =F(J)-DUU*R_IJ_X
        F(N+J)   =F(N+J)-DUU*R_IJ_Y
        F(2*N+J) =F(2*N+J)-DUU*R_IJ_Z
        U=U+UU-UU_SHIFT
      END IF
    END DO
  END DO

  DO I=1, 3*N
    F(I)=F(I)*U0
  END DO

  U=U*U0
END SUBROUTINE LJcalcforce
