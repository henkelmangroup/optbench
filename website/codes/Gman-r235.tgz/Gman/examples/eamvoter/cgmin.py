#!/usr/bin/env python

from Gman import *

p=data.point()
io.loadcon(p,'al.con')
force=pot.set('eamvoter',p)
opt.cgmin(p,force,itrmax=1000)
