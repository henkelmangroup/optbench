#!/usr/bin/env python

from Gman import *
import Gman.cdyn as Gcdyn
import Gman.opt as Gopt
import Gman.min as Gmin

p=data.point()
io.loadcon(p,'ice96.con')
force=pot.set('bjx')

opt=Gopt.qm()
opt.init()
#opt.init(maxmove=1.0)
min=Gmin.min()
#min.minimize(p,system,opt.step,itrmax=100,fmax=1E-8)

min.minimize(p,force,Gcdyn,fmax=1e-4)
