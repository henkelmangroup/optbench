#!/bin/bash

# Run test suite

echo "********  AL  ********"
cd al
min.py
neb.py
cd ..

echo "******** LEPS ********"
cd leps
min.py
cd ..

echo "****** MUELLER *******"
cd mueller
min.py
cd ..

#echo "******* Pt111 *******"
#cd pt111
#str_pt111_test.py
#cd ..

echo "******* Al (voter) *******"
cd eamvoter
pot.py
cd ..
