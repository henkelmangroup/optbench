#!/usr/bin/env python

from   Gman     import  *
import Gman.neb as      Gneb
import Gman.opt as      Gopt
from   Gman.vzr import  *
from   Gman.pot import  *

draw = True
#draw = False

imgnumber = 500

if draw:
    v = Vzr()
    img = potentialBoard('lepspho', -0.1285, -2.0005, 3.8715, 1.9995, 64, 20)

def doDraw():
    v.setCamera(1.8715, -0.0005, 5, 1.8715, -0.0005, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    v.drawBoard(-0.1285, 1.9995, 0, 3.8715, 1.9995, 0, 3.8715, -2.0005, 0, -0.1285, -2.0005, 0, img)
    for i in range(len(neb.p)):
        v.drawSphere(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, 0.05, 1, 1, 1)
    for i in range(len(neb.p) - 1):
        v.drawLine(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, neb.p[i + 1].R[0][0], neb.p[i + 1].R[0][1], 0.01, 1, 1, 1)
    v.update()
    #raw_input()

def doPass():
    pass

p1=data.point()
p2=data.point()
io.loadcon(p1,'lepsmina.con')
io.loadcon(p2,'lepsminb.con')

potential=pot.set('lepspho')

#opt=Gopt.gbfgs()
#opt.init(maxmove=0.000001, alpha=0.08, min="hess",DFP='false')

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.01, memory=25, min="hess")

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="hess")

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.2, min='line', alpha=0.08, memory=25)

opt=Gopt.glbfgs()
opt.init(maxmove=0.2, min='hess', alpha=0.0001, memory=1000)

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.01, min='hess', alpha=0.01, memory=25)

#opt=Gopt.qm()
#opt.init(dt=0.14, maxmove = 0.2)

#opt=Gopt.fire()
#opt.init(maxmove = 0.2, dt = 0.14)

opt=Gopt.sd()
opt.init(stepR=0.05, maxmove=0.2)

#opt=Gopt.cg()
#opt.init(maxmove=0.2, dR=0.0001)

#opt=Gopt.rk4()
#opt.init()

neb=Gneb.neb()
neb.new(p1,p2,images=8)

if not draw:
    neb.relax(potential,opt.step,tangent="new",itrmax=10000,ppd=1,fmax=0.001,fsaddle='off',graphic=doPass,method="ci")
if draw:
    neb.relax(potential,opt.step,tangent="new",k = 5, itrmax=10000,ppd=1,fmax=0.01,fsaddle='on',graphic=doDraw,method="ci")
neb.save(io.savecon,'str.con')

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / neb.ni

while True:
    doDraw()
    
    
