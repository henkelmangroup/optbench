#!/usr/bin/env python

from Gman import *
import Gman.opt as Gopt
import Gman.min as Gmin

p=data.point()
#io.loadcon(p,'lepsminb.con')
io.loadcon(p,'lepssp.con')
force=pot.set('lepspho')
force(p)

opt=Gopt.cg()
opt.init()

min=Gmin.min()
min.minimize(p,force,opt.step,itrmax=1,fmax=1E-12)
#io.savecon(min.p[0],'leps.con')
print min.p[0].R
print min.p[0].F
