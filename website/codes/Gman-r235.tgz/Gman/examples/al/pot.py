#!/usr/bin/env python

from Gman import *

p=data.point()
io.loadcon(p,'al.con')
#force=pot.set('al')
force=pot.set('eamvoter',p)
force(p)
print p.U
print p.F
