#!/usr/bin/env python

from Gman import *
import profile
import Gman.min as Gmin
import Gman.opt as Gopt

p=data.point()
io.loadcon(p,'al1a.con')
system=pot.set('al')
#opt=Gopt.bfgs()
#opt=Gopt.qm()
opt=Gopt.cg()
opt.init()
#opt.init(maxmove=1.0)
min=Gmin.min()
min.minimize(p,system,opt.step,itrmax=100,fmax=1E-8)
#profile.run('min.minimize(p,system,fmax=1e-4)','profile')
io.savecon(min.p[0],'al1a.con')
