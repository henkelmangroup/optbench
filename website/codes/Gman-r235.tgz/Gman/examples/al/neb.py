#!/usr/bin/env python

from Gman import *
import Gman.neb as Gneb
import Gman.opt as Gopt

p1=data.point()
p2=data.point()
io.loadcon(p1,'al1a.con')
io.loadcon(p2,'al1b.con')

potential=pot.set('al')
#opt=Gopt.bfgs()
opt=Gopt.cg()
#opt=Gopt.qm()
#opt=Gopt.lbfgs()
opt.init()
#opt.init(stepR=0.2)
#opt.init(maxmove=0.5,dR=0.01)
neb=Gneb.neb()
neb.new(p1,p2,images=8)
neb.relax(potential,opt.step)
#neb.relax(potential,opt.step,k=5,fmax=0.001,itrmax=1000,tangent='new',method='ci',dneb='off',dneb_org='off',fsaddle='off',ppd=1)
neb.save(io.savecon,'neb.con')


