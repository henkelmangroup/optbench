#!/usr/bin/env python

from Gman import *
import Gman.str as Gstr
import Gman.opt as Gopt

p1=data.point()
p2=data.point()
pot=pot.set('al')


io.loadcon(p1,'al1a.con')
io.loadcon(p2,'al1b.con') 

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2,memory=50)
opt=Gopt.sd()
opt.init(maxmove=0.2,stepR=0.01)
#opt=Gopt.qm()
#opt.init(maxmove=0.2,dt=0.01)
#opt=Gopt.fire()
#opt.init(maxmove=0.2,dt=0.01)

path=Gstr.str()
path.new(p1,p2,images=50)
path.relax(pot,opt.step,itrmax=1000,fmax=0.01,tangent='new',ppd=1,converge='Fmag')
path.save(io.savexyz,'movie.xyz')

