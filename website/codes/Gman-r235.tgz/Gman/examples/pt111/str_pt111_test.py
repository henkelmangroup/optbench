#!/usr/bin/env python

import Gman.str as      Gstr
import Gman.opt as      Gopt
from   Gman     import  *
from   Gman.pot import  *

p1=data.point()
p2=data.point()

mina = ['min01/a.con', 'min02/a.con', 'min03/a.con', 'min04/a.con', 'min05/a.con', 'min06/a.con', 'min07/a.con', 'min08/a.con', 'min09/a.con', 'min10/a.con', 'min11/a.con', 'min12/a.con', 'min13/a.con'] 
minb = ['min01/b.con', 'min02/b.con', 'min03/b.con', 'min04/b.con', 'min05/b.con', 'min06/b.con', 'min07/b.con', 'min08/b.con', 'min09/b.con', 'min10/b.con', 'min11/b.con', 'min12/b.con', 'min13/b.con'] 

potential=pot.set('morse')

for i in range(13):

    #opt=Gopt.lbfgs()
    #opt.init(maxmove=0.2, alpha=0.05, memory=50, min='line')

    #opt = Gopt.lbfgs()
    #opt.init(maxmove = 0.2, alpha = 0.05, memory = 50, min = 'hess')

    #opt=Gopt.glbfgs()
    #opt.init(maxmove=0.2, min='line', alpha=0.05, memory=50)

    opt=Gopt.glbfgs()
    opt.init(maxmove=0.2, min='hess', alpha=0.05, memory=25)

    #opt=Gopt.qm()
    #opt.init(dt=0.01, maxmove = 0.2)

    #opt=Gopt.fire()
    #opt.init(maxmove = 0.2, dt = 0.15)

    #opt=Gopt.sd()
    #opt.init(stepR=0.02, maxmove=0.2)

    #opt=Gopt.cg()
    #opt.init(maxmove=0.2, dR=0.0001)

#    opt=Gopt.rk4()
#    opt.init()

    io.loadcon(p1, mina[i])
    io.loadcon(p2, minb[i])
    str = Gstr.str()
    str.new(p1, p2, images = 8)
    str.relax(potential, opt.step, tangent="new", itrmax = 100000, ppd = 1, fmax = 0.01, fsaddle = 'off', method = "off")

print "............................................................"
print "Force count: ", pot.count()
print "Force count per image average: ", pot.count() / (13.0 * 8.0)
print "............................................................"

