#!/usr/bin/env python

from Gman import *
import Gman.opt as Gopt
import Gman.min as Gmin

p=data.point()
io.loadcon(p,'min.con')
force=pot.set('nfk')
force(p)

print p.R
print p.U
print p.F
