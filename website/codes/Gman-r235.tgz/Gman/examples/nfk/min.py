#!/usr/bin/env python

from Gman import *
import Gman.opt as Gopt
import Gman.min as Gmin

p=data.point()
io.loadcon(p,'minb.con')
force=pot.set('nfk')
force(p)

opt=Gopt.cg()
opt.init()

min=Gmin.min()
min.minimize(p,force,opt.step,itrmax=100,fmax=1E-12)
io.savecon(min.p[0],'min.con')
print min.p[0].R
print min.p[0].F
