#!/usr/bin/env python

from Gman import *
import Gman.opt as Gopt
import Gman.min as Gmin
from Gman.func import vmag, vproj, vdot, vunit

p=data.point()
io.loadcon(p,'saddle.con')
force=pot.set('nfk')
print p.R
p.R+=[[0.001,-0.001]]
force(p)
alpha=0.01

while vmag(p.F)>0.0001:
  p.R+=p.F*alpha
  print p.R
  force(p)
