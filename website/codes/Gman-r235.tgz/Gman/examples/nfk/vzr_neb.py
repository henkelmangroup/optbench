#!/usr/bin/env python

from   Gman     import  *
import Gman.neb as      Gneb
import Gman.opt as      Gopt
from   Gman.vzr import  *
from   Gman.pot import  *

draw = True
#draw = False

imgnumber = 500
if draw:
    v = Vzr()
    img = potentialBoard('nfk', -1, -3.4, 3.4, 1, 64, 1.0)

def doDraw():
    v.setCamera(1.2, -1.2, 5, 1.2, -1.2, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    v.drawBoard(-1, 1, 0, 3.4, 1, 0, 3.4, -3.4, 0, -1, -3.4, 0, img)
    for i in range(len(neb.p)):
        v.drawSphere(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, 0.05, 1, 1, 1)
    for i in range(len(neb.p) - 1):
        v.drawLine(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, neb.p[i + 1].R[0][0], neb.p[i + 1].R[0][1], 0.01, 1, 1, 1)
    v.update()
    #raw_input()

def doPass():
    pass

p1=data.point()
p2=data.point()
#io.loadcon(p1,'mina.con')
#io.loadcon(p2,'saddle.con')
io.loadcon(p1,'pointa.con')
io.loadcon(p2,'minb.con')

potential=pot.set('nfk')

opt=Gopt.qm()
opt.init(dt=0.0125, maxmove = 1.0)

#opt=Gopt.fire()
#opt.init(dt=0.015, maxmove = 0.0125)

#opt=Gopt.cg()
#opt.init(dR=0.0125, maxmove = 0.3)

#opt=Gopt.sd()
#opt.init(stepR=0.0125, maxmove = 1.)

neb=Gneb.neb()
neb.new(p1,p2,images=50)

if not draw:
    neb.relax(potential,opt.step,tangent="new",itrmax=1500,ppd=1,fmax=0.001,fsaddle='off',graphic=doPass,method="ci")
if draw:
    neb.relax(potential,opt.step,tangent="old",k = 0, itrmax=1500,ppd=1,fmax=0.001,fsaddle='off',graphic=doDraw,method="old")
neb.save(io.savecon,'str.con')

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / neb.ni

while True:
    doDraw()
