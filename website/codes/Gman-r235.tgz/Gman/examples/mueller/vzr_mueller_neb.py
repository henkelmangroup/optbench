#!/usr/bin/env python

import  Gman.str            as      Gstr
import  Gman.neb            as      Gneb
import  Gman.opt            as      Gopt
import  profile
from    Gman                import  *
from    Gman.vzr            import  *
from    Gman.pot            import  *
from    Gman.data.Spline2D  import  *


v = Vzr()
img = potentialBoard('mueller', -1.5, -0.5, 1.1, 1.7, 128, 5)


def doDraw():
    v.setCamera(-0.25, 0.5, 4, -0.25, 0.5, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    v.drawBoard(-1.5, 1.7, 0, 1.1, 1.7, 0, 1.1, -0.5, 0, -1.5, -0.5, 0, img)
    for i in range(len(str.p)):
        v.drawSphere(str.p[i].R[0][0], str.p[i].R[0][1], 0.01, 0.02, 1, 1, 1)
    for i in range(len(str.p) - 1):
        v.drawLine(str.p[i].R[0][0], str.p[i].R[0][1], 0.01, str.p[i + 1].R[0][0], str.p[i + 1].R[0][1], 0.01, 1, 1, 1)
    v.update()
    #raw_input()

p1 = data.point()
p2 = data.point()
io.loadcon(p1, 'minb.con')
io.loadcon(p2, 'mina.con')

potential=pot.set('mueller')

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="line")

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="hess")

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.001, min='line', alpha=0.000001, memory=25)

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.01, min='hess', alpha=0.0001, memory=25)

#opt=Gopt.qm()
#opt.init(dt=0.01, maxmove = 0.01)
 
#opt=Gopt.fire()
#opt.init(maxmove = 0.01, dt = 0.01)

#opt = Gopt.sd()
#opt.init(stepR = 0.0005, maxmove = 0.01)

#opt=Gopt.cg()
#opt.init(maxmove=0.01, dR=0.000001)

opt=Gopt.rk4()
opt.init(dt = 0.09)

str = Gneb.neb()
str.new(p1, p2, images = 8)
str.relax(potential, opt.step, k=20.0 , tangent = "new", itrmax = 25000, ppd = 1, fmax = 0.01, fsaddle = "off", graphic = doDraw, method = "ci",dneb = "off")
str.save(io.savecon,'neb.con')

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / str.ni

