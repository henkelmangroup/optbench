#!/usr/bin/env python

from Gman import *
import Gman.opt as Gopt
import Gman.min as Gmin


p=data.point()
io.loadcon(p,'init.con')
force=pot.set('mueller')
#io.savexyz(p,'movie.xyz')

opt=Gopt.cg()
opt.init()
min=Gmin.min()
p.R[0][0] = -0.5
p.R[0][1] = 1.5
min.minimize(p,force,opt.step,itrmax=100,fmax=1E-12)
#io.savecon(min.p[0],'mina.con')
print min.p[0].R

opt=Gopt.cg()
opt.init()
min=Gmin.min()
p.R[0][0] = 0.5
p.R[0][1] = 0.0
min.minimize(p,force,opt.step,itrmax=100,fmax=1E-12)
#io.savecon(min.p[0],'minb.con')
print min.p[0].R
