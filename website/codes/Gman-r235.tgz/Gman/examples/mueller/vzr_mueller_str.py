#!/usr/bin/env python

import  Gman.str            as      Gstr
import  Gman.neb            as      Gneb
import  Gman.opt            as      Gopt
import  profile
from    Gman                import  *
from    Gman.vzr            import  *
from    Gman.pot            import  *
from    Gman.data.Spline2D  import  *


v = Vzr()
img = potentialBoard('mueller', -1.5, -0.5, 1.1, 1.7, 128, 7.5)


def doDraw():
    v.setCamera(-0.2, 0.6, 3.5, -0.2, 0.6, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    v.drawBoard(-1.5, 1.7, 0, 1.1, 1.7, 0, 1.1, -0.5, 0, -1.5, -0.5, 0, img)
    for i in range(len(str.p)):
        v.drawSphere(str.p[i].R[0][0], str.p[i].R[0][1], 0.01, 0.02, 1, 1, 1)
    str.generateSpline()
    step = 0.03
    t = 0
    while t < str.getLength() - step:
        p1 = str.getSplineValue(t)
        p2 = str.getSplineValue(t + step)
        v.drawLine(p1[0], p1[1], 0.02, p2[0], p2[1], 0.02, 1, 1, 1)
        t += step
    p1 = str.getSplineValue(t)
    p2 = str.getSplineValue(str.getLength())
    v.drawLine(p1[0], p1[1], 0.02, p2[0], p2[1], 0.02, 1, 1, 1)
    v.update()
    #raw_input()

p1 = data.point()
p2 = data.point()
io.loadcon(p1, 'mina.con')
io.loadcon(p2, 'minb.con')

potential=pot.set('mueller')

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="line")

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="hess")

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.2, min='line', alpha=0.08, memory=25)

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.0001, min='hess', alpha=0.000001, memory=25)

#opt=Gopt.qm()
#opt.init(dt=0.001, maxmove = 0.01)
 
#opt=Gopt.fire()
#opt.init(maxmove = 0.1, dt = 0.01)

#opt = Gopt.sd()
#opt.init(stepR = 0.01, maxmove = 0.01)

#opt=Gopt.cg()
#opt.init(maxmove=0.2, dR=0.0001)

opt=Gopt.rk4()
opt.init(dt = 0.09)

str = Gstr.newString()
str.new(p1, p2, images = 8)
str.relax(potential, opt.step, tangent = "none", itrmax = 25000, ppd = 1, fmax = 0.001, fsaddle = "off", graphic = doDraw, method = "off")

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / str.ni

