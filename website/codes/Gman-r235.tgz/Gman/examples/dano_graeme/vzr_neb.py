#!/usr/bin/env python

from   Gman     import  *
import Gman.neb as      Gneb
import Gman.opt as      Gopt
from   Gman.vzr import  *
from   Gman.pot import  *

draw = True
#draw = False

imgnumber = 500
if draw:
    v = Vzr()
    img = potentialBoard('dano_graeme', -1.8, -1.8, 1.8, 1.8, 64, 1.0)

def doDraw():
    v.setCamera(0, 0, 5, 0, 0, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    #v.drawBoard(-2, 2, 0, 2, 2, 0, 2, -2, 0, -2, -2, 0, img)
    v.drawBoard(-1.8, 1.8, 0, 1.8, 1.8, 0, 1.8, -1.8, 0, -1.8, -1.8, 0, img)
    for i in range(len(neb.p)):
        v.drawSphere(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, 0.05, 1, 1, 1)
    for i in range(len(neb.p) - 1):
        v.drawLine(neb.p[i].R[0][0], neb.p[i].R[0][1], 0.01, neb.p[i + 1].R[0][0], neb.p[i + 1].R[0][1], 0.01, 1, 1, 1)
    v.update()
    #raw_input()

def doPass():
    pass

p1=data.point()
p2=data.point()
io.loadcon(p1,'min1.con')
io.loadcon(p2,'min3.con')

potential=pot.set('dano_graeme')

opt=Gopt.qm()
opt.init(dt=0.01, maxmove = 0.2)

#opt=Gopt.sd()
#opt.init(stepR=0.001, maxmove = 0.2)

#opt=Gopt.lbfgs()
#opt.init( maxmove = 0.2)

neb=Gneb.neb()
neb.new(p1,p2,images=50)

#for i in range(1,len(neb.p)-1):
#  neb.p[i].R[0][0] -=0.2

if not draw:
    neb.relax(potential,opt.step,tangent="new",itrmax=1500,ppd=1,fmax=0.001,fsaddle='off',graphic=doPass,method="ci")
if draw:
    neb.relax(potential,opt.step,tangent="new",k = 20, itrmax=8000,ppd=1,fmax=0.001,fsaddle='off',graphic=doDraw,method="ci")
neb.save(io.savecon,'str.con')

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / neb.ni

while True:
    doDraw()
