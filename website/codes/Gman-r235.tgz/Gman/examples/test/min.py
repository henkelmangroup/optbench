#!/usr/bin/env python

from Gman import *
import Gman.opt 

p=data.point()
io.loadcon(p,'al1a.con')
force=pot.set('eamvoter',p)
force(p)
#print 'init force:',p.F
p.V=p.R.copy()*0.0
io.savexyz(p,'movie.xyz')
opt.sdmin(p,force,itrmax=500)
#for i in range(1000):
#  opt.sdstep(p,force)
#  io.savexyz(p,'movie.xyz','a')
#  print p.U,(abs(p.F)).max()
io.savecon(p,'al1fn.con')
