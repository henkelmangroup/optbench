#!/usr/bin/env pythoN

from Gman import *
import Gman.neb as neb

p1=data.point()
p2=data.point()
io.loadcon(p1,'al1a.con')
io.loadcon(p2,'al1b.con')
force=pot.set('eamvoter')
#force=pot.set('tip4p')
#force=pot.set('eamvoter',p)
#force=pot.set('morse',p)
force(p1)
force(p2)
#print 'init force:',p.F
p.V=p.R.copy()*0.0
io.savexyz(p,'movie.xyz')
for i in range(1000):
  if((p.F*p.V).sum()>0):
    p.V=p.F*((p.F*p.V).sum())/((p.F*p.F).sum())
  else:
    p.V*=0
#  p.R+=p.F*0.01
  dyn.mdstep(p,force,dt=0.15)
#  print 'F: ',p.F
#  print 'R: ',p.R
#  print 'V: ',p.V
  io.savexyz(p,'movie.xyz','a')
#  print p.U,'  ',(abs(p.F)).max()
  Ukin=0.5*(p.V*p.V*p.MassD).sum()
  Upot=p.U
  print Ukin,Upot,Ukin+Upot,(abs(p.F)).max()
