#!/usr/bin/env python

import  Gman.str            as      Gstr
import  Gman.opt            as      Gopt
import  profile
from    Gman                import  *
from    Gman.vzr            import  *
from    Gman.pot            import  *
from    Gman.data.Spline2D  import  *


v = Vzr()
img = simpleBoard(-0.1, -0.5, 1.1, 0.5, 128, 1)


def doDraw():
    v.setCamera(0.5, 0, 1.5, 0.5, 0, 0, 0, 1, 0)
    v.clear(0, 0, 0)
    v.drawBoard(-0.1, 0.5, 0, 1.1, 0.5, 0, 1.1, -0.5, 0, -0.1, -0.5, 0, img)
    for i in range(len(str.p)):
        v.drawSphere(str.p[i].R[0][0], str.p[i].R[0][1], 0.01, 0.02, 1, 0, 1)
    for i in range(len(str.p) - 1):
        v.drawLine(str.p[i].R[0][0], str.p[i].R[0][1], 0.01, str.p[i + 1].R[0][0], str.p[i + 1].R[0][1], 0.01, 0, 1, 0)
    #str.generateSpline()
    step = 0.03
    t = 0
    while t < str.getLength() - step:
        p1 = str.getSplineValue(t)
        p2 = str.getSplineValue(t + step)
        v.drawLine(p1[0], p1[1], 0.02, p2[0], p2[1], 0.02, 1, 1, 0)
        t += step
    v.update()
    #raw_input()

p1 = data.point()
p2 = data.point()
io.loadcon(p1, 'simplemina.con')
io.loadcon(p2, 'simpleminb.con')

potential=pot.set('simple')

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="line")

#opt=Gopt.lbfgs()
#opt.init(maxmove=0.2, alpha=0.08, memory=25, min="hess")

opt=Gopt.glbfgs()
opt.init(maxmove=0.2, min='line', alpha=0.08, memory=25)

#opt=Gopt.glbfgs()
#opt.init(maxmove=0.2, min='hess', alpha=0.08, memory=25)

#opt=Gopt.qm()
#opt.init(dt=0.01, maxmove = 0.01)
 
#opt=Gopt.fire()
#opt.init(maxmove = 0.2, dt = 0.14)

#opt = Gopt.sd()
#opt.init(stepR = 0.01, maxmove = 0.01)

#opt=Gopt.cg()
#opt.init(maxmove=0.2, dR=0.0001)

#opt=Gopt.rk4()
#opt.init()

str = Gstr.str()
str.new(p1, p2, images = 11, dimensions = 2)
str.p[1].R[0][1] += 0.01
str.relax(potential, opt.step, tangent = "old", itrmax = 25000, ppd = 1, fmax = 0.00, fsaddle = "off", graphic = doDraw, method = "off")
str.save(io.savecon,'str.con')

print "Force count: ", pot.count()
print "Force count per image: ", pot.count() / str.ni

