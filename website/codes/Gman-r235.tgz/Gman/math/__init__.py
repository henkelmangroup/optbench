__all__ = ["math"]
from math import *
