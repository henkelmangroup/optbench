__all__ = ["func"]
from func import *
