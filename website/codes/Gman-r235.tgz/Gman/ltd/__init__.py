__doc__ = '''Gman long time dynamics.'''

from ltd import *
