      SUBROUTINE FORCE(N, R, F, U)
      INTEGER N
      DOUBLE PRECISION R(3*N)
      DOUBLE PRECISION F(3*N)
      DOUBLE PRECISION U(1)
      DOUBLE PRECISION X,Y,Ysq,Xsq,X4,Y4
      X=R(1)
      Y=R(2)
      Xsq = X*X
      Ysq = Y*Y
      X4 = Xsq*Xsq
      Y4 = Ysq*Ysq
      U(1)=X4+Y4-DBLE(2)*Xsq-DBLE(4)*Ysq+X*Y+DBLE(0.3)*X+DBLE(0.1)*Y
      F(1)= -DBLE(0.3)+DBLE(4)*(X-X*Xsq)-Y
      F(2)= -DBLE(0.1)-X+DBLE(8)*Y-DBLE(4)*Y*Ysq
      END SUBROUTINE FORCE
