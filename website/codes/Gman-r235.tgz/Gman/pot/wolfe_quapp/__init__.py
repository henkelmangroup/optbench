__doc__ = '''Wolfe-Quapp-PES potential'''

from wolfe_quapp import *
