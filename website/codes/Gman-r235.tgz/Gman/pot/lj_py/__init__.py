__doc__ = '''Lennard Jones potential.'''

from lj import *
