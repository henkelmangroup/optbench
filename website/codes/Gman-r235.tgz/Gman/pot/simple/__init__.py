__doc__ = '''LEPS+HO potential'''

from simple import force
