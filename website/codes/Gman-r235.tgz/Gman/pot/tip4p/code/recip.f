C******************** RECIP
C
      SUBROUTINE RECIP(A1,A2,A3,B1,B2,B3,VOL)
      IMPLICIT REAL*8(A-H,O-Z)
C
      DIMENSION A1(3),A2(3),A3(3),B1(3),B2(3),B3(3)
      data pi /3.14159265358979312d0/
      TWOPI = 2.0D0 * PI
C
      ZERO = 0.0D0
      DET = ZERO
      I = 1
      J = 2
      K = 3
      S = 1.0D0
101   DO 102 IPERM = 1, 3
      DET = DET + S*A1(I)*A2(J)*A3(K)
      L = I
      I = J
      J = K
      K = L
102   CONTINUE
      I = 2
      J = 1
      K = 3
      S = -S
      IF (S .LT. ZERO) GO TO 101
      VOL = ABS(DET)
      DEN = TWOPI / DET
      I = 1
      J = 2
      K = 3
      DO 103 IR = 1, 3
      B1(IR) = DEN*(A2(J)*A3(K)-A2(K)*A3(J))
      B2(IR) = DEN*(A3(J)*A1(K)-A3(K)*A1(J))
      B3(IR) = DEN*(A1(J)*A2(K)-A1(K)*A2(J))
      L = I
      I = J
      J = K
      K = L
103   CONTINUE
      RETURN
      END
C
C ************** GENERATE G-VECTORS
C
C The scale factors are used to keep a constant ordering of
C G vectors even if the lattice constants change...
C
      SUBROUTINE GENKG(B1,B2,B3)
      INCLUDE 'dimen.prm'
C
      COMMON/GVEC/GG(NUMG,4),GKA(NPLG,4,NKP),KG(NUMG,3),KA(NPLG,3,NKP)
cgo     &            IKDX(NPLG,NKP),IDEX(NX,NY,NZ)
      DIMENSION B1(3),B2(3),B3(3)
      COMMON/G_WORK/GG_T(NUMG),GG_T1(NUMG),GG_T2(NUMG),GG_T3(NUMG),
     &              KG_T1(NUMG),KG_T2(NUMG),KG_T3(NUMG),INDEX(NUMG)
C
C We rescale in such a way that changing SC1 etc. doesn't change
C the ordering of the G vectors, or the number used.
C

      B11 = B1(1)
      B12 = B1(2)
      B13 = B1(3)
      B21 = B2(1)
      B22 = B2(2)
      B23 = B2(3)
      B31 = B3(1)
      B32 = B3(2)
      B33 = B3(3)
C
      IG = 0
      L1 = LGX - 1
      L2 = LGY - 1
      L3 = LGZ - 1
C
      DO 101 IX = -L1, L1
      G1X = IX * B11
      G2X = IX * B12
      G3X = IX * B13
C
      DO 101 IY = -L2, L2
      G1Y = G1X + IY * B21
      G2Y = G2X + IY * B22
      G3Y = G3X + IY * B23
C
      DO 101 IZ = -L3, L3
      G1 = G1Y + IZ * B31
      G2 = G2Y + IZ * B32
      G3 = G3Y + IZ * B33
C
      IG = IG + 1
C
      KG_T1(IG) = IX
      KG_T2(IG) = IY
      KG_T3(IG) = IZ
C
      GG_T1(IG) = G1
      GG_T2(IG) = G2
      GG_T3(IG) = G3
      GG_T(IG) = G1 * G1 + G2 * G2 + G3 * G3
101   CONTINUE
C
C --- Ranking and Indexing
C
C --- Is ordering really necessary here? -- it's done in MTSIZE too
      CALL ORDER(NUMG,GG_T,INDEX)
C
C --- Sorting
C
      CALL GATHER_I(NUMG,KG(1,1),KG_T1,INDEX)
      CALL GATHER_I(NUMG,KG(1,2),KG_T2,INDEX)
      CALL GATHER_I(NUMG,KG(1,3),KG_T3,INDEX)
C
      CALL GATHER(NUMG,GG(1,1),GG_T1,INDEX)
      CALL GATHER(NUMG,GG(1,2),GG_T2,INDEX)
      CALL GATHER(NUMG,GG(1,3),GG_T3,INDEX)
      CALL GATHER(NUMG,GG(1,4),GG_T,INDEX)
C
c	write(*,*) 'Ns',NX,NY,NZ
c	write(*,*) 'NUMG',NUMG

      DO 104 IG = 1, NUMG
      K1 = KG(IG,1)
      K2 = KG(IG,2)
      K3 = KG(IG,3)
cg    I think this is incorrect.  The NX,NY,NZ should be NGX,NGY,NGZ
cg      IF(K1 .LT. 0) K1 = K1 + NX
cg      IF(K2 .LT. 0) K2 = K2 + NY
cg      IF(K3 .LT. 0) K3 = K3 + NZ
      IF(K1 .LT. 0) K1 = K1 + NGX
      IF(K2 .LT. 0) K2 = K2 + NGY
      IF(K3 .LT. 0) K3 = K3 + NGZ
      KG(IG,1) = K1 + 1
      KG(IG,2) = K2 + 1
      KG(IG,3) = K3 + 1
c	write(*,*) 'Ks',K1+1,K2+1,K3+1

cg    I think this is incorrect.  The NX,NY,NZ should be NGX,NGY,NGZ
cg      IDEX(K1+1,K2+1,K3+1) = IG

104   CONTINUE
C
      RETURN
      END
C
C *** INDEXING AND RANKING (Numerical Recipes Chap. 8.3)
C
      SUBROUTINE ORDER(N,ARRIN,INDX)
      IMPLICIT REAL*8 (A-H,O-Z)
C
      DIMENSION ARRIN(N),INDX(N)
      DO 11 J=1,N
        INDX(J)=J
11    CONTINUE
      L=N/2+1
      IR=N
10    CONTINUE
        IF(L.GT.1)THEN
          L=L-1
          INDXT=INDX(L)
          Q=ARRIN(INDXT)
        ELSE
          INDXT=INDX(IR)
          Q=ARRIN(INDXT)
          INDX(IR)=INDX(1)
          IR=IR-1
          IF(IR.EQ.1)THEN
            INDX(1)=INDXT
            RETURN
          ENDIF
        ENDIF
        I=L
        J=L+L
20      IF(J.LE.IR)THEN
          IF(J.LT.IR)THEN
            IF(ARRIN(INDX(J)).LT.ARRIN(INDX(J+1)))J=J+1
          ENDIF
          IF(Q.LT.ARRIN(INDX(J)))THEN
            INDX(I)=INDX(J)
            I=J
            J=J+J
          ELSE
            J=IR+1
          ENDIF
        GO TO 20
        ENDIF
        INDX(I)=INDXT
      GO TO 10
      END

