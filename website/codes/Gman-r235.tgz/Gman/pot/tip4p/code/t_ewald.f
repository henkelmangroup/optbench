C
C*************** Ewald Table
C
      SUBROUTINE T_EWALD(A1L,A2L,A3L)
      INCLUDE 'dimen.prm'
C
      COMMON/E_TABLE/RSHELL(NUMR,3),EXPS1(NUMG),NR123(3),NG123(3)
      COMMON/E_CONST/GPAR,PI8V,ENN_R,ENN_G,FAC3,HAL(3)
      COMMON/CELL/Q_ATM(NAT),R_ATM(3,NAT),UNITCV,N_KATM(KAT),N_ATM,K_ATM
      COMMON/GVEC/GG(NUMG,4),GKA(NPLG,4,NKP),KG(NUMG,3),KA(NPLG,3,NKP)
cgo     &            IKDX(NPLG,NKP),IDEX(NX,NY,NZ)
      COMMON/G_WORK/GG_T(NUMG),GG_T1(NUMG),GG_T2(NUMG),GG_T3(NUMG),
     &              KG_T1(NUMG),KG_T2(NUMG),KG_T3(NUMG),INDEX(NUMG)
      COMMON/EWALD/RLATT(3,3),GLATT(3,3),NSHELL
C
      DATA SMN,PI/1.0D-6, 3.14159265358979D0/
      DATA PA,A1,A2,A3,A4,A5/0.3275911D0,0.254829592D0,-0.284496736D0
     &                      ,1.421413741D0,-1.453152027D0,1.061405429D0/
C
      TWOPI = 2.0D0 * PI
      PI8V = 8.0D0 * PI / UNITCV
      HAL(1) = 0.5D0 * A1L
      HAL(2) = 0.5D0 * A2L
      HAL(3) = 0.5D0 * A3L
C
C --- Determine the optimized convergence coefficient
C
cERB      CALL GRPAR(RLATT,NR123,NG123,GPAR)
      gpar = 4.0d0/unitcv**(1.0d0/3.0d0)      !added to replace CALL GRPAR
c      print *, 'convergence parameter: ', gpar
C
      GPAR2 = GPAR * GPAR
      FAC1 = -0.25D0 / GPAR2
      FAC2 = - PI / (GPAR2 * UNITCV)
      SQRTPI = 1.0D0 / SQRT(PI)
      FAC3 = 2.0D0 * GPAR * SQRTPI
C
      S0 = -2.0D0 * GPAR * SQRTPI
C
      L1 = LRX - 1
      L2 = LRY - 1
      L3 = LRZ - 1
cERB      IF(NRX .GT. NGX) L1 = LGX - 1
cERB      IF(NRY .GT. NGY) L2 = LGY - 1
cERB      IF(NRZ .GT. NGZ) L3 = LGZ - 1
C
      IR = 0
      DO 103 IZ = -L3, L3
      DO 103 IY = -L2, L2
      DO 103 IX = -L1, L1
C
      IR = IR + 1
C
      XR = IX*RLATT(1,1)+IY*RLATT(1,2)+IZ*RLATT(1,3)
      YR = IX*RLATT(2,1)+IY*RLATT(2,2)+IZ*RLATT(2,3)
      ZR = IX*RLATT(3,1)+IY*RLATT(3,2)+IZ*RLATT(3,3)
      GG_T1(IR) = XR
      GG_T2(IR) = YR
      GG_T3(IR) = ZR
      GG_T(IR) = XR*XR + YR*YR + ZR*ZR
103   CONTINUE
C
      CALL ORDER(NUMR,GG_T,INDEX)
      CALL GATHER(NUMR,RSHELL(1,1),GG_T1,INDEX)
      CALL GATHER(NUMR,RSHELL(1,2),GG_T2,INDEX)
      CALL GATHER(NUMR,RSHELL(1,3),GG_T3,INDEX)
C
      EXPS1(1) = ZERO
      DO 104 IG = 2, NUMG
      G_T = GG(IG,4)
      EXPS1(IG) = EXP(FAC1*G_T) / G_T
104   CONTINUE
C
C --- summing over same atoms, which are constants
C
      S = S0
C
      DO 105 IR = 2, NUMR
      R2 = GG_T(INDEX(IR))
      RSQ = SQRT(R2)
      GR = GPAR * RSQ
      T=1.D0/(1.D0+PA*GR)
      FERF = T*(A1+T*(A2+T*(A3+T*(A4+T*A5))))*EXP(-GR*GR)
      S = S + FERF / RSQ
105   CONTINUE
C
      QT = ZERO
      QT2 = ZERO
      DO 106 IA = 1, N_ATM
      QT = QT + Q_ATM(IA)
      QT2 = QT2 + Q_ATM(IA) ** 2
106   CONTINUE
C
C --- Constant terms in Ry units
C
      ENN_G = QT * QT * FAC2
      ENN_R = QT2 * S
C
      RETURN
      END
