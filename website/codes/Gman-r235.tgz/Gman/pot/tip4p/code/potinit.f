c   version e93:   add gregs SPF routine for chain relaxation
c   EAM version b91:   add FPI forces and potential by calling FPIforce                   
c                                                                                         
C     THIS SUBROUTINE COMPUTES THE FORCES by calling GAGAFE for each type of              
c     interaction.                                                                        

      SUBROUTINE POTINIT()

      implicit real*8 (a-h,o-z)

      include 'commonblks/parameters.cmn'
cgo      include 'commonblks/combaths.cmn'
cgo      include 'commonblks/comgeom.cmn'
      include 'commonblks/comconf.cmn'
cgo      include 'commonblks/comenergy.cmn'
cgo      include 'commonblks/comenperat.cmn'
      include 'commonblks/compotent.cmn'
cgo      include 'commonblks/comluns.cmn'
cgo      include 'commonblks/comintlis.cmn'
cgo      include 'commonblks/comtime.cmn'

cgo      common /unscale/RALOCAL(MAXCOO)

c     -----------------------------------------------------------------------
c	Defining the parameters in potpar manually (for TIP4P)

c	initflag=1

c	alpha=90
c	beta=90
c	gamma=90

c	IQKMIN=.false.
      nFPI=0

c	 H20 Parameters

      indf1=1
      potpar(1,1)=89.78
      potpar(2,1)=0.15
      potpar(3,1)=0.9572
      potpar(4,1)=104.52
      potpar(5,1)=600000
      potpar(6,1)=610.0
      potpar(7,1)=610.0
      potpar(8,1)=9.47523
      potpar(14,1)=0.9572
      potpar(15,1)=104.52

      stpsz=0.5
      amass(1)=1
      amass(2)=16
      natype=2
cgo      DO 10 I=1,NATYPE
cgo        sscrh(I)=STPSZ/(2.*amass(I))
cgo10      continue
cg      write(*,*)'potinit mass sscrh',amass(1),amass(2),sscrh(1),sscrh(2)
cgo      RETURN
      END
