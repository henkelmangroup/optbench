C Common blocks that are needed in almost every subroutine.
C
C In this file are the following common blocks:
C    ctol, ctol2, band, cell, pot_t, conv, hd_r, gvec, psi_r, rho_g,
C    rho_r, vppl_r, epp, epsi, mtsize, point, point_f, rho_mix,
C    dpsi, escf_r, escf
C At least one of these is used in each of the following subroutines
C or functions:
C   chden, diagon, ewald, excgrad, fermi, force, io, linemin, mixing,
C   nbefq, nbqstr, pressure, pseudo, recip, renew, readin, rho, rwcgx, savek,
C   scfbulk, scfpcg, scfpot, strfac, specialk, symion, symmetry, util


C
C  Tolerances:
C
      real *8 gamtol,dnrtol,restol,wtol,eftol,epsm,epss
      real *8 e1ctol,etol1,etol2,astol,tolq
      common/ctol/gamtol,dnrtol,restol,wtol,eftol,epsm,epss
      common/ctol2/e1ctol,etol1,etol2,astol,tolq      


C
C  miscellaneous parameters, including total charge, Fermi energy
C
      integer n_vb(nkp), n_vbf(nkp), iwb(4), i_wm, iexc, n_bnd
      real*8 fwb(4), alpha, tot_q, tk, sigma, tdosef, efq, tc_dif_m
      common/band/fwb,alpha,tot_q,tk,sigma,tdosef,efq,tc_dif_m,
     &            n_vb,n_vbf,iwb,i_wm,iexc,n_bnd
CMF$  LAYOUT n_vb(:NEWS)
CMF$  LAYOUT n_vbf(:SERIAL)
CMF$  LAYOUT iwb(:SERIAL)
CMF$  LAYOUT fwb(:SERIAL)


C
C   The unit cell description
C
      integer n_atm, k_atm, n_katm(kat)
      real *8 q_atm(nat), r_atm(3, nat), unitcv
      common/cell/q_atm,r_atm,unitcv,n_atm,k_atm,n_katm
CMF$  LAYOUT n_katm(:SERIAL)
CMF$  LAYOUT q_atm(:SERIAL)
CMF$  LAYOUT r_atm(:SERIAL,:SERIAL)


      complex *16 cvl_g(nx1, ny, nz)
      common/pot_t/cvl_g
CMF$  LAYOUT cvl_g(:NEWS,:NEWS,:NEWS)


      complex *16 cvl(nx1,ny,nz)
      common/conv/cvl
CMF$  LAYOUT cvl(:NEWS,:NEWS,:NEWS)

      complex *16 chd_r(nx1,ny,nz)
      common/hd_r/chd_r
CMF$  LAYOUT chd_r(:NEWS,:NEWS,:NEWS)

C
C The reciprocal lattice:
C energmask tells whether this G vector is within the energy cutoff
C ggmask tells whether or not this G vector is zero...
      integer kg(3,nx,ny,nz), idex(nx*ny*nz)
      integer xindex(nx,ny,nz)
      integer yindex(nx,ny,nz)
      integer zindex(nx,ny,nz)
      integer ixzero,iyzero,izzero
      logical energmask(nkp,nx,ny,nz)
      logical enggmask(nx,ny,nz)
      logical ggmask(nx,ny,nz)
      real *8 gg(4,nx,ny,nz), gka(4, nkp, nx,ny,nz)
      common/gvec/gg, kg, gka, energmask, enggmask, ggmask, idex,
     &            ixzero,iyzero,izzero, xindex,yindex,zindex
CMF$  LAYOUT energmask(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT enggmask(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT ggmask(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT idex(:NEWS)
CMF$  LAYOUT gg(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT kg(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT gka(:SERIAL,:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT xindex(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT yindex(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT zindex(:NEWS,:NEWS,:NEWS)


C
C  Current wavefunction
C
      complex *16 cpsi(nx1,ny,nz)
      common/psi_r/cpsi
CMF$  LAYOUT cpsi(:NEWS,:NEWS,:NEWS)

C
C  Reciprocal space charge density
C
      complex *16 crho_g(nx,ny,nz), cvl_t(nx,ny,nz)
      common/rho_g/crho_g,cvl_t
CMF$  LAYOUT crho_g(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT cvl_t(:NEWS,:NEWS,:NEWS)


C
C  Real space  charge density
C
      real *8 rho_r(nx,ny,nz)
      common/rho_r/rho_r
CMF$  LAYOUT rho_r(:NEWS, :NEWS, :NEWS)

C
C Real space potential and structure factors:
C
      real *8 vpp_r(nx,ny,nz)
      complex *16 csg(kat,nx,ny,nz), csg_t(nx,ny,nz)
      complex *16 cz_atm(nat,3)
cERB      common/vppl_r/vpp_r,csg,csg_t,cz_atm
      common/vppl_r/csg,csg_t,cz_atm,vpp_r
CMF$  LAYOUT vpp_r(:NEWS, :NEWS, :NEWS)
CMF$  LAYOUT csg(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT csg_t(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT cz_atm(:SERIAL,:SERIAL)


C
C The pseudopotential:
C  note: vnl_pp  reduced in size from nlm to nl in second argument
C  -- because the m-dependence is just given by ylm's, which are
C  already stored anyway.
C
      integer l_max(kat), nl_max(kat), i_nlocal
      real *8 zv(kat), vl_pp(kat,nx,ny,nz),
     &		 vnl_pp(nl,nll,kat,nkp,nx,ny,nz),vnl_kb(nl,nll,kat)
      common/epp/zv,vl_pp,vnl_pp,vnl_kb,l_max,nl_max,i_nlocal
CMF$  LAYOUT zv(:SERIAL)
CMF$  LAYOUT vl_pp(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT vnl_pp(:SERIAL,:SERIAL,:SERIAL,:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT vnl_kb(:SERIAL,:SERIAL,:SERIAL)
CMF$  LAYOUT l_max(:SERIAL)
CMF$  LAYOUT nl_max(:SERIAL)


C
C The wavefunction:
C
      real *8 wgt(nkp,nb), enk(nkp,nb)
      complex *16 cpsi_g(nb,nkpp,nx,ny,nz)
      common/epsi/wgt,enk,cpsi_g
CMF$  LAYOUT wgt(:SERIAL,:NEWS)
CMF$  LAYOUT enk(:SERIAL,:NEWS)
CMF$  LAYOUT cpsi_g(:SERIAL,:SERIAL,:NEWS,:NEWS,:NEWS)


C
C  Actually, following used only by scfpcg and recip.f
C
      integer iwarn, ipmax
      common/mtsize/iwarn,ipmax

C
C  And the following are only used with symmetry.f
C
C  Arrays used for symmetrization in reciprocal space:
C  nsymop is now to be set properly by the user, at the
C  expected number of symmetry operations.
C
      integer irglist(nsymop, 3, nx, ny, nz), nsym(nx,ny,nz)
      logical symmask(nx,ny,nz), boundsmask(nsymop,nx,ny,nz)
      logical gzeromask(nsymop,nx,ny,nz)
CMF$  LAYOUT irglist(:SERIAL,:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT nsym(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT symmask(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT boundsmask(:SERIAL,:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT gzeromask(:SERIAL,:NEWS,:NEWS,:NEWS)
      common/symlists/irglist,nsym,symmask,boundsmask,gzeromask

C
C The following arrays used for finding the symmetry etc:
C -- these have the number of symmetry elements hard-coded as 48,
C   in case there are actually more found than expected.
C
      integer irot(3,3,48)
      integer n_rt,isymp
      real *8 rottau(3, 48)
      complex*16 ctau_g(nx,ny,nz)
      common/point/ctau_g,rottau,irot,n_rt,isymp
CMF$  LAYOUT ctau_g(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT rottau(:SERIAL,:SERIAL)
CMF$  LAYOUT irot(:SERIAL,:SERIAL,:SERIAL)

      integer n_rt_f
      real*8 rot_f(3,3,48), tau_f(3,48)
      common/point_f/rot_f,tau_f,n_rt_f
CMF$  LAYOUT rot_f(:SERIAL,:SERIAL,:SERIAL)
CMF$  LAYOUT tau_f(:SERIAL,:SERIAL)

C
C  mixing parameters
C
      integer i_rho
      real*8 a_exp(nx,ny,nz), q_mix
      common/rho_mix/a_exp,q_mix,i_rho
CMF$  LAYOUT a_exp(:NEWS,:NEWS,:NEWS)


C
C  ??
C
      real *8 enke(nkp,nb), e_k
      common/dpsi/enke,e_k
CMF$  LAYOUT enke(:SERIAL,:NEWS)


C
C  SCF potential in real and reciprocal space
C
      real *8 vr_scf(nx,ny,nz)
      complex *16 cv_scf(nx,ny,nz)
      common/escf_r/vr_scf
      common/escf/cv_scf
CMF$  LAYOUT vr_scf(:NEWS,:NEWS,:NEWS)
CMF$  LAYOUT cv_scf(:NEWS,:NEWS,:NEWS)

C  array for masking in unpack
C      logical mask(nx1,ny,nz)
C      logical maskl
C      complex*16 coned(numg)
C      complex*16 c3d(nx1,ny,nz)
      complex*16 czero
c     common /cmask/ coned,mask,maskl
C      data mask/numg*.true./
C      data maskl/.true./
      data czero/(0.0d0,0.0d0)/
CCMF$ LAYOUT mask(:NEWS,:NEWS,:NEWS)
CCMF$ LAYOUT coned(:NEWS)
C       integer ipa,iunpa
C      common /icount/ipa,iunpa

C
C   Special k-points
C
      integer n_kp
      real *8 skp(4,nkp)
      common/kpoint/skp,n_kp
CMF$  LAYOUT skp(:SERIAL,:SERIAL)
