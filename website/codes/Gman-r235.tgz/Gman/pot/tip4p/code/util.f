C
C ****************  GRAM-SCHMIDE ORTHONORMALIZATION
C
      SUBROUTINE ORTHO_GS(NPL_T,IB,IK,CV_T)
      INCLUDE 'dimen.prm'
C
      DIMENSION CV_T(*),CV_B(NPLG)
      COMMON/ePSI/WGT(NB,NKP),ENK(NB,NKP),CPSI_G(NPLG,NB,NKPP)
      COMMON/CONV/CVL(NX1,NY,NZ)
      COMMON/CTOL/GAMTOL,DNRTOL,RESTOL,WTOL,EFTOL,EPSM,EPSS
C
      COMMON/POT_T/CV_A(NUMG)
      EQUIVALENCE (CV_B(1),CVL(1,1,1))
C
      CALL CCOPY(NPL_T,CV_T,INC,CV_B,INC)
C
      DO 102 IBB = 1, IB - 1
      CALL CCOPY(NPL_T,CPSI_G(1,IBB,IK),INC,CV_A,INC)
      COVLP = - CDOTC(NPL_T,CV_A,INC,CV_B,INC)
      CALL CAXPY(NPL_T,COVLP,CV_A,INC,CV_T,INC)
102   CONTINUE
C
      DNR = SCNRM2(NPL_T,CV_T,INC)
      DDNR = ZERO
      IF(ABS(DNR) .GT. DNRTOL) DDNR = 1.0D0 / DNR
      CALL CSSCAL(NPL_T,DDNR,CV_T,INC)
C
      RETURN
      END
C ************ DOT PRODUCT
C
      DOUBLE PRECISION FUNCTION DOTV(A,B)
C     CALCULATES THE DOT PRODUCT OF TWO VECTORS
      REAL*8 A(3),B(3)
C
      DOTV = 0.0D0
      DO 101 I = 1, 3
101   DOTV = DOTV + A(I) * B(I)
      RETURN
      END
C
C
C
      SUBROUTINE GATHER_I(NSIZE,I_AR,J_AR,IDX)
      IMPLICIT REAL*8 (A-H,O-Z)
C
      DIMENSION I_AR(*),J_AR(*),IDX(*)
C
      DO 101 IA = 1, NSIZE
      I_AR(IA) = J_AR(IDX(IA))
101   CONTINUE
      RETURN
      END

cg	added from mdUtil
	real*8 function dot(r1, r2)
c     Routine to calculate the dot product of 3-vectors. dot = r1.r2
      real*8 r1(3), r2(3)

      dot = r1(1)*r2(1) + r1(2)*r2(2) + r1(3)*r2(3)
      return
      end