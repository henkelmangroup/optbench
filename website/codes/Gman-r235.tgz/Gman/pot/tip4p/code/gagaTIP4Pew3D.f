c-----------------------------------------------------------------------
c                  TIP4P POTENTIAL WITH EWALD SUMMATION
c-----------------------------------------------------------------------
c     This program incorporates the potential of interaction between two
c     water molecules described in Journal of Physical Chemistry vol 91,
c     no 10, pp 2513-18, 1987. 
c     An arrays with positions enters as argument ra(). 
c     It is assumed that the array of positions ra() has a length equal
c     to 9 times the number of molecules and that its structure is the
c     following: 
c           ra(l+6*(i-1)) stores the l-th coordinate of the first
c                         hydrogen in the i-th molecule
c           ra(l+3+6*(i-1)) stores the l-th coordinate of the second
c                         hydrogen in the i-th molecule
c           ra(l+3*(i-1+nHydrogens)) stores the l-th coordinate of the
c                         oxigen in the i-th molecule. (nHydrogens is
c                         the total number of hydrogen atoms)
c     The routine will return an array fa() with the forces on each atom.
c     The array fa() has the same structure as ra().
c     The total potential energy of the configuration is also calculated
c     and returned in 'uTot'.
c
c     This routine was written by Enrique Batista.
c-----------------------------------------------------------------------

c23456789012345678901234567890123456789012345678901234567890123456789012
c        10        20        30        40        50        60        70

cGH      subroutine gagafe(nAtms, raOri, fa, uTot, virial)
      subroutine gagafe(ncoo, raOri, fa, uTot, tax, tay, taz)

      implicit real*8 (a-h,o-z)

c----- Beginning of lines added for doing Ewald summation -----
      include 'dimenReal.prm'

      DIMENSION F_ION(NAT,3)
      COMMON/CELL/Q_ATM(NAT),R_ATM(3,NAT),UNITCV,N_KATM(KAT),N_ATM,K_ATM

      COMMON/GVEC/GG(NUMG,4),GKA(NPLG,4,NKP),KG(NUMG,3),KA(NPLG,3,NKP)
cgo     &            IKDX(NPLG,NKP),IDEX(NX,NY,NZ)
      COMMON/G_WORK/GG_T(NUMG),GG_T1(NUMG),GG_T2(NUMG),GG_T3(NUMG),
     &              KG_T1(NUMG),KG_T2(NUMG),KG_T3(NUMG),INDEX(NUMG)
      COMMON/EWALD/RLATT(3,3),GLATT(3,3),NSHELL

      DIMENSION A1(3),A2(3),A3(3),B1(3),B2(3),B3(3)
      real*8 r1(3), r2(3), r3(3), rn(3)
      real*8 f1(3), f2(3), f3(3)
c-------- end of lines added for doing Ewald summation --------

      include 'commonblks/parameters.cmn'
      include 'commonblks/compotent.cmn'
cgo      include 'commonblks/comtime.cmn'
      include 'commonblks/comgeom.cmn'    

      real*8 m(3), m1(3), m2(3), mn(3), fTot(3)
cgo      integer coord, atom1, atom2, atom3

      real*8 A_LJ, C_LJ, q2, dr(3)
      real*8 d, Ro, theta0, rHH, rHHsq
cGH      real*8 k, pi, raOri(maxCoo), a(3)
      real*8 k, pi, a(3)
cGH      real*8 ra(maxCoo), fa(maxCoo), uTot, faB(maxCoo), u
      real*8 ra(maxCoo), uTot, faB(maxCoo), u
cGH Needed for the python interface
      real*8 raOri(ncoo), fa(ncoo), uRet(1), tax, tay, taz

      real*8 dist, convFactor, virial, rr(maxcoo)
      integer nMolecules, nOxygens, nHydrogens, nAtms(maxComp)
      real*8 rrH1(3), rrH2(3), rrO(3), drr(3)

cGH Parameters from python
      ax=tax
      ay=tay
      az=taz
      nAtms(1)=2*ncoo/9
      nAtms(2)=ncoo/9
      
      pi = 3.14159265358979312
c     Rescue intermolecular parameters
      q2 = potpar(1, 1)
      d  = potpar(2, 1)
      Ro = potpar(3, 1)
      theta0 = potpar(4, 1)
      A_LJ = potpar(5, 1)
      C_LJ = potpar(6, 1)
      q0 = sqrt(q2)
      k = d/(2.0d0 * Ro * cos(theta0 * pi/360.0d0))
      rHH = 2.0d0 * Ro * sin(theta0 * pi/360.0d0)
      rHHsq = rHH*rHH
c     Size of the simulation cell
      a(1) = ax
      a(2) = ay
      a(3) = az

c      write(*,*) 'box', ax,ay,az
c      write(*,*) 'q2',q2
c      write(*,*) 'd',d
c      write(*,*) 'Ro',Ro
c      write(*,*) 'theta0',theta0
c      write(*,*) 'A_LJ',A_LJ
c      write(*,*) 'C_LJ',C_LJ
c      write(*,*) 'q0',q0
c      write(*,*) 'k',k
c      write(*,*) 'rHH',rHH

      uTot = 0.0d0
      nOxygens = nAtms(2)
      nHydrogens = nAtms(1)
      nMolecules = nOxygens

c      write(*,*) 'nH',nHydrogens,'nO',NOxygens

c     Recover broken molecules due to PBC
      do i = 1, nOxygens
         do l = 1, 3
            do n = 1, 2
               indice = l+3*(n-1)+6*(i-1)
               dist = raOri(l+3*(n-1)+6*(i-1))
               dist = dist -raOri(l+3*(i-1+nHydrogens))
               if (dist .gt. a(l)/2.0d0) then
                  ra(indice) = raOri(indice) - a(l)
               elseif(dist .lt. -a(l)/2.0d0) then
                  ra(indice) = raOri(indice) + a(l)
               else
                  ra(indice) = raOri(indice)
               end if
            end do
            ra(l+3*(i-1+nHydrogens)) = raOri(l+3*(i-1+nHydrogens))
         end do
      end do

cg	write(*,*) ra(1:3*nMolecules)

 
**********************************************
cSurf      rr3 = ra(3)
cSurf      rr6 = ra(6)
cSurf      rr189 = ra(189)
cSurf      do shi = 1, 10
cSurf         ra(3) = rr3 + shi
cSurf         ra(6) = rr6 + shi
cSurf         ra(189) = rr189 + shi

c     Lines added to study the dependence of the potential energy with
c     the volume of the box

c$$$      aax = a(1)
c$$$      aay = a(2)
c$$$      aaz = a(3)
c$$$
c$$$      do i = 1, 3*(nOxygens+nHydrogens)
c$$$         rr(i) = ra(i)
c$$$      end do
c$$$
c$$$      do sscale = 0.98, 1.02, 0.001
c$$$
c$$$         uTot = 0.0d0
c$$$         u = 0.0d0
c$$$         do i = 1, 3*(nOxygens+nHydrogens)
c$$$            fa(i) = 0.0d0
c$$$         end do
c$$$      
c$$$         ax = aax * sscale
c$$$         ay = aay * sscale
c$$$         az = aaz * sscale
c$$$         a(1) = ax
c$$$         a(2) = ay
c$$$         a(3) = az
c$$$         
c$$$         do i = 1, nOxygens
c$$$            do j = 1, 3
c$$$               indexO = 3*(nHydrogens + i-1) + j
c$$$               indexH = 3 * (2*i - 1) + j
c$$$               ra(indexH) = rr(indexH) + rr(indexO) * (sscale - 1.d0)
c$$$               indexH = indexH - 3
c$$$               ra(indexH) = rr(indexH) + rr(indexO) * (sscale - 1.d0)
c$$$               ra(indexO) = rr(indexO) * sscale
c$$$            end do
c$$$         end do     

c     Spring constant
c$$$      mole_num = 18
c$$$      mol_1 = mole_num
c$$$      mol_2 = 30
c$$$      indexH = ((2 * mole_num - 1) - 1) * 3
c$$$      indexO = 3 * (nAtms(1) + mole_num - 1)
c$$$      do i = 1, 3         
c$$$         rrH1(i) = ra(indexH + i)
c$$$         rrH2(i) = ra(indexH + 3 + i)
c$$$         rrO(i) = ra(indexO + i)
c$$$      end do
c$$$
c$$$      do i = 1, 3
c$$$         drr(i) = ra(3 * (nAtms(1) + mol_1 - 1) + i)
c$$$         drr(i) = dr(i) - ra(3 * (nAtms(1) + mol_2 - 1) + i)
c$$$      end do
c$$$      dd = sqrt(drr(1)*drr(1) + drr(2)*drr(2) + drr(3)*drr(3))
c$$$      drr(1) = drr(1)/dd
c$$$      drr(2) = drr(2)/dd
c$$$      drr(3) = drr(3)/dd
c$$$      
c$$$      n = 3
c$$$      do ishift = -n, n
c$$$         dd = 0.01 * ishift / n
c$$$         do i = 1, 3
c$$$            ra(indexH + i) = rrH1(i) + dd * drr(i)
c$$$            ra(indexH + 3 + i) = rrH2(i) + dd * drr(i)
c$$$            ra(indexO + i) = rrO(i) + dd * drr(i)
c$$$         end do
c$$$         uTot = 0.0
**********************************************


c--- Beginning of Ewald summation of the coulombic interactions ---
 
      N_atm = nHydrogens + nOxygens
      K_atm = 2
      N_katm(1) = nHydrogens
      N_katm(2) = nOxygens

      do i = 1, nHydrogens
         Q_atm(i) = q0
      end do
      do i = nHydrogens+1, nHydrogens+nOxygens
         Q_atm(i) = -2.0d0 * q0
      end do

      do j = 1, nHydrogens
         do i = 1, 3
            R_atm(i,j) = ra(3*(j-1)+i)
         end do
c$$$         print '(i4,4f18.10)', j, (R_atm(i,j), i=1,3)
c$$$         print *, j, ra(3*(j-1)+2)
c$$$         pause
      end do
      do j = 1, nOxygens
         do i = 1, 3
            R_atm(i,nHydrogens+j) = ra(i+3*(j-1+nHydrogens)) + k * 
     $           (ra(i+6*(j-1)) + ra(i+3+6*(j-1)) - 2.0d0 * 
     $           ra(i+3*(j-1+nHydrogens)))
         end do
c$$$         print '(i4,4f18.10)', nHydrogens+j, 
c$$$     $        (R_atm(i,nHydrogens+j), i=1,3), q_atm(nHydrogens+j)
      end do


**********************
c Testing that the force equals the derivative of the total energy
c$$$      coord = 3
c$$$      atom1 = 1
c$$$      atom2 = 2
c$$$      atom3 = 17
c$$$
c$$$      rr1 = r_atm(coord, atom1)
c$$$      rr2 = r_atm(coord, atom2)
c$$$      rr3 = r_atm(coord, atom3)
c$$$      nn = 200
c$$$      ddx = 5.0d-6
c$$$      xx1 = rr1 + (0-nn/2) * ddx
c$$$      xx2 = rr2 + (0-nn/2) * ddx
c$$$      xx3 = rr3 + (0-nn/2) * ddx
c$$$      r_atm(coord, atom1) = xx1
c$$$      r_atm(coord, atom2) = xx2
c$$$      r_atm(coord, atom3) = xx3
c$$$      uOld = u
c$$$      do jj = 1, nn/2
c$$$         xx1 = rr1 + (jj-nn/2) * ddx
c$$$         xx2 = rr2 + (jj-nn/2) * ddx
c$$$         xx3 = rr3 + (jj-nn/2) * ddx
c$$$         r_atm(coord, atom1) = xx1
c$$$         r_atm(coord, atom2) = xx2
c$$$         r_atm(coord, atom3) = xx3
c$$$
**********************
      
      do i = 1, nHydrogens+nOxygens
         do j = 1, 3
            f_ion(i,j) = 0.d0
         end do
      end do


      nshell = numg

      a1L = ax
      a2L = ay
      a3L = az

      unitcv = ax*ay*az

      RLATT(1,1) = 1.0d0 * a1L
      RLATT(2,1) = 0.0d0 * a1L
      RLATT(3,1) = 0.0d0 * a1L

      RLATT(1,2) = 0.0d0 * a2L
      RLATT(2,2) = 1.0d0 * a2L
      RLATT(3,2) = 0.0d0 * a2L

      RLATT(1,3) = 0.0d0 * a3L
      RLATT(2,3) = 0.0d0 * a3L
      RLATT(3,3) = 1.0d0 * a3L

      A1(1) = RLATT(1,1)
      A1(2) = RLATT(2,1)
      A1(3) = RLATT(3,1)

      A2(1) = RLATT(1,2)
      A2(2) = RLATT(2,2)
      A2(3) = RLATT(3,2)

      A3(1) = RLATT(1,3)
      A3(2) = RLATT(2,3)
      A3(3) = RLATT(3,3)

      call RECIP(A1,A2,A3,B1,B2,B3,unitcv)

      call GENKG(B1,B2,B3)

      call str_fac
      call t_ewald(a1l, a2l, a3l)

      call f_ewald(f_ion, totme)

      uTot = totme/2.0d0

c      write(*,*) 'uTot after f_ewald',uTot

      do j = 1, 3
         do i = 1, nOxygens+nHydrogens
            f_ion(i,j) = f_ion(i,j)/2.d0
         end do
      end do

c      write(*,*) 'f_ion after f_ewald'
c      write(*,'(3E13.5)') f_ion(1:nOxygens+nHydrogens,:)

      if (.false.) then

      do j = 1, nMolecules
         do i = 1, 3
            f1(i) = f_ion(2*j-1, i)
            f2(i) = f_ion(2*j, i)
            f3(i) = f_ion(j+nHydrogens, i)
            r1(i) = R_atm(i, 2*j-1)
            r2(i) = R_atm(i, 2*j)
            rn(i) = R_atm(i, j+nHydrogens)
            r3(i) = ra(i+3*(j-1+nHydrogens))
         end do

         call molForce(f1, f2, f3, r1, r2, r3, rn, rHHsq)
      
         do i = 1, 3
            fa(i+6*(j-1)) = f1(i)/2.0d0
            fa(i+3+6*(j-1)) = f2(i)/2.0d0
            fa(i+3*(j-1+nHydrogens)) = f3(i)/2.0d0
         end do

      end do

      end if


c*************** Testing area *****
*     Subtract intramolecular forces and energies.
      do i = 1, nHydrogens-1, 2
         j = i+1
         do l = 1, 3
            dr(l) = r_atm(l,i) - r_atm(l,j)
         end do
         dr2 = dr(1)*dr(1) + dr(2)*dr(2) + dr(3)*dr(3)
         dr1 = sqrt(dr2)
         qij = q_atm(i) * q_atm(j)
         fij = qij/(dr2*dr1)
         do l = 1, 3
            f_ion(i,l) = f_ion(i,l) - fij * dr(l)
            f_ion(j,l) = f_ion(j,l) + fij * dr(l)
         end do
         uTot = uTot - qij/dr1
      end do
      
      do i = nHydrogens + 1, nHydrogens + nOxygens
         ji = 2*(i-nHydrogens) - 1
         do j = ji, ji+1
            do l = 1, 3
               dr(l) = r_atm(l,i) - r_atm(l,j)
            end do
            dr2 = dr(1)*dr(1) + dr(2)*dr(2) + dr(3)*dr(3)
            dr1 = sqrt(dr2)
            fij = q_atm(i)*q_atm(j)/(dr2*dr1)
            do l = 1, 3
               f_ion(i,l) = f_ion(i,l) - fij * dr(l)
               f_ion(j,l) = f_ion(j,l) + fij * dr(l)
            end do
            uTot = uTot - q_atm(i)*q_atm(j)/dr1
         end do
      end do

c     Distribute the force on the N charge among the oxygen and the
c     hydrogens. 
      do j = 1, nMolecules
         oIndex = j+nHydrogens
         h1Index = 2*j-1
         h2Index = 2*j
         do i = 1, 3
c     decompose the forces on changes into H1, H2 & O
            fa(i+6*(j-1)) = (f_ion(h1Index, i) + k * f_ion(oIndex,i))
            fa(i+3+6*(j-1)) = (f_ion(h2Index, i) + k * f_ion(oIndex,i))
            fa(i+3*(j-1+nHydrogens)) =  
     $           (1.0d0 - 2.0d0 * k) * f_ion(oIndex,i)
         end do
      end do
c********* End testing area ***************

***************      
c$$$      fNum = - (uTot-uOld)/ddx
c$$$      fExa = f_ion(atom1,coord) +f_ion(atom2,coord) +f_ion(atom3,coord)
c$$$      if (jj .gt. 1 ) print '(4g15.7)', xx1, fExa, fNum, uTot
c$$$      uOld = uTot
c$$$      end do
c$$$      stop
***************
c---End of Ewald sum of the coulombinc interactions---
 
c     Add Oxygen-Oxygen interaction
      call O_O(ra, faB, u, nOxygens, nHydrogens, a_LJ, c_LJ)
      call update(fa, faB, uTot, u, nOxygens, nHydrogens)


      virial = 0.0d0
c     Convert units from Kcal/mol to eV/atom
c     1 Kcal/mol = 4180 J/mol / (1.6 10^-19 J/eV x 6.022 10^23 at/mol)

      convFactor = 4180.0d0 / (1.6021892d-19 * 6.022045d23)
      do i = 1, 3*(nHydrogens+nOxygens)
         fa(i) = convFactor * fa(i)
c         virial = virial - ra(i)*fa(i)
      end do
      uTot = uTot * convFactor

cGH Return energy to python
      uRet(1) = uTot

************************************
cSurf      print *, shi, ra(189), uTot
cSurf      write(99,*) shi, ra(189), uTot

c$$$      print *, sscale, 2.72345*sscale, uTot
c$$$      write (99,*) sscale, 2.72345*sscale, uTot
c$$$      end do
c$$$      close (99)
c$$$      stop

c     spring constant
c$$$      print '(2f15.7)', dd, uTot
c$$$      write(1,'(2f15.7)') dd, uTot
c$$$      end do                    ! ishift
c$$$      stop
************************************

      return
      end

c----------------------------------------------------------------------+
c                                                                      |
c     O-O INTERACTION. Oxygens interact through a 12-6 Lennard-Jones   |
c                                                                      |
c----------------------------------------------------------------------+
      subroutine O_O(ra, fa, uTot, nOxygens, nHydrogens, A, C)

      include 'commonblks/parameters.cmn'
      real*8 ra(maxCoo), fa(maxCoo), uTot, dr(3)
      real*8 dr1, dr2, dr6, dr8, f_OO, V_OO, A, C
      real*8 sf, dSFdx, dFdx, switchFunc
      integer i, j, l, nHydrogens, nOxygens


      do i = 1, nOxygens-1
         do j = i+1, nOxygens
            do l = 1, 3
               dr(l) =  ra(l+3*(i-1+nHydrogens)) - 
     .              ra(l+3*(j-1+nHydrogens))
            end do

            call applyPBC(dr, dr, 1)

            dr2 = dr(1)*dr(1) + dr(2)*dr(2) + dr(3)*dr(3)
cSF            dr1 = dsqrt(dr2)
            dr6 = dr2 * dr2 * dr2
            dr8 = dr6 * dr2

cSF            sf = switchFunc(dr1)
cSF            dFdx = dSFdx(dr1)
            V_OO = (A/dr6 - C)/dr6

            do l = 1, 3
               f_OO = (12.d0 * A/dr6 - 6.d0 * C) * dr(l)/dr8
cSF-------------------------------
cSF               f_OO = f_OO * sf - V_OO * dFdx * dr(l)/dr1
c---------------------------------
               index = l+3*(i-1+nHydrogens)
               fa(index) = fa(index) + f_OO
               index = l+3*(j-1+nHydrogens)
               fa(index) = fa(index) - f_OO
            end do
            
            uTot = uTot + V_OO 
cSF            uTot = uTot + V_OO * sf

         end do
      end do

      return
      end 

c-----------------------------------------------------------------------
      subroutine molForce(f1, f2, f3, r1, r2, r3, rn, rHHsq)
      real*8 dot, alpha1, alpha2, beta1, beta2, lDr1, lDr2, blSq, sc
      
      real*8 r1(3), r2(3), r3(3), rn(3), f1(3), f2(3), f3(3)
      real*8 m(3), m1(3), m2(3), mn(3), fTot(3), r21(3), r31(3), r23(3)
      real*8 m2T(3), v1(3), v2(3), l(3), alpha, rHHsq

      call cross(r1, f1, m1)
      call cross(r2, f2, m2)
      call cross(rn, f3, mn)

      do i = 1, 3
         m(i) = m1(i) + m2(i) + mn(i)
         fTot(i) = f1(i) + f2(i) + f3(i)
      end do

      print '(3f17.10)', (m(i), i=1,3)
      print '(3f17.10)', (fTot(i), i=1,3)

      do i = 1, 3
         r21(i) = r1(i) - r2(i)
         r31(i) = r1(i) - r3(i)
         r23(i) = r3(i) - r2(i)
      end do

      call cross(r2, fTot, m2T)
      call cross(r31, r21, v1)
      call cross(r23, v1, v2)

      alpha = (dot(m, r21) - dot(m2T, r21))/dot(v2, r21)

      do i = 1, 3
         l(i) = m(i) - m2T(i) - alpha * v2(i)
      end do
      call cross(l, r21, f1)
      call cross(r31, r21, f3)

      do i = 1, 3
         f1(i) = f1(i)/rHHsq
         f3(i) = alpha * f3(i)
         f2(i) = fTot(i) - f1(i) - f3(i)
      end do


      call cross(r1, f1, m1)
      call cross(r2, f2, m2)
      call cross(rn, f3, mn)

      do i = 1, 3
         m(i) = m1(i) + m2(i) + mn(i)
         fTot(i) = f1(i) + f2(i) + f3(i)
      end do

      print '(3f17.10)', (m(i), i=1,3)
      print '(3f17.10)', (fTot(i), i=1,3)
      pause 'molforce'

      return
      end

c-----------------------------------------------------------------------
      subroutine cross(a, b, c)

c     This routine returns the cross product c=axb
      real*8 a(3), b(3), c(3)

      c(1) = a(2)*b(3) - a(3)*b(2)
      c(2) = a(3)*b(1) - a(1)*b(3)
      c(3) = a(1)*b(2) - a(2)*b(1)

      return
      end

c-----------------------------------------------------------------------
      subroutine update(fa, faB, uTot, u, nOxygens, nHydrogens)

c     Add the vector faB to fa and u to the total energy uTot.

      include 'commonblks/parameters.cmn'
      real*8 fa(maxCoo), uTot, faB(maxCoo), u
      integer nOxygens, nHydrogens, i, l, index

      uTot = uTot + u
      u = 0.0d0

      do i = 1, nHydrogens + nOxygens
         do l = 1, 3
            index = l+3*(i-1)
c
c To calculate energy maxima use the following line and comment the next one.
c            fa(index) = fa(index) - faB(index)
c
            fa(index) = fa(index) + faB(index)
            faB(index) = 0.0d0
         end do
      end do

      return
      end

c-----------------------------------------------------------------------      
      subroutine applyPBC(r, sep, j)

      implicit real*8 (a-h,o-z)
      include 'commonblks/comgeom.cmn'
      real*8 r(3), a(3), sep(3)
      integer j

c     Size of the simulation cell
      a(1) = ax/2.0d0
      a(2) = ay/2.0d0
      a(3) = az/2.0d0

      do i = 1, 3
c         if (j*sep(i) .gt. a(i)) then
         if (r(i) .gt. a(i)) then
            r(i) = r(i) - 2.0d0 * a(i)
c         elseif (j*sep(i) .lt. -a(i)) then
         elseif (r(i) .lt. -a(i)) then
            r(i) = r(i) + 2.0d0 * a(i)
         end if
      end do

      j = 0

      return
      end
c-----------------------------------------------------------------------

c-----------------------------------------------------------------------      
c----------------------------- The End ---------------------------------
c-----------------------------------------------------------------------      

 
c                               _------____
c                              (           )
c                             (_  The End   )
c                               (__  _____-"
c                                  |/
c                                  /
c                             .----.
c                            /(o)(o)\
c                           //     /||
c                          ||\ T  / ||
c                           "  "" \  "
c                              ||| \
c                             ( |(   \   _
c                            __\__\__---"

