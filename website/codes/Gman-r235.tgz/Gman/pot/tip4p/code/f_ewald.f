C
C*************** Ewald Forces
C
      SUBROUTINE F_EWALD(F_ION,TOTME)
      INCLUDE 'dimen.prm'
C
      DIMENSION MR(3),MG(3),R(3),RMT(3),F_ION(NAT,3)
      COMMON/E_TABLE/RSHELL(NUMR,3),EXPS1(NUMG),NR123(3),NG123(3)
      COMMON/E_CONST/GPAR,PI8V,ENN_R,ENN_G,FAC3,HAL(3)
      COMMON/CELL/Q_ATM(NAT),R_ATM(3,NAT),UNITCV,N_KATM(KAT),N_ATM,K_ATM
      COMMON/GVEC/GG(NUMG,4),GKA(NPLG,4,NKP),KG(NUMG,3),KA(NPLG,3,NKP)
cgo     &            IKDX(NPLG,NKP),IDEX(NX,NY,NZ)
cERB      COMMON/VPPL_R/VPP_R(NX,NY,NZ),CSG(NUMG,KAT),CSG_ATM(NUMG,NAT)
cgo      COMMON/VPPL_R/CSG(NUMG,KAT),CSG_ATM(NUMG,NAT),VPP_R(NX,NY,NZ)
      COMMON/VPPL_R/CSG(NUMG,KAT),CSG_ATM(NUMG,NAT)
      COMMON/EWALD/RLATT(3,3),GLATT(3,3),NSHELL

C
      EXTERNAL AIMAG
C
      DATA PA,A1,A2,A3,A4,A5/0.3275911D0,0.254829592D0,-0.284496736D0,
     &                       1.421413741D0,-1.453152027D0,1.061405429D0/
cgo      DATA SMN,PI/1.0D-6, 3.14159265358979D0/
C
      NRSHELL = NUMR
      NGSHELL = NUMG

cg      print '(A,i)', '# of r-vectors: ', nrshell
cg      print '(A,i)', '# of g-vectors: ', ngshell
C
      FE = ZERO
C
      DO 103 IG = 2, NGSHELL
         CF = DCMPLX(ZERO, ZERO)
         IATM = 0
         DO 104 IKND = 1, K_ATM
            IATM = IATM + N_KATM(IKND)
            QIKND  = Q_ATM(IATM)
            CF = CF + QIKND * CSG(IG,IKND)
 104     CONTINUE
C
         EXPS1_T = EXPS1(IG)
         FE = FE +  EXPS1_T * ABS(CF) ** 2
         QX = GG(IG,1)
         QY = GG(IG,2)
         QZ = GG(IG,3)
C
         DO 105 IATM = 1, N_ATM
            CF_T = CF - Q_ATM(IATM) * CONJG(CSG_ATM(IG,IATM))
            CSTR = CSG_ATM(IG,IATM) * Q_ATM(IATM) * EXPS1_T * CF_T
            F_ION(IATM,1) = F_ION(IATM,1) + AIMAG(CSTR) * QX
            F_ION(IATM,2) = F_ION(IATM,2) + AIMAG(CSTR) * QY
            F_ION(IATM,3) = F_ION(IATM,3) + AIMAG(CSTR) * QZ
cg	write(*,*) 'IATM',IATM
cg	write(*,*) 'CSTR',CSTR
cg	write(*,*) 'F_ION',F_ION(IATM,1),F_ION(IATM,2),F_ION(IATM,3)
cg	write(*,*) 'Q',QX,QY,QZ
cg	write(*,*) 'EXPS1_T',EXPS1_T
cg	write(*,*) 'CF_T',CF_T
cg	write(*,*) 'CSG_ATM',CSG_ATM(IG,IATM)
cg	write(*,*) 'Q_ATM',Q_ATM(IATM)
 105     CONTINUE
C     
 103  CONTINUE
C
      TOTME = 0.5D0 * PI8V * FE
c	write(*,*) 'TOTME1',TOTME

cg      write(*,*) 'f_ion in f_ewald'
cg      write(*,'(3E13.5)') f_ion(1:nOxygens+nHydrogens,:)

C     
      DO 106 IATM = 1, N_ATM
         F_ION(IATM,1) = PI8V * F_ION(IATM,1)
         F_ION(IATM,2) = PI8V * F_ION(IATM,2)
         F_ION(IATM,3) = PI8V * F_ION(IATM,3)
 106  CONTINUE
C     
      DO 107 IA1 = 2, N_ATM
C     
         R(1) = R_ATM(1,IA1)
         R(2) = R_ATM(2,IA1)
         R(3) = R_ATM(3,IA1)
C     
         POT = ZERO
         QIA1 = Q_ATM(IA1)
         F_TT1 = ZERO
         F_TT2 = ZERO
         F_TT3 = ZERO
C     
         DO 108 IA2 = 1, IA1 - 1
C     
            S = ZERO
            QIA2 = Q_ATM(IA2)
            QFOR = 2.0D0 * QIA1 * QIA2
cERB      QFOR = QIA1 * QIA2
C
            DO 109 IX = 1, 3
               RMT(IX) = R(IX) - R_ATM(IX,IA2)
 109        CONTINUE
C
            F_T1 = ZERO
            F_T2 = ZERO
            F_T3 = ZERO
C
            DO 110 IR = 1, NRSHELL
               X01 = RMT(1) - RSHELL(IR,1)
               Y01 = RMT(2) - RSHELL(IR,2)
               Z01 = RMT(3) - RSHELL(IR,3)
C
               R2 = X01**2 + Y01**2 + Z01**2
C     
               RSQ = SQRT(R2)
               R3 = R2 * RSQ
               GR = GPAR * RSQ
               GR2 = EXP(-GR*GR)
               T=1.0D0/(1.0D0+PA*GR)
               FERF = T*(A1+T*(A2+T*(A3+T*(A4+T*A5))))*GR2
               S1 = FERF / RSQ
               FR1 = FERF / R3
               FR2 = FAC3 * GR2 / R2
               FR = (FR1 + FR2) * QFOR
               S = S + S1
               F_T1 = F_T1 + FR * X01
               F_T2 = F_T2 + FR * Y01
               F_T3 = F_T3 + FR * Z01
 110        CONTINUE
C     
            F_TT1 = F_TT1 + F_T1
            F_TT2 = F_TT2 + F_T2
            F_TT3 = F_TT3 + F_T3
            F_ION(IA2,1) = F_ION(IA2,1) - F_T1
            F_ION(IA2,2) = F_ION(IA2,2) - F_T2
            F_ION(IA2,3) = F_ION(IA2,3) - F_T3
C     
            POT = POT + QIA2 * S
C     
 108     CONTINUE
C     
         F_ION(IA1,1) = F_ION(IA1,1) + F_TT1
         F_ION(IA1,2) = F_ION(IA1,2) + F_TT2
         F_ION(IA1,3) = F_ION(IA1,3) + F_TT3
C
         TOTME = TOTME + QIA1 * POT * 2.0D0
cg      write(*,*) 'TOTME2',TOTME
cERB      TOTME = TOTME + QIA1 * POT
C
 107  CONTINUE
C
C --- Adding in the constant terms
C
      TOTME = TOTME + ENN_G + ENN_R
c      write(*,*) 'TOTME3',TOTME
C
C
      END
C
C **************** GRPAR
C --- Determine the optimum value of G-parameter for the Madelung sum.
C --- Also determine corresponding number of R and G lattice vectors
C --- that must be included in the Madelung sum.
C
      SUBROUTINE grpar(r,g,rcut,gcut)
      INCLUDE 'dimen.prm'

      COMMON/E_TABLE/RSHELL(NUMR,3),EXPS1(NUMG),NR123(3),NG123(3)
      COMMON/E_CONST/GPAR,PI8V,ENN_R,ENN_G,FAC3,HAL(3)
      COMMON/CELL/Q_ATM(NAT),R_ATM(3,NAT),UNITCV,N_KATM(KAT),N_ATM,K_ATM
      COMMON/GVEC/GG(NUMG,4),GKA(NPLG,4,NKP),KG(NUMG,3),KA(NPLG,3,NKP)
cgo     &            IKDX(NPLG,NKP),IDEX(NX,NY,NZ)
      COMMON/G_WORK/GG_T(NUMG),GG_T1(NUMG),GG_T2(NUMG),GG_T3(NUMG),
     &              KG_T1(NUMG),KG_T2(NUMG),KG_T3(NUMG),INDEX(NUMG)
      COMMON/VPPL_R/CSG(NUMG,KAT),CSG_ATM(NUMG,NAT)
cgo      COMMON/VPPL_R/CSG(NUMG,KAT),CSG_ATM(NUMG,NAT),VPP_R(NX,NY,NZ)
      COMMON/EWALD/RLATT(3,3),GLATT(3,3),NSHELL

cg      INCLUDE 'cgscf.com'

      DIMENSION R(3,3)
      REAL *8 rcut, gcut

cERB      DATA PI,FAC/3.14159265358979D0, 12.0D0/
C
C --- Fac is a factor that controles the convergence.  Larger Fac
C     gives larger numvers of R- and G- lattice vector in the sum
C     and hence better convergence( but more computation).
C    Errors are of order exp(-FAC^2).
C    Note change made here - n_atm and k_atm factors in g
C    Also double precision cutoffs, not integer.
C    and use of unit cell volume instead of prod of |r_i|
C
C
cERB      sixth = 1.0D0 / 6.0D0
cERBC
cERB      g = pi*pi*pi*n_atm*n_atm/(unitcv*unitcv*k_atm)
cERB      g = g**sixth
cERB      rcut = fac/g
cERB      gcut = fac*g

      gcut = 5.0d0/unitcv**(1.0d0/3.0d0)
c	write(*,*) 'gcut',gcut
cERB      rcut = 0.5d0/gcut
cERB
cERB      print '(A,f20.10)', 'rCut = ', rcut
cERB      print '(A,f20.10)', 'gCut = ', gcut

      RETURN
      END


