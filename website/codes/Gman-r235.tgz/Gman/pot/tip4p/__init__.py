__doc__ = '''tip4p water potential'''

from tip4p import init, force
