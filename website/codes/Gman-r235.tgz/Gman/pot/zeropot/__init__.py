__doc__ = '''zero potential potential.'''

from zeropot import *
