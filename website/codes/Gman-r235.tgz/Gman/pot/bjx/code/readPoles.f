c-----------------------------------------------------------------------
      subroutine readPoles(dpole, qpole, opole, hpole)

C Modified by Fer
      implicit none

      integer   IBUFFER
      parameter (IBUFFER = 256)
      character(LEN=IBUFFER) line
      integer*4 iUnit
      integer*4 ios

      integer*4 i
      integer*4 p, q, r, s
      integer*4 nC
      real*8    kk1, kk2, Val
      real*8 dpole(3), qpole(3,3), opole(3,3,3), hpole(3,3,3,3)

CAA
      REAL*8 kka
CAA

C Initialize the multipole moments
      do p=1,3
        dpole(p) = 0.0D0
        do q=1,3
          qpole(p,q) = 0.0D0
          do r=1,3
            opole(p,q,r) = 0.0D0
            do s=1,3
              hpole(p,q,r,s) = 0.0D0
            end do
          end do
        end do
      end do

C au to Debye constant
      kk1 = 2.5417709D0

C Ang to au constant
      kk2 = 1.88972666351031921149

CAA The dipole moment components
      kka = kk1
      dpole(3) = -0.72981d0 * kka

CAA The quadrupole moment components
      kka = kka/kk2
      qpole(1,1) =  1.95532d0 * kka
      qpole(2,2) = -1.85867d0 * kka
      qpole(3,3) = -0.09665d0 * kka

CAA The octupole moment components
      kka = kka/kk2
      opole(1,1,3) = -3.27190d0 * kka
      opole(2,2,3) =  1.36606d0 * kka
      opole(3,3,3) =  1.90585d0 * kka

CAA The hexadecapole moment components
      kka = kka/kk2
      hpole(1,1,1,1) = -0.94903d0 * kka
      hpole(1,1,2,2) = -3.38490d0 * kka
      hpole(1,1,3,3) =  4.33393d0 * kka
      hpole(2,2,2,2) =  4.09835d0 * kka
      hpole(2,2,3,3) = -0.71345d0 * kka
      hpole(3,3,3,3) = -3.62048d0 * kka

CAA C Open the multipoles file
CAA      iUnit = 55
CAA       open(iUnit, file="multipoles", status="old")

CAA C Read the dipole moment components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, Val
CAA        dpole(p) = Val*kk1
CAA      end do

CAA C Read the quadrupole moment components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, Val
CAA        qpole(p,q) = Val*kk1/kk2
CAA     end do

CAA C Read the octupole moment components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, r, Val
CAA        opole(p,q,r) = Val*kk1/(kk2)**2
CAA      end do

CAA C Read the hexadecapole moment components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, r, s, Val
CAA        hpole(p,q,r,s) = Val*kk1/(kk2)**3
CAA      end do

C Enforce the symmetry constraints
C Note: Symmetry constraints are only enforced for non-zero
C       components in water

      opole(1,3,1) = opole(1,1,3)
      opole(3,1,1) = opole(1,1,3)
      opole(2,3,2) = opole(2,2,3)
      opole(3,2,2) = opole(2,2,3)

      hpole(1,2,1,2) = hpole(1,1,2,2)
      hpole(1,2,2,1) = hpole(1,1,2,2)
      hpole(2,1,1,2) = hpole(1,1,2,2)
      hpole(2,1,2,1) = hpole(1,1,2,2)
      hpole(2,2,1,1) = hpole(1,1,2,2)
      hpole(1,3,1,3) = hpole(1,1,3,3)
      hpole(1,3,3,1) = hpole(1,1,3,3)
      hpole(3,1,1,3) = hpole(1,1,3,3)
      hpole(3,1,3,1) = hpole(1,1,3,3)
      hpole(3,3,1,1) = hpole(1,1,3,3)
      hpole(2,3,2,3) = hpole(2,2,3,3)
      hpole(2,3,3,2) = hpole(2,2,3,3)
      hpole(3,2,2,3) = hpole(2,2,3,3)
      hpole(3,2,3,2) = hpole(2,2,3,3)
      hpole(3,3,2,2) = hpole(2,2,3,3)
        
CAA A Close the multipoles file
CAA      close(iUnit)

      end

c-----------------------------------------------------------------------
c     This routine extracts the next uncommented line from a file. The
c     comments are specified by starting the line with a '#' sign

      subroutine getLine(unit, line, ios)

      parameter (IBUFFER = 256)
      integer unit, ios
c      character(LEN=IBUFFER) line, fmt
      character*256 line, fmt
      character*1 first

c      write(fmt, 100) IBUFFER
c 100  format('(A',i3.3,')')

      write(fmt, '("(A",i3.3,")")') IBUFFER

      read(unit, fmt, IOSTAT=ios, end=200, err=200) line
      read(line, '(A1)') first
      do while (first .eq. '#')
         read(unit, fmt, IOSTAT=ios, end=200, err=200) line
         read(line, '(A1)') first
      end do

 200  return
      end
