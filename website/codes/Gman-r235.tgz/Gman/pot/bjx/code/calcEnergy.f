      subroutine calcEnergy(dpole, qpole, opole, hpole, d1v, d2v, d3v,
     $     d4v, nM, uTot)

      implicit none
      include 'commonblks/parameters.cmn'
      
c     Work multipoles. They start unpolarized and with the induction
c     loop we induce dipoles and quadrupoles.
      real*8 dpole(3,maxCoo/3), qpole(3,3,maxCoo/3)
      real*8 opole(3,3,3,maxCoo/3), hpole(3,3,3,3,maxCoo/3)

c     High order derivatives of the potential
      real*8 d1v(3,maxCoo/3), d2v(3,3,maxCoo/3), d3v(3,3,3,maxCoo/3)
      real*8 d4v(3,3,3,3,maxCoo/3), uTot, ud, uq, uo, uh, du

      integer nM

      integer n, i, j, k, l, s
      real*8 u

      uTot = 0.d0
      ud = 0.d0
      uq = 0.d0
      uo = 0.d0
      uh = 0.d0

      do n = 1, nM

         do i = 1, 3
c     Energy of the dipole
            du = d1v(i,n) * dpole(i,n)
            uTot = uTot + du
            ud = ud + du
            do j = 1, 3
c     Energy of the quadrupole
               du = d2v(j,i,n)*qpole(j,i,n) / 3.d0
               uTot = uTot + du
               uq = uq + du
               do k = 1, 3
c     Energy of the octopole
                  du = d3v(k,j,i,n)*opole(k,j,i,n) / 15.d0
                  uTot = uTot + du
                  uo = uo + du

                  do l = 1, 3
c     Energy of the hexadecapole
                     du = d4v(l,k,j,i,n)*hpole(l,k,j,i,n) / 105.d0 
                     uTot = uTot + du
                     uh = uh + du
                  end do
               end do
            end do

         end do
      end do
      uTot = uTot / 2.d0
      
      ud = ud / 2.d0
      uq = uq / 2.d0
      uo = uo / 2.d0
      uh = uh / 2.d0

      return
      end
c-----------------------------------------------------------------------
CAA      subroutine calcEnergyI(dpole, dpole0, qpole, qpole0, opole, hpole,
CAA     $     d1v, d2v, d3v, d4v, nM, uTot)  
CAA
CAA      implicit none
CAA      include 'commonblks/parameters.cmn'
CAA      
CAAc     Work multipoles. They start unpolarized and with the induction
CAAc     loop we induce dipoles and quadrupoles.
CAA      real*8 dpole(3,maxCoo/3), qpole(3,3,maxCoo/3)
CAA      real*8 dpole0(3,maxCoo/3), qpole0(3,3,maxCoo/3)
CAA      real*8 opole(3,3,3,maxCoo/3), hpole(3,3,3,3,maxCoo/3)
CAA
CAAc     High order derivatives of the potential
CAA      real*8 d1v(3,maxCoo/3), d2v(3,3,maxCoo/3), d3v(3,3,3,maxCoo/3)
CAA      real*8 d4v(3,3,3,3,maxCoo/3), uTot
CAA
CAA      integer nM
CAA
CAA      integer n, i, j, k, l, s
CAA      real*8 u
CAA
CAA      uTot = 0.d0
CAA      do n = 1, nM
CAA
CAA         do i = 1, 3
CAAc     Energy of the dipole
CAA            uTot = uTot + d1v(i,n) * (dpole(i,n) - dpole0(i,n))
CAA            do j = 1, 3
CAAc     Energy of the quadrupole
CAA               uTot = uTot + d2v(j,i,n)*(qpole(j,i,n)-qpole0(j,i,n)) / 
CAA     $              3.d0 
CAA            end do
CAA            
CAA         end do
CAA      end do
CAA      uTot = uTot / 2.d0
CAA
CAA      return
CAA      end
c-----------------------------------------------------------------------
CAA      subroutine polarizationEnergy1(hp, dpole, dpole0, qpole, qpole0,
CAA     $     d1v, d2v, nM, uPol)
CAA
CAA      implicit none
CAA      include 'commonblks/parameters.cmn'
CAA      
CAAc     Work multipoles. They start unpolarized and with the induction
CAAc     loop we induce dipoles and quadrupoles.
CAA      real*8 dpole(3,maxCoo/3), qpole(3,3,maxCoo/3)
CAA      real*8 dpole0(3,maxCoo/3), qpole0(3,3,maxCoo/3)
CAA
CAAc     High order derivatives of the potential
CAA      real*8 d1v(3,maxCoo/3), d2v(3,3,maxCoo/3), uPol
CAA      real*8 hp(3,3,3,maxCoo/3) 
CAA
CAA      integer i, j, k, nM
CAA
CAA      integer n
CAA      real*8 u
CAA
CAA      uPol = 0.d0
CAA      do n = 1, nM
CAAc     Dipole polarization
CAA         u = -0.5d0 * ( (dpole(1,n)-dpole0(1,n)) * d1v(1,n) + 
CAA     $        (dpole(2,n)-dpole0(2,n)) * d1v(2,n) +
CAA     $        (dpole(3,n)-dpole0(3,n)) * d1v(3,n) )
CAA         uPol = uPol + u
CAA
CAA      end do
CAA
CAA      return
CAA      end
c-----------------------------------------------------------------------
CAA      subroutine polarizationEnergy(dd, dq, qq, hp, d1v, d2v, nM, uPol)
CAA
CAA      implicit none
CAA      include 'commonblks/parameters.cmn'
CAA      
CAAc     Work multipoles. They start unpolarized and with the induction
CAAc     loop we induce dipoles and quadrupoles.
CAA
CAAc     High order derivatives of the potential
CAA      real*8 d1v(3,maxCoo/3), d2v(3,3,maxCoo/3), uPol
CAA      real*8 dd(3,3,maxCoo/3), dq(3,3,3,maxCoo/3), hp(3,3,3,maxCoo/3)
CAA      real*8 qq(3,3,3,3,maxCoo/3)
CAA
CAA      integer i, j, k, l, nM
CAA
CAA      integer n
CAA      real*8 u
CAA
CAA      uPol = 0.d0
CAA      do n = 1, nM
CAA
CAAc     Dipole-dipole polarization
CAA         do i = 1, 3
CAA            do j = 1, 3
CAA               uPol = uPol + 0.5d0 * dd(i,j,n) *d1v(i,n)*d1v(j,n)
CAA
CAAc     Dipole-quadrupole polarization
CAA               do k = 1, 3
CAA                  uPol = uPol + dq(i,j,k,n) *d1v(i,n)*d2v(j,k,n) / 3.d0
CAA
CAAc     Quadrupole-quadrupole polarization
CAA                  do l = 1, 3
CAA                     uPol = uPol + qq(i,j,k,l,n) *d2v(i,j,n)*d2v(k,l,n)
CAA     $                    / 6.d0
CAA                  end do
CAA
CAAc     first hyperpolarization
CAAc                  uPol = uPol - hp(i,j,k,n) * d1v(i,n)*d1v(j,n)*d1v(k,n)
CAAc     $                 / 6.d0 
CAA               end do
CAA            end do
CAA         end do
CAA      end do
CAA
CAA      return
CAA     end
CAA
