c-----------------------------------------------------------------------
      subroutine readPolariz(dd, dq, hp, qq)

C Modified by Fer
      implicit none

      integer   IBUFFER
      parameter (IBUFFER = 256)
      character(LEN=IBUFFER) line
      integer*4 iUnit
      integer*4 ios

      integer i
      integer*4 p, q, r, s
      integer*4 nC
      real*8    kk1, kk2, Val
      real*8 dd(3,3), dq(3,3,3), hp(3,3,3), qq(3,3,3,3), scale

CAA
      REAL*8 kka
CAA

C Initialize the polarizabilities
      do p=1,3
        do q=1,3
          dd(p,q) = 0.0D0
          do r=1,3
            hp(p,q,r) = 0.0D0
            dq(p,q,r) = 0.0D0
            do s=1,3
              qq(p,q,r,s) = 0.0D0
            end do
          end do
        end do
      end do

CAA C Open the polarizabilities file
CAA      iUnit = 55
CAA      open(iUnit, file="polar", status="old")
      ios = 0

CAA C au to Debye constant
CAA       kk1 = 2.5417709D0

C Ang to au constant
      kk2 = 1.88972666351031921149

CAA
      kka = kk2**3
CAA

CAA The dipole-dipole polarizability components
      dd(1,1) = 10.31146d0 / kka
      dd(2,2) =  9.54890d0 / kka
      dd(3,3) =  9.90656d0 / kka

CAA The dipole-quadrupole polarizability components
      kka = kka*kk2
      dq(1,1,3) = -8.42037d0 / kka
      dq(2,2,3) = -1.33400d0 / kka
      dq(3,1,1) = -2.91254d0 / kka
      dq(3,2,2) =  4.72407d0 / kka
      dq(3,3,3) = -1.81153d0 / kka

CAA The quadrupole-quadrupole polarizability components
      kka = kka*kk2
      qq(1,1,1,1) = 12.11907d0 / kka
      qq(1,1,2,2) = -6.95326d0 / kka
      qq(1,1,3,3) = -5.16582d0 / kka
      qq(1,2,1,2) =  7.86225d0 / kka
      qq(1,3,1,3) = 11.98862d0 / kka
      qq(2,2,2,2) = 11.24741d0 / kka
      qq(2,2,3,3) = -4.29415d0 / kka
      qq(2,3,2,3) =  6.77226d0 / kka
      qq(3,3,3,3) =  9.45997d0 / kka

CAA C Read the dipole-dipole polarizability components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, Val
CAA        dd(p,q) = Val/(kk2)**3
CAA      end do

CAA C Read the dipole-quadrupole polarizability components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, r, Val
CAA        dq(p,q,r) = Val/(kk2)**4
CAA      end do

CAA C Read the quadrupole-quadrupole polarizability components
CAA      call getLine(iUnit, line, ios)
CAA      read(line, *) nC
CAA
CAA      do i=1,nC
CAA        call getLine(iUnit, line, ios)
CAA        read(line, *) p, q, r, s, Val
CAA        qq(p,q,r,s) = Val/(kk2)**5
CAA      end do

C Enforce the symmetry constraints
C Note: Symmetry constraints are only enforced for non-zero
C       components in water

      dq(1,3,1) = dq(1,1,3)
      dq(2,3,2) = dq(2,2,3)

      qq(2,2,1,1) = qq(1,1,2,2)
      qq(3,3,1,1) = qq(1,1,3,3)
      qq(3,3,2,2) = qq(2,2,3,3)
      qq(1,2,2,1) = qq(1,2,1,2)
      qq(2,1,1,2) = qq(1,2,1,2)
      qq(2,1,2,1) = qq(1,2,1,2)
      qq(1,3,3,1) = qq(1,3,1,3)
      qq(3,1,1,3) = qq(1,3,1,3)
      qq(3,1,3,1) = qq(1,3,1,3)
      qq(2,3,3,2) = qq(2,3,2,3)
      qq(3,2,2,3) = qq(2,3,2,3)
      qq(3,2,3,2) = qq(2,3,2,3)

CAA C Close the polarizabilities file
CAA      close(iUnit)

      end

