C AA 10-11-2004
C Hard code the potential parameters in

      SUBROUTINE potinit()
        IMPLICIT NONE
        INTEGER i,j
        CHARACTER(LEN=80) text

        INCLUDE 'commonblks/potparam.cmn'
        INCLUDE 'commonblks/compotent.cmn'           

C The old environmental variables
        fsti(1)  =  4.40000d0
        fsti(2)  = -1.44350d0
        fsti(3)  =  20169.17400d0
        fsti(4)  = -3.46581d0
        fsti(5)  =  1.00000d0
        fsti(6)  = -1.00000d0
        fsti(7)  =  1.0250853530d-01
        fsti(8)  = -1.7246118649d-04
        fsti(9)  =  1.0219555575d-07
        fsti(10) = -2.6087710711d-11
        fsti(11) =  3.0605430553d-15
        fsti(12) = -1.3290133918d-19
        fsti(13) =  0.0000000000d+00
        fsti(14) =  5

C Variables from the inp.dat file
        rcut(1) = 3.0d0
        rcut(2) = 3.0d0
        rcut(3) = 3.0d0
        rskin(1) = 3.0d0
        rskin(2) = 3.0d0
        rskin(3) = 3.0d0
        indf1 = 1
        DO  i=1,3
          rcut2(i)=rcut(i)**2
          rskin2(i)=rskin(i)**2
        END DO

        npotpar=15
        DO i=1,npotpar
          DO j=1,3
            potpar(i,j) = 0.0d0
          END DO
        END DO
        potpar(1,2)  = -10.687d0
        potpar(2,1)  =   1.0d0
        potpar(3,1)  =   0.9572d0
        potpar(4,1)  = 104.52d0
        potpar(9,1)  =   2.68d0
        potpar(9,2)  =   3.5d0
        potpar(9,3)  =   3.8d0
        potpar(10,2) =   4.0d0
        potpar(10,3) =   2.0d0
        potpar(14,1) =   0.9572d0
        potpar(15,1) = 104.52d0
      
      END 
