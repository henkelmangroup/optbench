__doc__ = '''BJX water potential'''

from bjx import init, force
