! -*- f90 -*-
      SUBROUTINE FORCE(N,R,F,U,B1,B2,B3,UAA,SAA,UBB,SBB,UAB,SAB,RC,NA)
      USE geometry
      IMPLICIT NONE
      INTEGER N
      DOUBLE PRECISION R(3*N)
      DOUBLE PRECISION F(3*N)
      DOUBLE PRECISION U(1)
      DOUBLE PRECISION UAA,UBB,UAB
      DOUBLE PRECISION SAA,SBB,SAB
      DOUBLE PRECISION UUAA,UUBB,UUAB
      DOUBLE PRECISION RC, RCsq
      DOUBLE PRECISION B1(3), B2(3), B3(3) !box
      DOUBLE PRECISION BOX(3,3) !box
      DOUBLE PRECISION R_IJ_X, R_IJ_Y, R_IJ_Z, R_IJ, VEC_R_IJ(3)
      DOUBLE PRECISION iRsq,iRs2, iRs6, iRs12
      DOUBLE PRECISION UU, DUU
      DOUBLE PRECISION SHIFTAA,SHIFTBB,SHIFTAB
      DOUBLE PRECISION minR(3)
      INTEGER I,J,NA

      BOX(:,1) = B1
      BOX(:,2) = B2
      BOX(:,3) = B3
      call init_g(BOX)
      
      ! two atom lj pot taken from 
      ! Peng, X.Q. Composites: Part A 36 (2005) 859-874
      RCsq=RC*RC
      iRs2=SAA*SAA/(RCsq)
      iRs6=iRs2*iRs2*iRs2
      iRs12=iRs6*iRs6
      SHIFTAA=(iRs12-iRs6)
      iRs2=SBB*SBB/(RCsq)
      iRs6=iRs2*iRs2*iRs2
      iRs12=iRs6*iRs6
      SHIFTBB=(iRs12-iRs6)
      iRs2=SAB*SAB/(RCsq)
      iRs6=iRs2*iRs2*iRs2
      iRs12=iRs6*iRs6
      SHIFTAB=(iRs12-iRs6)
!      UU_SHIFT=UU_SHIFT*UU_SHIFT-DBLE(2.0)*UU_SHIFT
      U(1)=DBLE(0.0)
      UUAA=DBLE(0.0)
      UUBB=DBLE(0.0)
      UUAB=DBLE(0.0)
      ! loop all over first atom type AA
      !DO I=1, N-1
      !  DO J=I+1, N
      DO I=1, NA-1
        DO J=I+1, NA
          R_IJ_X=R(3*I-2)-R(3*J-2)
          R_IJ_Y=R(3*I-1)-R(3*J-1)
          R_IJ_Z=R(3*I)-R(3*J)
          VEC_R_IJ(1)=R_IJ_X 
          VEC_R_IJ(2)=R_IJ_Y 
          VEC_R_IJ(3)=R_IJ_Z 
          call wigner_seitz_cell(VEC_R_IJ,minR) !find the shortest distance to apply PBC
          R_IJ_X=minR(1)
          R_IJ_Y=minR(2)
          R_IJ_Z=minR(3)
          R_IJ=R_IJ_X*R_IJ_X+R_IJ_Y*R_IJ_Y+R_IJ_Z*R_IJ_Z
          IF(R_IJ<=RCsq) THEN
            iRsq=DBLE(1.0)/R_IJ
            iRs2=SAA*SAA*iRsq
            iRs6=iRs2*iRs2*iRs2
            iRs12=iRs6*iRs6
            UU=(iRs12-iRs6)
            DUU=(DBLE(12.0)*iRs12-DBLE(6.0)*iRs6)*iRsq
            F(3*I-2)=F(3*I-2)+DUU*R_IJ_X*UAA
            F(3*I-1)=F(3*I-1)+DUU*R_IJ_Y*UAA
            F(3*I)=F(3*I)+DUU*R_IJ_Z*UAA
            F(3*J-2)=F(3*J-2)-DUU*R_IJ_X*UAA
            F(3*J-1)=F(3*J-1)-DUU*R_IJ_Y*UAA
            F(3*J)=F(3*J)-DUU*R_IJ_Z*UAA
            UUAA=UUAA+UU-SHIFTAA
            !U(1)=U(1)+UU-SHIFTAA
          END IF
        END DO
      END DO
      ! loop all over second atom type BB
      DO I=NA+1, N-1
        DO J=I+1, N
          R_IJ_X=R(3*I-2)-R(3*J-2)
          R_IJ_Y=R(3*I-1)-R(3*J-1)
          R_IJ_Z=R(3*I)-R(3*J)
          VEC_R_IJ(1)=R_IJ_X 
          VEC_R_IJ(2)=R_IJ_Y 
          VEC_R_IJ(3)=R_IJ_Z 
          call wigner_seitz_cell(VEC_R_IJ,minR) !find the shortest distance to apply PBC
          R_IJ_X=minR(1)
          R_IJ_Y=minR(2)
          R_IJ_Z=minR(3)
          R_IJ=R_IJ_X*R_IJ_X+R_IJ_Y*R_IJ_Y+R_IJ_Z*R_IJ_Z
          IF(R_IJ<=RCsq) THEN
            iRsq=DBLE(1.0)/R_IJ
            iRs2=SBB*SBB*iRsq
            iRs6=iRs2*iRs2*iRs2
            iRs12=iRs6*iRs6
            UU=(iRs12-iRs6)
            DUU=(DBLE(12.0)*iRs12-DBLE(6.0)*iRs6)*iRsq
            F(3*I-2)=F(3*I-2)+DUU*R_IJ_X*UBB
            F(3*I-1)=F(3*I-1)+DUU*R_IJ_Y*UBB
            F(3*I)=F(3*I)+DUU*R_IJ_Z*UBB
            F(3*J-2)=F(3*J-2)-DUU*R_IJ_X*UBB
            F(3*J-1)=F(3*J-1)-DUU*R_IJ_Y*UBB
            F(3*J)=F(3*J)-DUU*R_IJ_Z*UBB
            UUBB=UUBB+UU-SHIFTBB
          END IF
        END DO
      END DO
      ! loop all over first atom type AB
      DO I=1, NA
        DO J=NA+1, N
          R_IJ_X=R(3*I-2)-R(3*J-2)
          R_IJ_Y=R(3*I-1)-R(3*J-1)
          R_IJ_Z=R(3*I)-R(3*J)
          VEC_R_IJ(1)=R_IJ_X 
          VEC_R_IJ(2)=R_IJ_Y 
          VEC_R_IJ(3)=R_IJ_Z 
          call wigner_seitz_cell(VEC_R_IJ,minR) !find the shortest distance to apply PBC
          R_IJ_X=minR(1)
          R_IJ_Y=minR(2)
          R_IJ_Z=minR(3)
          R_IJ=R_IJ_X*R_IJ_X+R_IJ_Y*R_IJ_Y+R_IJ_Z*R_IJ_Z
          IF(R_IJ<=RCsq) THEN
            iRsq=DBLE(1.0)/R_IJ
            iRs2=SAB*SAB*iRsq
            iRs6=iRs2*iRs2*iRs2
            iRs12=iRs6*iRs6
            UU=(iRs12-iRs6)
            DUU=(DBLE(12.0)*iRs12-DBLE(6.0)*iRs6)*iRsq
            F(3*I-2)=F(3*I-2)+DUU*R_IJ_X*UAB
            F(3*I-1)=F(3*I-1)+DUU*R_IJ_Y*UAB
            F(3*I)=F(3*I)+DUU*R_IJ_Z*UAB
            F(3*J-2)=F(3*J-2)-DUU*R_IJ_X*UAB
            F(3*J-1)=F(3*J-1)-DUU*R_IJ_Y*UAB
            F(3*J)=F(3*J)-DUU*R_IJ_Z*UAB
            UUAB=UUAB+UU-SHIFTAB
          END IF
        END DO
      END DO
      !DO I=1, 3*N
      !  F(I)=F(I)*U0
      !END DO
      !U(1)=UUAA*UAA
      U(1)=U(1)+UUAA*UAA+UUBB*UBB+UUAB*UAB

      END SUBROUTINE FORCE


