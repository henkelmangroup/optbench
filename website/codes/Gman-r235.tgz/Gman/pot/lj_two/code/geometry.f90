! -*- f90 -*-
MODULE geometry
  !Usage: call init_g(box) to initialize the global variables
  !       call wigner_seitz_cell(vr,minvr) to get the image of given vector vr within the wigner_seitz cell
  !Tools: reduce_lattice,cross_product,cartesian2direct,norm
  !Version 1, by Penghao 05/24/2010
  DOUBLE PRECISION reciprocal_box(3,3)
  DOUBLE PRECISION realbox_volume
  DOUBLE PRECISION reduced_lattice(3,3)
  DOUBLE PRECISION dp_redslat(3) !dot product of reduced lattice v1v2,v1v3,v2v3, got from reduce_lattice, used in wigner_seitz_cell
  DOUBLE PRECISION norm2_redslat(3) !square of norm of reduced lattice, got from reduce_lattice, used in wigner_seitz_cell

CONTAINS

  SUBROUTINE init_g(box)
    IMPLICIT NONE
    DOUBLE PRECISION,INTENT(in)  :: box(3,3)
    !requires: box vectors in cartesian.
    !effects:  initialize some box data that only need to be calculated once.
    call reduce_lat(box,reduced_lattice)
    call ibox(box,reciprocal_box,realbox_volume)
  END SUBROUTINE init_g

  SUBROUTINE ibox(box,rep_box,volume)
    IMPLICIT NONE
    DOUBLE PRECISION,INTENT(in)  :: box(3,3)
    DOUBLE PRECISION,INTENT(out) :: rep_box(3,3)
    DOUBLE PRECISION,INTENT(out) :: volume
    !reciprocal box and volume are used in getting direct coordinates, c2d
    DOUBLE PRECISION a(3), b(3), c(3)
    a = box(:,1)
    b = box(:,2)
    c = box(:,3)
    rep_box(:,1) = cross_product(b,c)
    rep_box(:,2) = cross_product(c,a)
    rep_box(:,3) = cross_product(a,b)
    volume = dot_product(rep_box(:,1),a)
    volume = abs(volume)
  END SUBROUTINE ibox
  
  SUBROUTINE reduce_lat(box,reds_lat)
    IMPLICIT NONE
    DOUBLE PRECISION,INTENT(in)  :: box(3,3)
    DOUBLE PRECISION,INTENT(out) :: reds_lat(3,3)
    !requires: box vectors in cartesian.
    !effects:  return the reduced lattice vectors, v1,v2,v3, which are the 3 shortest ones in different directions. 
    !          That is if |v1|<|v2|<|v3| then |v2+x1*v1|>=|v2|, |v3+x2*v2+x1*v1|>=|v3|. 
    !          Also, the dot products of the reduced lattice vectors are given.
    !methods:  The necessary condition is dot_product(vi,vj)/norm(vi)**2<=0.5 for i,j={1,2,3}. 
    !          Including one special case it can become sufficient. 
    !          For example: (1,0,0),(0.5,sqrt(3.0)/2,0),(0.5,-sqrt(3.0)/2,0.3), satisfy, but exists a=v3+v2-v1, |a|<1 
    !See Igor Semaev,"A 3-Dimensional Lattice Reduction Algorithm" Algorithm 2 on page 185.
    DOUBLE PRECISION cbox(3,3) !copy of box
    DOUBLE PRECISION a(3), b(3), c(3),tmp(3)
    DOUBLE PRECISION proj 
    DOUBLE PRECISION nt1,nt2,nt3
    DOUBLE PRECISION dp12,dp13,dp23
    DOUBLE PRECISION,parameter:: TOL=1E-5
    INTEGER i,j
    INTEGER eps12,eps13,eps23 !the sign of dot products of the reduced lattice vectors
    LOGICAL complete

    cbox=box

    DO WHILE(.NOT.complete)
      complete = .TRUE.
      DO i=1,2
        DO j=i+1,3
          a = cbox(:,i)
          b = cbox(:,j)
          proj = dot_product(b,a)/dot_product(a,a)
          b = b - DNINT(proj)*a
          complete = complete.AND.(abs(proj)<0.5+TOL)
          !Given (b,a)<=0.5|a|**2, moving a to a-b will not affect this inequality. The proof is on 5/21/2010's notes.
          proj = dot_product(b,a)/dot_product(b,b)
          a = a - DNINT(proj)*b
          complete = complete.AND.(abs(proj)<0.5+TOL)
          cbox(:,i) = a
          cbox(:,j) = b
        END DO
      END DO
    END DO

    a = cbox(:,1)
    b = cbox(:,2)
    c = cbox(:,3)
    dp12  = dot_product(a,b)
    eps12 = sign(1.0d0,dp12)
    dp13  = dot_product(a,c)
    eps13 = sign(1.0d0,dp13)
    dp23  = dot_product(b,c)
    eps23 = sign(1.0d0,dp23)
    !The special case.
    IF(eps12*eps13*eps23 == -1)THEN
      tmp = a - eps12*b - eps13*c
      print*,tmp
      nt1 = norm(tmp)
      nt2 = max(norm(a),norm(b),norm(c))
      IF(nt1<nt2)THEN
        DO i=1,3
          nt3 = norm(cbox(:,i))
          IF(abs(nt3-nt2)<=TOL)THEN
            cbox(:,i) = tmp
          END IF
        END DO
      END IF
    END IF

    a = cbox(:,1)
    b = cbox(:,2)
    c = cbox(:,3)
    dp12  = dot_product(a,b)
    dp13  = dot_product(a,c)
    dp23  = dot_product(b,c)
    nt1 = dot_product(a,a)
    nt2 = dot_product(b,b)
    nt3 = dot_product(c,c)
    !output
    reds_lat = cbox
    dp_redslat = (/dp12,dp13,dp23/)
    norm2_redslat = (/nt1,nt2,nt3/)
  END SUBROUTINE reduce_lat
  
  SUBROUTINE wigner_seitz_cell(vr,minvr)
    IMPLICIT NONE
    DOUBLE PRECISION,INTENT(in) :: vr(3)
    DOUBLE PRECISION,INTENT(out):: minvr(3)
    !requires: a vector in cartesian coordinates, reduced lattice and the 3 signs of dot products of lattice vectors
    !effects:  return the new cartesian coordinates of the vector, whose norm is the shortest among all images.
    !methods:  using reduced lattice v1 v2 v3, the nearest neighbors of a lattice point is defined by {vi}, {vi+vj} and {vi+vj+vk}. 
    !          dot_product(vr,vnn)/|vnn|**2<=0.5 for all vnn means vr is within the wigner_seitz_cell.
    !          vnn is the vetor pointing to a nearing neighbor. Just need to test vnn in the same quadrant.
    DOUBLE PRECISION dr(3) !direct coordinates
    DOUBLE PRECISION v1(3),v2(3),v3(3)
    DOUBLE PRECISION t1(3),t2(3),t3(3)
    DOUBLE PRECISION tmp(3)
    DOUBLE PRECISION dp12,dp13,dp23
    DOUBLE PRECISION proj 
    INTEGER e1,e2,e3 !quadrant of vr. First quadrant (1,1,1)... 

    v1 = reduced_lattice(:,1)
    v2 = reduced_lattice(:,2)
    v3 = reduced_lattice(:,3)
    dr = c2d(vr)
    e1 = sign(1.0d0,dr(1))
    e2 = sign(1.0d0,dr(2))
    e3 = sign(1.0d0,dr(3))
    t1 = e1*v1
    t2 = e2*v2
    t3 = e3*v3
    minvr = vr
    proj  = dot_product(minvr,t1)/norm2_redslat(1)
    minvr = minvr - DNINT(proj)*t1
    proj  = dot_product(minvr,t2)/norm2_redslat(2)
    minvr = minvr - DNINT(proj)*t2
    proj  = dot_product(minvr,t3)/norm2_redslat(3)
    minvr = minvr - DNINT(proj)*t3

    dp12  = dp_redslat(1)*e1*e2
    dp13  = dp_redslat(2)*e1*e3
    dp23  = dp_redslat(3)*e2*e3
    IF(dp12<0)THEN
      tmp = t1+t2
      proj  = dot_product(minvr,tmp)/dot_product(tmp,tmp)
      minvr = minvr - DNINT(proj)*tmp
    END IF
    IF(dp13<0)THEN
      tmp = t1+t3
      proj  = dot_product(minvr,tmp)/dot_product(tmp,tmp)
      minvr = minvr - DNINT(proj)*tmp
    END IF
    IF(dp23<0)THEN
      tmp = t2+t3
      proj  = dot_product(minvr,tmp)/dot_product(tmp,tmp)
      minvr = minvr - DNINT(proj)*tmp
    END IF
    IF((dp12+dp23<0).AND.(dp12+dp13<0).AND.(dp12+dp23<0))THEN
      tmp = t1+t2+t3
      proj  = dot_product(minvr,tmp)/dot_product(tmp,tmp)
      minvr = minvr - DNINT(proj)*tmp
    END IF
  END SUBROUTINE wigner_seitz_cell

  FUNCTION c2d(vr)
    IMPLICIT NONE
    DOUBLE PRECISION vr(3)
    DOUBLE PRECISION c2d(3)
    !transfer cartesian vr to direct c2d
    DOUBLE PRECISION ia(3), ib(3), ic(3)
    ia = reciprocal_box(:,1)
    ib = reciprocal_box(:,2)
    ic = reciprocal_box(:,3)
    c2d(1) = dot_product(ia,vr)/realbox_volume
    c2d(2) = dot_product(ib,vr)/realbox_volume
    c2d(3) = dot_product(ic,vr)/realbox_volume
  END FUNCTION c2d

  FUNCTION cross_product(a,b) 
    IMPLICIT NONE
    DOUBLE PRECISION a(3),b(3)
    DOUBLE PRECISION cross_product(3)
    cross_product(1)=a(2)*b(3)-a(3)*b(2)
    cross_product(2)=a(3)*b(1)-a(1)*b(3)
    cross_product(3)=a(1)*b(2)-a(2)*b(1)
  END FUNCTION cross_product

  FUNCTION norm(vec)
    IMPLICIT NONE
    DOUBLE PRECISION vec(3)
    DOUBLE PRECISION norm
    norm = dot_product(vec,vec)
    norm = sqrt(norm)
  END FUNCTION norm

END MODULE geometry

