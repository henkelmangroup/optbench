__doc__ = '''Lennard-Jones potential.'''

from lj_two import *
