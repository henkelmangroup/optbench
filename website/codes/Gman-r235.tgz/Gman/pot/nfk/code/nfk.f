      SUBROUTINE FORCE(N, R, F, U)
      INTEGER N
      DOUBLE PRECISION R(3*N)
      DOUBLE PRECISION F(3*N)
      DOUBLE PRECISION U(1)
      DOUBLE PRECISION X,Y,Ysq
      DOUBLE PRECISION XsqYsq,XsqYsqsq
      DOUBLE PRECISION Xp3,Xm3
      DOUBLE PRECISION Xp3sq,Xm3sq
      DOUBLE PRECISION eXp3,eXm3
      X=R(1)
      Y=R(2)
      Xp3 = DBLE(3)+X
      Xp3sq = Xp3**2
      Xm3 = -DBLE(3)+X
      Xm3sq = Xm3**2
      Ysq = Y**2
      XsqYsq = (X**2 +Ysq)
      XsqYsqsq = XsqYsq**2
      eXm3=DEXP(-Xm3sq-Ysq)
      eXp3=DEXP(-Xp3sq-Ysq)
      U(1)=-DBLE(9)*eXm3-DBLE(9)*eXp3+X*Y+DBLE(0.03)*XsqYsqsq
      F(1)=-DBLE(18)*eXm3*Xm3-DBLE(18)*eXp3*Xp3-Y-DBLE(0.12)*XsqYsq*X
      F(2)=-DBLE(18)*eXm3*Y-DBLE(18)*eXp3*Y-X-DBLE(0.12)*XsqYsq*Y
      END SUBROUTINE FORCE
