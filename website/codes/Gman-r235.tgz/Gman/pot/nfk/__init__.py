__doc__ = '''NFK-PES potential'''

from nfk import *
