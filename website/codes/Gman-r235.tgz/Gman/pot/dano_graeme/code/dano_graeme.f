      SUBROUTINE FORCE(N, R, F, U)
      INTEGER N
      DOUBLE PRECISION R(3*N)
      DOUBLE PRECISION F(3*N)
      DOUBLE PRECISION U(1)
      DOUBLE PRECISION X,Y
      DOUBLE PRECISION gaussp,gaussm
      PARAMETER (pi=DBLE(3.141592653589793))
      PARAMETER (xa=DBLE(0.8))
      !PARAMETER (A=pi/DBLE(2))
      PARAMETER (A=0.d0)
      X=R(1)
      Y=R(2)
      gaussp=pi*dexp(-pi*(X*X+(Y+xa)*(Y+xa)))
      gaussm=pi*dexp(-pi*(X*X+(Y-xa)*(Y-xa)))
      U(1)=A*X*Y+COS(pi*X)+COS(pi*Y)+gaussp+gaussm
      F(1)=-A*Y+pi*(SIN(pi*X)+DBLE(2.0)*X*(gaussp+gaussm))
      F(2)=-A*X+pi*(SIN(pi*Y)+DBLE(2.0)*((Y+xa)*gaussp+(Y-xa)*gaussm))
      END SUBROUTINE FORCE
