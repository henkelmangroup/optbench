__doc__ = '''Mueller-Brown potential.'''

from mueller import *
