! Mueller-Brown Potential
! modified by Dan 5.11.2007

      SUBROUTINE FORCE(R,F,U)
      ! imput var
      DOUBLE PRECISION R(3)
      DOUBLE PRECISION F(3)
      DOUBLE PRECISION U(1)
      ! local var
      DOUBLE PRECISION x
      DOUBLE PRECISION y
      DOUBLE PRECISION u1, u2, u3, u4
      DOUBLE PRECISION f1, f2, f3, f4

      x = R(1)
      y = R(2)

      ! potential
      u1 = -200.d0*dexp(-1.0*(x-1.0)**2-10.0*y**2)
      u2 = -100.d0*dexp(-1.0*(x-0.d0)**2-10.0* (y-0.5)**2)
      u3 = -170.d0*dexp(-6.5*(x+0.5)**2+11.0*(x+0.5)
     .        *(y-1.5)-6.5*(y-1.5)**2)
      u4 = 15.0*dexp(0.7*(x+1.0)**2+0.6*(x+1.0)*(y-1.0)
     .        +0.7*(y- 1.d0)**2)
      U(1) = u1+u2+u3+u4
      ! force on x          
      f1 = 2.0*(x-1.0)*u1
      f2 = 2.0*(x-0.d0)*u2
      f3 = u3*(6.5*2.0*(x+0.5)-11.0*(y-1.5))
      f4 = u4*(-0.7*2.0*(x+1.0)- 0.6*(y-1.0))
      F(1) = f1+f2+f3+f4 
      ! force on y          
      f1 = u1*10.0*2.0*y
      f2 = u2*10.0*2.0*(y-0.5)
      f3 = u3*(-11.0*(x+0.5)+6.5*2.0*(y-1.5))
      f4 = u4*(-0.6*(x+1.0)-0.7*2*(y-1.d0))
      F(2) = f1+f2+f3+f4 
      ! force on z          
      F(3) = 0.0

      END SUBROUTINE FORCE

