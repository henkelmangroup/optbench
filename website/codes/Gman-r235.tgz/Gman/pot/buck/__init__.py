__doc__ = '''Ewald ionic potential with Buckingham repulsion.'''

from buck import force, init
