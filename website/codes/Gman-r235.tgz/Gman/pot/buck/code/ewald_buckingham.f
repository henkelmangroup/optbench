c
c   Subroutines to implement Buckingham potential and Ewald sum.
c
c   prmst72 - define potential for Buckingham
c   g72     - calculates gradients and energy of atoms 
c   ebuck   - calculates short-range buckingham energy
c   fbuck   - calculates short-range buckingham forces
c   erfc(x) - error function for ewald sum.
c   furier  - reciprocal part of ewald sum

      subroutine prmst72(ntype,maxtyp,rcut,amu,azero,taxes)

c   Read in potential parameters for buckingham potential from file 'buck.parms'
c   Energy read in eV and then converted to hartrees
c   distances in Angstroms
c
c   File is of format:
c
c   azero  (real)  -  Lattice constant (set to 1.0 since not used in this version)
c   rcut   (real)  - Cutoff for long and short range potentials
c   ntype  (int)   -  Number of species
c   na, chge(na), amu(na) - Species No., charge and atomic mass  (Int, real, real)
c   ...  Repeat for ntype species
c   npote (int)    -  Number of sets of buckingham potential paramters
c   na,nb,aterm(na,nb),rhoterm(na,nb),cterm(na,nb) - potential details for na,nb interaction
c   ...  Repeat for npote potentials
c   iewald (int)   - switch for ewald 0=auto calc alpha and kmax, 1= user defined. Currently 
c                    suggest using iewald=1 since the auto method not particuarly good. In fact I 
c                    really ought to take this line out of the input.
c   alpha (real) kmax (real) - alpha term for Ewald sum; max no of k-vectors for Ewald sum
c
c     Version Info
c     17/1/03 - First Version
c     21/1/03 - Set single rcut and apply to all species
c               Automatically generate lmax,mmax,nmax, alpha from rcut
c     28/1/03 - option to manually set kmax and alpha if necessary. Backup e14_buck.210103
c               Auto calc of kmax, alpha disabled (gives bad values)
c
      implicit real*8(a-h,o-z)
      integer maxtyp,ntype,ewald_opt
      integer lmax,mmax,nmax,ii,jj,na,nb,npote
      real*8  alpha,aterm,chge,cterm,rhoterm
      real*8  rcut,rcutall,amu,azero
      real*8  prec,prefac,sqrtprefac,kval
      dimension rcut(maxtyp,maxtyp),amu(maxtyp),azero(maxtyp),taxes(3)
      dimension inita(8)
      real*8 initb(13)
      common/buck/aterm(9,9),rhoterm(9,9),
     x            cterm(9,9),chge(9)
      common/ewald/vkc, alpha, lmax,mmax,nmax, ewald_opt
      
      open(unit=21,file='buck.parms',status='old')

      read(21,*) azero(1)           ! Lattice constant for species 1
      if (azero(1).ne.1.0) then 
        write(6,'(a,/,a)') 'Warning: Lattice constant, azero(1) ne 1.',
     x                 'TAD currently has no functionality 
     x                  for azero ne 1. Stopping'
        stop
      endif

      read(21,*) rcutall      ! Cutoff for all potentials
c      write(6,'(a,f12.6,a)') "Cutoff set to ",rcutall," Angstrom"

      read(21,*) ntype
c      write(6,'(a,i3)') "Reading ",ntype," species"
      do i=1,ntype
        read(21,*) na,chge(na),amu(na)
c        write(6,'("Species ",i2,2f12.6)') na, chge(na), amu(na)
       enddo

c   Initialise the parameters

      do ii=1,ntype
        do jj=1,ntype
          aterm(ii,jj)   = 0.0d0                
          rhoterm(ii,jj) = 0.0d0
          cterm(ii,jj)   = 0.0d0 
          rcut(ii,jj)    = rcutall
        enddo
      enddo     
      read(21,*) npote
      do i=1,npote
        read(21,*) na,nb,aterm(na,nb),rhoterm(na,nb),
     x             cterm(na,nb)          
        aterm(na,nb) = aterm(na,nb)/27.21            ! Convert energies
        cterm(na,nb) = cterm(na,nb)/27.21            ! to hartrees

        aterm(nb,na) = aterm(na,nb)                  ! Set the reverse
        rhoterm(nb,na) = rhoterm(na,nb)              ! values in case
        cterm(nb,na) = cterm(na,nb)                  ! they are needed 
c        write(6,'(a,i2)') "Potential ",i," Units: Hartrees, Angstroms"
c        write(6,'(i3,i3,3f12.6)') na,nb,aterm(na,nb),rhoterm(na,nb),
c     x                           cterm(na,nb)
      enddo

c     Ewald Parameters
 
      read(21,*) ewald_opt
c      if(ewald_opt == 1) then
c       Read in alpha, kmax
        read(21,*) alpha,kmax
c      else
c       Calculate  alpha and kmax automatically from rcut
c       precfactor = -ln(prec)
c        prec = 0.0001
c        prefac = -dlog(prec)
c        sqrtprefac = sqrt(prefac)
c        alpha = sqrtprefac/rcutall
c        kval = 2.0d0*alpha*sqrtprefac
c        kmax = int(nint(kval+0.5))   ! Round up to nearest int
c      endif

        if (ewald_opt.lt.0) then
           write(6,*) 'e72: multiple method not compiled'
           stop 'e72: multiple method not compiled'
        endif

      lmax = kmax
      mmax = kmax
      nmax = kmax
c     write(6,'("Cutoff = ",f12.8," Angstroms, alpha = ",f12.8,
c     x   " lmax = ",i3," mmax = ",i3," nmax = ",i3)') 
c     x   rcutall,alpha,lmax,mmax,nmax

      close(21)

      if (ewald_opt.eq.-1) then
         tax=taxes(1)
         tay=taxes(2)
         taz=taxes(3)
         open(unit=22,file='dpmta.parms',status='old')
         do i=1,8
            read(22,*) inita(i)
         enddo
c         do i=1,13
         do i=1,1
            read(22,*) initb(i)
         enddo
         do i=2,13
            initb(i)=0.0d0
         enddo
         initb(2)=tax
         initb(6)=tay
         initb(10)=taz
         initb(11)=tax/2.0d0
         initb(12)=tay/2.0d0
         initb(13)=taz/2.0d0
         close(22)
c         call fpmtainit(inita,initb,natom)! natom not defined here! xxxxxxxxxx
      endif

      if (ewald_opt.eq.5) then
         stop 'ewald_opt=5 not implemented yet'
         write(6,*) 'warning: rezeroing charges'
         do i=1,natmax
c            charges(i)=0.0d0
         enddo
      endif

c      write(6,*)
c     x     'prmst72: Completed reading the potential'
      
      return
      end
c     Lijun replaced the follwoing line with the one next to it
c      real*8 function ebuck(it,jt,rj)
      function ebuck(it,jt,rj)
*-----------------------------------------------------------------------

c  Buckingham energy of ion pair             

      implicit real*8(a-h,o-z)

      common/buck/aterm(9,9),rhoterm(9,9),
     x            cterm(9,9),chge(9)
      common/potcom/rct(5,5),tx,ty,tz,ax,ay,az

      m=20

      rcut=rct(it,jt)

      tiny = 0.0000001
      if(rhoterm(it,jt) .lt. tiny) then
        ebuck = 0.0d0
      else
        ebuck=aterm(it,jt)*dexp(-rj/rhoterm(it,jt)) - cterm(it,jt)/rj**6
     +       + cterm(it,jt)/rcut**6 
     +       - aterm(it,jt)*dexp(-rcut/rhoterm(it,jt)) 
     +       + (rcut/float(m))*(1-(rj/rcut)**m)* 
     +       (6.0d0*cterm(it,jt)/rcut**7 
     +       - aterm(it,jt)*dexp(-rcut/rhoterm(it,jt))/rhoterm(it,jt))
      endif
      return
      end

c     Lijun replaced the follwoing line with the one next to it
c      real*8 function fbuck(it,jt,rj,maxtyp)
      function fbuck(it,jt,rj,maxtyp)
*-----------------------------------------------------------------------

c  Buckingham short range forces on ion      

      implicit real*8(a-h,o-z)

      common/buck/aterm(9,9),rhoterm(9,9),
     x            cterm(9,9),chge(9)
      common/potcom/rct(5,5),tx,ty,tz,ax,ay,az

      m=20

      rcut=rct(it,jt)

      tiny = 0.0000001
      if (rhoterm(it,jt) .lt. tiny) then
        fbuck = 0.0d0
      else
        fbuck=aterm(it,jt)*dexp(-rj/rhoterm(it,jt))/(rj*rhoterm(it,jt))
     x        -6.0d0*cterm(it,jt)/rj**8
     +       -((rj/rcut)**(m-1))*(aterm(it,jt)*dexp(-rcut/rhoterm(it 
     +       ,jt))/rhoterm(it,jt)-6.0d0*cterm(it,jt)/rcut**7)/rj
      endif
   
      return
      end

c     Lijun replaced the follwoing line with the one next to it
c      real*8 function erfc(x)        ! Taken from mdions2.f
      function erfc(x)
      implicit none
      real*8 x, erfc
      real*8 a1,a2,a3,a4,a5,expar2,p,t
      DATA p/0.3275911/
      data a1,a2,a3/0.254829592,-0.284496736,1.421413741/
      data a4,a5/-1.453152027,1.061405429/
      t=1.0d0/(1.0d0+p*x)
      expar2=exp(-x**2)

      erfc=( ( ((a5*t+a4)*t+a3)*t +a2 )*t+a1)*t*expar2

      return
      end
      
c-----------------------------------------------------------------------
      subroutine g72
     x   (natom,nmove,x,y,z,itype,maxtyp,tax,tay,taz,rcut,energy,grad)
c-----------------------------------------------------------------------

c     Versions
c     17/1/03 - Completed code, mdions2 ewald sum included. 
c               Verlet list not included
c     21/1/03 - Fixed bug to ensure coulombic sum correctly solved
c               Added virial calculations
c     28/1/03 - rlist used to calculate the nearest neighbour list
c               

      implicit none
      real*8 x, y, z, rj, xj, yj, zj                             
      integer natom, itype, i, it, j, jt, ijpt, k, kt, ikpt, marki, jj
      integer lwrk1,natmax,llmax,nnmax,iwrk1,jwrk1,nneigh,markn,jatomn
      integer maxtyp,nmove,lmax,mmax,nmax,ijdx
      integer mtemp1
      real*8 tax,tay,taz,tx,ty,tz,ax,ay,az,energy
      real*8 dxn,dyn,dzn,rn,fill1
      real*8 b, bd, fr, frd, fa, fad, fc, fcd
      real*8 chgij,pi,aterm,rhoterm,cterm,chge,facpe,facfor,eps0
      real*8 xew,yew,zew,rcut,rct,rjsq
      real*8 grad,gx,gy,gz,gsj,gsjx,gsjy,gsjz,gcrx,gcry,gcrz
      real*8 vsr,vself,vrc,vkc
      real*8 alpha,alphar,al2,ef,ex2,fexp,fm,pad,totpi
      real*8 xmv,ymv,zmv,fxr,fyr,fzr
      real*8 viren,virk,virtot,virsht,vircr,rjtot
      real*8 shtenst,lrenst
      integer imax
      real*8  ebuck,fbuck,erfc
      real*8 rc,emadelung,eself,alpharc,fma,fmb
      external imax, ebuck, fbuck, erfc
      real*8 rq,rpe

c  input
c    natom         number of atoms
c    nmove         number of moving atoms
c    x(natom)      x coordinate of the of atoms
c    y(natom)      y coordinate of the of atoms
c    z(natom)      z coordinate of the of atoms
c    itype(natom)  type of the atoms
c    maxtyp        maximum number of different types
c    tax,tay,taz   x,y,z cell lengths
c    rcut          potential cutoffs
c  output 
c    energy         Potential energy
c    grad(3,natom) Force gradient on single atom

c Note the rather huge values of lwrk1, due to the number of 
c BNeed to sort this out at some point.

      dimension x(natom), y(natom), z(natom), itype(natom)
      dimension xew(natom), yew(natom), zew(natom)
      dimension grad(3,natom)
      dimension rcut(maxtyp,maxtyp)
      dimension fxr(natom), fyr(natom), fzr(natom)
      common/potcom/rct(5,5),tx,ty,tz,ax,ay,az
      parameter (lwrk1=15000000,natmax=2000,nnmax=600,llmax=500000)
      integer ewald_opt
      real*8 charges,chgij1,chgij2,chgetot

c  Voter work common
c	parameter (mtemp1=lwrk1-natmax-9*llmax/2-8*natmax*nnmax-2*natmax)
      parameter (mtemp1=3144000)
      common/wrkcm1/iwrk1,jwrk1,nneigh(natmax),markn(natmax),
     x         jatomn(llmax),dxn(llmax),dyn(llmax),dzn(llmax),rn(llmax),
     x         b(natmax,nnmax), bd(natmax,nnmax),
     x         fr(natmax,nnmax), frd(natmax,nnmax),
     x         fa(natmax,nnmax), fad(natmax,nnmax),
     x         fc(natmax,nnmax), fcd(natmax,nnmax),
     x         rq(natmax),rpe(natmax),
     x         fill1(mtemp1)
      common/buck/aterm(9,9),rhoterm(9,9),cterm(9,9),chge(9)
      common/ewald/vkc, alpha, lmax,mmax,nmax,ewald_opt
      common/dwbpu/charges(natmax)

c set up some factors
      pi = 4.0d0*atan(1.0)
      totpi = 2.0d0/sqrt(pi)
      al2 = alpha*alpha
      facpe = 14.39965173/27.21         ! Hartrees
      facfor = facpe

c kludge for now - move these into call
      tx=tax
      ty=tay
      tz=taz
      ax=tax/2.0d0
      ay=tay/2.0d0
      az=taz/2.0d0
      do i=1,maxtyp
         do j=1,maxtyp
            rct(i,j)=rcut(i,j)
         end do
      end do

      if(iwrk1.gt.0) then
        stop 'g72: wrkcm1 conflict'
        return
      else
        iwrk1=1
      end if

      pad = 0.0d0

c rlistr does the neighbor stuff

      call rlistr (natom, 1, natom, x, y, z, itype, pad,
     x             nneigh, markn, jatomn, dxn, dyn, dzn, rn, llmax)

c      do i=1, natom
c		 print*, 'nneigh:', i, ':', nneigh(i)
c	 end do
c  zero the energy accumulators
      vsr = 0.0d0
      vrc = 0.0d0
      vkc = 0.0d0
      vself = 0.0d0
      viren = 0.0d0

      do i=1,natom
        grad(1,i) = 0.0d0
        grad(2,i) = 0.0d0
        grad(3,i) = 0.0d0
      enddo
      do i=1,natom
        gx = 0.0d0
        gy = 0.0d0
        gz = 0.0d0
        it=itype(i)
        marki = markn(i)

         do jj=1,nneigh(i)
           if (nneigh(i) .gt. nnmax) then
             write(6,'("nneigh(",i3,")=",i4," nnmax=",i4)') 
     x             i,nneigh(i),nnmax
             stop 'g72: increase nnmax'
           endif
           ijdx = marki + jj
           j = jatomn(ijdx)
           xj = dxn(ijdx)
           yj = dyn(ijdx)
           zj = dzn(ijdx)
           rj = rn(ijdx)
           jt = itype(j)

c    Energy Calc. Short range - eV
           shtenst = ebuck(it,jt,rj)
           vsr = vsr + ebuck(it,jt,rj) 
c    Short-range forces
           gsj = fbuck(it,jt,rj,maxtyp)
           gsjx = gsj*xj
           gsjy = gsj*yj
           gsjz = gsj*zj

           gcrx=0.0d0
           gcry=0.0d0
           gcrz=0.0d0

           if (ewald_opt.eq.1) then

c    Coulombic forces - Real space part
              chgij = chge(it)*chge(jt)
              alphar = alpha*rj
              ef = erfc(alphar)
              lrenst=chgij*facpe*erfc(alphar)/rj
              vrc = vrc + chgij*facpe*erfc(alphar)/rj
              ex2 = exp(-al2*rj**2)
              fexp = totpi*ex2
              fm = facfor*chgij*(totpi*alphar*ex2+ef)/(rj**3)
              gcrx = fm * xj                         
              gcry = fm * yj                     
              gcrz = fm * zj     

           endif
              
           gx=gx-gsjx-gcrx  
           gy=gy-gsjy-gcry
           gz=gz-gsjz-gcrz

        enddo
        
c    Nearest Neighbour loop ended here. 
c    Total the forces on atom so far. 
c    These include short range and real space coloumbic
    
        grad(1,i)=gx
        grad(2,i)=gy
        grad(3,i)=gz

c    Coulombic force - Self energy

        vself = vself - ( alpha * chge(it)**2 ) / sqrt(pi)
      
c    Coulombic forces - Reciprocal space part - setting up vectors

        xmv    = nint(x(i)/tx) *tx
        xew(i) = x(i) - xmv
        ymv    = nint(y(i)/ty) *ty
        yew(i) = y(i) - ymv
        zmv    = nint(z(i)/tz) *tz
        zew(i) = z(i) - zmv

      enddo

      vsr=0.5d0*vsr
      vrc=0.5d0*vrc
      vself=vself*facpe

c At this point we have short range energies and forces (in eV)
c The real space coulombic energy, forces and the self energy term (eV)
c plus dimensionless vectors for the atom positions (xew,yew,zew)

      if (ewald_opt.eq.1) then
      
c Calculate the reciprocal space part of the Ewald sum.

         call furier(natom,xew,yew,zew,fxr,fyr,fzr,tax,tay,taz,itype
     +       ,virk)

c      viren = viren+virk
c Calculate total energy and convert to hartrees

         energy =  vsr + vrc + vkc + vself
c    Add reciprocal forces to the total forces on an atom

         do i=1,natom
            grad(1,i) = grad(1,i) - fxr(i) 
            grad(2,i) = grad(2,i) - fyr(i) 
            grad(3,i) = grad(3,i) - fzr(i) 
         enddo

      else if (ewald_opt.eq.-1) then

c Calculate the electrostatics with fast multipoles

         do i=1,natom
            fxr(i)=0.0d0
            fyr(i)=0.0d0
            fzr(i)=0.0d0
            rq(i)=chge(itype(i))
            rpe(i)=0.0d0
         enddo

c this call is for multipole method
c         call fpmtaforce(natom,x,y,z,rq,fxr,fyr,fzr,rpe)

         energy=0.0d0
         do i=1,natom
               grad(1,i) = grad(1,i) - fxr(i)/27.21d0 
               grad(2,i) = grad(2,i) - fyr(i)/27.21d0 
               grad(3,i) = grad(3,i) - fzr(i)/27.21d0 
            energy=energy+rpe(i)/27.21d0/2.0d0
         enddo
         energy=energy+vsr

      else if (ewald_opt.eq.2) then

c    Coulombic forces - Real space part for all atoms (free system)
         do i=1,natom
            it=itype(i)
            do j=1,natom
               if (i.ne.j) then
                  xj=x(i)-x(j)
                  yj=y(i)-y(j)
                  zj=z(i)-z(j)
                  rj=sqrt(xj**2+yj**2+zj**2)
                  jt=itype(j)
                  chgij = chge(it)*chge(jt)

                  vrc=vrc+chgij*facpe/rj
                  fm=chgij*facfor/rj**3

                  gcrx = fm * xj                         
                  gcry = fm * yj                     
                  gcrz = fm * zj     

                  grad(1,i)=grad(1,i)-gcrx
                  grad(2,i)=grad(2,i)-gcry
                  grad(3,i)=grad(3,i)-gcrz
               endif
            enddo
         enddo

         energy=vsr+vrc*0.5d0 ! electrostatics from fmp + buckingham

c         write(6,*) 'energy,vsr,vrc: ',energy,vsr,vrc*0.5d0

      else if (ewald_opt.eq.3.or.ewald_opt.eq.4) then
c    Coulombic forces - Wolf Truncation
         eself=0.0d0
         emadelung=0.0d0
         do i=1,natom
            it=itype(i)
            marki=markn(i)

            eself=eself+chge(it)**2

            do jj=1,nneigh(i)
               ijdx=marki+jj
               j=jatomn(ijdx)

               xj=dxn(ijdx)
               yj=dyn(ijdx)
               zj=dzn(ijdx)
               rj=rn(ijdx)
               jt=itype(j)

               rc=rcut(it,jt)
               alphar=alpha*rj
               alpharc=alpha*rc

               chgij = chge(it)*chge(jt)

               emadelung = emadelung + chgij*erfc(alphar)/rj
               if (ewald_opt.eq.3) then
                  emadelung = emadelung - chgij*erfc(alpharc)/rc
               else if (ewald_opt.eq.4) then
                  emadelung = emadelung - chgij*(erfc(alpharc)/rc**2
     +               +2.0d0*alpha/sqrt(pi)*exp(-alpharc**2)/rc)*(rj-rc)
               endif

               fma=erfc(alphar)/rj**2+2.0d0*alpha/sqrt(pi)
     +             *exp(-alphar**2)/rj
               fmb=erfc(alpharc)/rc**2+2.0d0*alpha/sqrt(pi)
     +             *exp(-alpharc**2)/rc

               fma=fma*chgij*facfor/rj
               fmb=fmb*chgij*facfor/rc

               gcrx = fma * xj - fmb * xj*rc/rj
               gcry = fma * yj - fmb * yj*rc/rj
               gcrz = fma * zj - fmb * yj*rc/rj

               grad(1,i)=grad(1,i)-gcrx
               grad(2,i)=grad(2,i)-gcry
               grad(3,i)=grad(3,i)-gcrz
            enddo
         enddo

         eself=eself*facpe*(erfc(alpharc)/2.0d0/rc+alpha/sqrt(pi))

         energy=vsr + 0.5d0*facpe*emadelung - eself

         write(6,*) 'energy,eself,vsr,emadelung: ',energy,eself,vsr,
     +       0.5d0*facpe*emadelung

      else if (ewald_opt.eq.5) then
c    modified dieter wolf scheme with explicit coulomb partial charges
         eself=0.0d0
         emadelung=0.0d0
         vrc=0.0d0

         chgetot=0.0d0
         do i=1,natom
            chgetot=chgetot+chge(itype(i))-charges(i)
         enddo

         write(6,*) 'total charge on DW system: ',chgetot

         do i=1,natom
            it=itype(i)
            marki=markn(i)

            eself=eself+(chge(it)-charges(i))**2

            do jj=1,nneigh(i)
               ijdx=marki+jj
               j=jatomn(ijdx)
               
               xj=dxn(ijdx)
               yj=dyn(ijdx)
               zj=dzn(ijdx)
               rj=rn(ijdx)
               jt=itype(j)
               
               rc=rcut(it,jt)
               alphar=alpha*rj
               alpharc=alpha*rc
               
               chgij = (chge(it)-charges(i))*(chge(jt)-charges(j))
               
               emadelung=emadelung + chgij*erfc(alphar)/rj
               emadelung=emadelung-chgij*erfc(alpharc)/rc
               
               fma=erfc(alphar)/rj**2+2.0d0*alpha/sqrt(pi)
     +             *exp(-alphar**2)/rj
               fmb=erfc(alpharc)/rc**2+2.0d0*alpha/sqrt(pi)
     +             *exp(-alpharc**2)/rc
               
               fma=fma*chgij*facfor/rj
               fmb=fmb*chgij*facfor/rc
               
               gcrx = fma * xj - fmb * xj*rc/rj
               gcry = fma * yj - fmb * yj*rc/rj
               gcrz = fma * zj - fmb * yj*rc/rj
               
               grad(1,i)=grad(1,i)-gcrx
               grad(2,i)=grad(2,i)-gcry
               grad(3,i)=grad(3,i)-gcrz
            enddo
            if (charges(i).ne.0.0d0) then
               write(6,*) 'atom ',i,' has a fractional charge of '
     +             ,charges(i)
               do j=1,natom
                  if (i.ne.j) then
                     jt=itype(j)
                     chgij1=charges(i)*(chge(jt)-charges(j))
                     chgij2=charges(i)*charges(j)
                     xj=x(i)-x(j)
                     yj=y(i)-y(j)
                     zj=z(i)-z(j)
                     rj=sqrt(xj**2+yj**2+zj**2)
                  
                     vrc=vrc+chgij2*facpe/rj
                     vrc=vrc+2.0d0*chgij1*facpe/rj
                     fm=facfor/rj**3
 
                     grad(1,i)=grad(1,i)-fm*xj*(2*chgij1+chgij2)
                     grad(2,i)=grad(2,i)-fm*yj*(2*chgij1+chgij2)
                     grad(3,i)=grad(3,i)-fm*zj*(2*chgij1+chgij2)
                     
                     grad(1,j)=grad(1,j)+fm*xj*(2*chgij1)
                     grad(2,j)=grad(2,j)+fm*yj*(2*chgij1)
                     grad(3,j)=grad(3,j)+fm*zj*(2*chgij1)
                  endif
               enddo
            endif
         enddo

         eself=eself*facpe*(erfc(alpharc)/2.0d0/rc+alpha/sqrt(pi))

         write(6,*) 'vrc,emadelung,vsr,eself: ',vrc*0.5d0,emadelung
     +       *0.5d0*facpe,vsr,eself

         energy=vsr + vrc*0.5d0 + 0.5d0*facpe*emadelung - eself         

      endif

      iwrk1=0

      return
      end

      subroutine furier
     x   (nmove,x,y,z,fx,fy,fz,tax,tay,taz,itype,virk)
c calculates the reciprocal space part of the ewald sum

      implicit real*8 (a-h,o-z)
      integer nmove,itype
      integer i,L,m,n,lmax,mmax,nmax,ksqmax
      real*8 qforce,tax,tay,taz,virk
      real*8 pi,twopi, elechg,eps0
      real*8 fx,fy,fz,qfrfac,facfor,facpe
      integer ewald_opt
      complex*16 sum, expikr(nmove)
      complex*16 el(nmove,0:lmax),em(nmove,-mmax:mmax),
     x           en(nmove,-nmax:nmax)
      dimension  fx(nmove), fy(nmove), fz(nmove), 
     x           x(nmove),y(nmove),z(nmove),itype(nmove)
      common/buck/aterm(9,9),rhoterm(9,9),cterm(9,9),chge(9)
      common/ewald/vkc, alpha, lmax,mmax,nmax,ewald_opt
C physical constants
      data elechg,eps0/1.602e-19,8.854e-12/

      virk = 0.0d0
      ksqmax = lmax**2 +2
      pi= 4.0*atan(1.0)
      twopi = 2.0d0 * pi
      vol = tax*tay*taz
      facpe = 14.39965173/27.21
      facfor = facpe


c   Zero Forces and store exponential factors

      do  i =1,nmove

        fx(i) = 0.0
        fy(i) = 0.0
        fz(i) = 0.0

        el(i,0) = 1.0
        em(i,0) = 1.0
        en(i,0) = 1.0

        el(i,1) = cmplx( cos(twopi*x(i)/tax) , sin(twopi*x(i)/tax) )
        em(i,1) = cmplx( cos(twopi*y(i)/tay) , sin(twopi*y(i)/tay) )
        en(i,1) = cmplx( cos(twopi*z(i)/taz) , sin(twopi*z(i)/taz) )

        do L=2,lmax
          el(i,L) = el(i,L-1)*el(i,1) 
        enddo
        do m=2,mmax
          em(i,m) = em(i,m-1)*em(i,1) 
        enddo
        do m=-mmax,-1
          em(i,m) = conjg( em(i,-m) )
        enddo
        do n=2,nmax
          en(i,n) = en(i,n-1)*en(i,1) 
        enddo
        do n=-nmax,-1
          en(i,n) = conjg( en(i,-n) )
        enddo

      enddo

      vkc = 0.0d0
      qfrfac = -4.0*facfor

c loop over all k vectors k=2pi(L/cl,m/cm,n/cn), taking into account
c the inversion symmetry. thus
c
c      L ranges over the values 0 to lmax
c      m ranges over 0 to mmax when l=0, and over -mmax to mmax
c      otherwise
c      n ranges over 1 to nmax when l=m=0, and over -nmax to nmax
c      otherwise
c
c and the result of the summation is doubled at the end.

      mmin = 0
      nmin = 1
      do L=0,lmax
        rl = twopi*real(L)/tax
        do m=mmin,mmax
          rm = twopi*real(m)/tay
          do n=nmin,nmax
            rn = twopi*real(n)/taz
           
            kk=L*L + m*m + n*n
            if (kk .le. ksqmax) then
              rksq=rl*rl+rm*rm+rn*rn
              ak = twopi/vol * exp(-0.25*rksq/alpha**2)/rksq
              do i = 1,nmove
                expikr(i) = el(i,L)*em(i,m)*en(i,n)
              enddo
              sum = (0.0, 0.0)  
              do i = 1,nmove
                sum = sum + chge(itype(i))*expikr(i)
              enddo
              vkc = vkc + ak*conjg(sum)*sum 
              do i = 1,nmove
                qforce = qfrfac*ak*chge(itype(i))
     x                   * dimag(sum*conjg(expikr(i)))
                fx(i) = fx(i) +rl*qforce
                fy(i) = fy(i) +rm*qforce
                fz(i) = fz(i) +rn*qforce
                virk = virk+qforce*sqrt(rksq)
              enddo
            endif

          enddo
          nmin=-nmax
        enddo
        mmin = -mmax
      enddo
      vkc = vkc *2.0*facpe

      return
      end
      subroutine rlistr(natom,iatom1,iatom2,x,y,z,itype, pad,
     +          nneigh,markn,jatomn,dxn,dyn,dzn,rn,lmax)
c  like rlist_, but only computes neighbor lists for range of atoms iatom1,iatom2
c  like rlistn, but uses z-boxing info to improve speed
c  general neighbor-listing routine
c  sets up a full neighbor list for each of the natom atoms
c  user supplies:  natom, x(),y(),z(),itype(),
c                  lmax=maximum length for jatomn,dxn,dyn,dzn,rn arrays
c                  pad = extra distance (padding) to add to rcut
c                        (necessary if using later calls to rlistu)
c  rlistn returns:
c                  nneigh(natom) = no. of neighbors for each atom
c                  markn(natom) = pointer array for jatomn,dxn,dyn,dzn,rn
c                  jatomn(),dxn(),dyn(),dzn(),rn() - length<=lmax
c           define: m=markn(i)
c              jatomn(m+j) = j'th neighbor of atom i
c              dxn(m+j) = x(i)-x(j)  (dyn,dzn analagous)
c              rn(m+j) = distance from atom i to j'th neighbor of atom i
c
      implicit real*8(a-h,o-z)
      save
      dimension x(natom),y(natom),z(natom),itype(natom)
      dimension nneigh(natom),markn(natom)
      dimension jatomn(lmax),dxn(lmax),dyn(lmax),dzn(lmax),rn(lmax)
      common/potcom/rcut(5,5),tax,tay,taz,ax,ay,az
c      common/potcom/rcut(3,3),tax,tay,taz,ax,ay,az
      common/nlists/ilist
c     Lijun added the following lineon Austin/04
       ilist=0
      if(ilist.gt.0) then
        call rlistb(natom,iatom1,iatom2,x,y,z,itype, pad,
     x            nneigh,markn,jatomn,dxn,dyn,dzn,rn,lmax)
        return
      end if

        k=0
        do 190 i=iatom1,iatom2
        markn(i)=k
        it=itype(i)
        do 170 j=1,natom
        if(j.eq.i) go to 170
        dx=x(i)-x(j)
        if(dx.gt.ax) dx=dx-tax
        if(dx.lt.-ax) dx=dx+tax
        dy=y(i)-y(j)
        if(dy.gt.ay) dy=dy-tay
        if(dy.lt.-ay) dy=dy+tay
        dz=z(i)-z(j)
        if(dz.gt.az) dz=dz-taz
        if(dz.lt.-az) dz=dz+taz
        r2=dx*dx+dy*dy+dz*dz
        if(r2.gt.(rcut(it,itype(j))+pad)**2) go to 170
          k=k+1
          jatomn(k)=j
          dxn(k)=dx
          dyn(k)=dy
          dzn(k)=dz
          rn(k)=sqrt(r2)
  170   continue
        if(k.gt.lmax) stop 'abort - out of space in rlistr'
        nneigh(i)=k-markn(i)
  190   continue

      return
      end

      subroutine rlistb(natom,iatom1,iatom2,x,y,z,itype, pad,
     x          nneigh,markn,jatomn,dxn,dyn,dzn,rn,lmax)
c  computes full neighbor list each atom in range iatom1,iatom2
c  uses 3-D boxing to increase speed
c  user supplies:  natom, x(),y(),z(),itype(),
c                  lmax=maximum length for jatomn,dxn,dyn,dzn,rn arrays
c                  pad = extra distance (padding) to add to rcut
c                        (necessary if using later calls to rlistu)
c  returned:
c                  nneigh(natom) = no. of neighbors for each atom
c                  markn(natom) = pointer array for jatomn,dxn,dyn,dzn,rn
c                  jatomn(),dxn(),dyn(),dzn(),rn() - length<=lmax
c           define: m=markn(i)
c              jatomn(m+j) = j'th neighbor of atom i
c              dxn(m+j) = x(i)-x(j)  (dyn,dzn analagous)
c              rn(m+j) = distance from atom i to j'th neighbor of atom i
c
      implicit real*8(a-h,o-z)
      save
      dimension x(natom),y(natom),z(natom),itype(natom)
      dimension nneigh(natom),markn(natom)
      dimension jatomn(lmax),dxn(lmax),dyn(lmax),dzn(lmax),rn(lmax)
      common/potcom/rcut(5,5),tax,tay,taz,ax,ay,az
c      common/potcom/rcut(3,3),tax,tay,taz,ax,ay,az
      include 'wrksubs_tad2.h' 
      parameter(mxijk=10000,mxpont=100000,mxatom=10000)
c      parameter(mtemp10=lwrk10 - 3*mxatom/2 - mxijk/2 - mxpont/2)
      parameter(mtemp10=30000)
      common/wrkcm10/iwrk10,jwrk10,
     +            ixbox(mxatom),iybox(mxatom),izbox(mxatom),
     +            nijk(mxijk),ipoint(mxpont),
     +            fill10(mtemp10)
      common/nlists/ilist
c  ilist=0 - rlist calls stay there
c  ilist=1 - rlist calls diverted here (rlistb)
c  ilist=2 - rlist calls diverted here (rlistb) with no boxing

      if(iwrk10.le.0 .and. ilist.ne.2) then
        iwrk10=1132
        ifbox=1
      else
        ifbox=0
        go to 234
      end if

c begin 3-D boxing scheme

c  determine number of boxes in each of x,y,z directions

c   make each box a little larger, as nec., to exactly fill tax length
      call dmnmx(rcut,9,rdum1,rcmax,idum1,idum2)
      nreach=1
      nxbox =  int(tax/(rcmax/float(nreach)))
      nybox =  int(tay/(rcmax/float(nreach)))
      nzbox =  int(taz/(rcmax/float(nreach)))
      if(min(nxbox,nybox,nzbox).lt.1+2*nreach) then
        ifbox=0
        go to 234
      end if
c    xbox = x length of the box  (a little larger than rcmax/nreach)
      xbox = tax/float(nxbox)
      ybox = tay/float(nybox)
      zbox = taz/float(nzbox)
      itest=nxbox*nybox*nzbox
      if(itest.gt.mxijk .or. itest.lt.0) then
          ifbox = 0
          write(6,*)  'note =- not able to box in rlistb'
          go to 234
c         stop 'increase mxijk in rlistb'
      end if

c  determine which box each atom is in to find max in any one box

      do 10 ijk=1,nxbox*nybox*nzbox
   10 nijk(ijk)=0

c    following scheme good unless an atom coord is more negative than 10*tax
      do 20 i=1,natom
      ixbox(i)=mod(x(i)+100.0d0*tax,tax)/xbox + 1
      iybox(i)=mod(y(i)+100.0d0*tay,tay)/ybox + 1
      izbox(i)=mod(z(i)+100.0d0*taz,taz)/zbox + 1
      if(ixbox(i).lt.1 .or. ixbox(i).gt.nxbox) stop 'fix x boxing'
      if(iybox(i).lt.1 .or. iybox(i).gt.nybox) stop 'fix y boxing'
      if(izbox(i).lt.1 .or. izbox(i).gt.nzbox) stop 'fix z boxing'
      ijk = (izbox(i)-1)*nxbox*nybox + (iybox(i)-1)*nxbox + ixbox(i)
      nijk(ijk)=nijk(ijk)+1
   20 continue
      nbmax = imax(nijk,nxbox*nybox*nzbox)
      if(nbmax*nxbox*nybox*nzbox.gt.mxpont)stop'rlistb: increase mxpont'

      do 25 ijk=1,nxbox*nybox*nzbox
      nijk(ijk)=0
   25 continue

c  fill ipoint array so atoms in that box can be found

c     ipoint array is ordered as follows:
c      fastest index:  icell      max=nbmax
c                       x         max=nxbox
c                       y         max=nybox
c      slowest index:   z         max=nzbox

      do 30 i=1,natom
      ix = ixbox(i)
      iy = iybox(i)
      iz = izbox(i)
      ijk = (iz-1)*nxbox*nybox + (iy-1)*nxbox + ix
      nijk(ijk)=nijk(ijk)+1
      icell=nijk(ijk)
      ijkm = (ijk-1)*nbmax + icell
      ipoint(ijkm)=i
   30 continue

c now have the following arrays of interest:

c     ipoint(...)  given box, can look up each atom in that box
c     nijk(ijk) = number of atoms in box ijk
c     ixbox(i)  =  x box number for atom i
c     iybox(i)  =  y box number for atom i
c     izbox(i)  =  z box number for atom i

c make neighbor list
c  note that this code is only good if atoms are within roughly one tax of origin

 234  continue
      if(ifbox.ne.0) then
c        write(6,*) 'will perform 3-D boxing for fast neighbor list'
        k=0
        do 90 i=iatom1,iatom2
        markn(i)=k
        it=itype(i)
ccc       do 70 j=1,natom

        do 80 ixraw=ixbox(i)-nreach,ixbox(i)+nreach
        do 70 iyraw=iybox(i)-nreach,iybox(i)+nreach
        do 60 izraw=izbox(i)-nreach,izbox(i)+nreach
        ix =   mod(ixraw + nxbox-1,nxbox) + 1
        iy =   mod(iyraw + nybox-1,nybox) + 1
        iz =   mod(izraw + nzbox-1,nzbox) + 1
        ijk = (iz-1)*nxbox*nybox + (iy-1)*nxbox + ix
        do 50 icell=1,nijk(ijk)
        ijkm = (ijk-1)*nbmax + icell
        j=ipoint(ijkm)
        if(j.eq.i) go to 50
        dx=x(i)-x(j)
        if(dx.gt.ax) then
           dx=dx-tax
        else if(dx.lt.-ax) then
           dx=dx+tax
        end if
        dy=y(i)-y(j)
        if(dy.gt.ay) then
          dy=dy-tay
        else if(dy.lt.-ay) then
          dy=dy+tay
        end if
        dz=z(i)-z(j)
        if(dz.gt.az) then
          dz=dz-taz
        else if(dz.lt.-az) then
          dz=dz+taz
        end if
        r2=dx*dx+dy*dy+dz*dz
        if(r2.gt.(rcut(it,itype(j))+pad)**2) go to 50
          k=k+1
          jatomn(k)=j
          dxn(k)=dx
          dyn(k)=dy
          dzn(k)=dz
          rn(k)=sqrt(r2)
   50   continue
   60   continue
   70   continue
   80   continue
        if(k.gt.lmax) stop 'abort - out of space in rlistb'
        nneigh(i)=k-markn(i)
   90   continue

      else if(ifbox.eq.0) then
c        write(6,*) 'NOTE - skipping 3-D boxing: full neighbor list work'
        k=0
        do 190 i=iatom1,iatom2
        markn(i)=k
        it=itype(i)
        do 170 j=1,natom
        if(j.eq.i) go to 170
        dx=x(i)-x(j)
        if(dx.gt.ax) dx=dx-tax
        if(dx.lt.-ax) dx=dx+tax
        dy=y(i)-y(j)
        if(dy.gt.ay) dy=dy-tay
        if(dy.lt.-ay) dy=dy+tay
        dz=z(i)-z(j)
        if(dz.gt.az) dz=dz-taz
        if(dz.lt.-az) dz=dz+taz
        r2=dx*dx+dy*dy+dz*dz
        if(r2.gt.(rcut(it,itype(j))+pad)**2) go to 170
          k=k+1
          jatomn(k)=j
          dxn(k)=dx
          dyn(k)=dy
          dzn(k)=dz
          rn(k)=sqrt(r2)
  170   continue
        if(k.gt.lmax) stop 'abort - out of space in nonboxing rlistb'
        nneigh(i)=k-markn(i)
  190   continue
      end if

      if(iwrk10.eq.1132) iwrk10=0

      return
      end

      subroutine dmnmx(x,natom,xmin,xmax,ixmin,ixmax)
c: finds min and max in array x, returns values(xmin,xmax) and pointers(ixmin,ixmax)
c:
      implicit real*8(a-h,o-z)
      dimension x(natom)
      ixmin=1
      ixmax=1
      do 10 i=1,natom
      if(x(i).lt.x(ixmin)) ixmin=i
      if(x(i).gt.x(ixmax)) ixmax=i
   10 continue
      xmin=x(ixmin)
      xmax=x(ixmax)
      return
      end


      function imax(ia,n)
c: finds max integer in array ia
c:
      dimension ia(n)
      if(n.eq.0) then
        imax=0
        return
      else
        imax=ia(1)
      end if
      do 10 i=1,n
      if(ia(i).gt.imax) imax=ia(i)
   10 continue
      return
      end
