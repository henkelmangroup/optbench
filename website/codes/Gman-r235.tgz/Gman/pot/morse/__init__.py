__doc__ = '''Morse potential.'''

from morse import *
