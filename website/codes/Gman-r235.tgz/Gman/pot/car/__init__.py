__doc__ = '''car potential'''

from car import force
