c  etestcu.f - test routine for Voter embedded atom potentials   (afv 10/24/86)

c link this with esubs and trpsubs  (2/2000)

      implicit real*8(a-h,o-z)
      dimension x(4),y(4),z(4),itype(4)
c  4-atom cluster, (coordinates chosen out of thin air)
      data x/0.0d0, 0.0d0, 3.0d0, 2.5d0/
      data y/0.0d0, 2.5d0, 0.0d0, 4.0d0/
      data z/0.0d0, 0.5d0, 0.0d0, 0.0d0/

      write(6,1)
    1 format('  test program for Voter Cu potential, 9/21/87')

      natom=4
      write(6,5) (x(i),y(i),z(i),i=1,natom)
    5 format(/' atom coordinates for test case cluster'/(3f20.8))

c  open units for potentials

c convention for unit numbers:
c      rho(r)   -   70 + itype
c      phi(r)   -   80 + itype*jtype
c      f(rho)   -   90 + itype

      open(unit=61,file='cu.doc',form='formatted',status='old')
      open(unit=71,file='cu.rho',form='unformatted',status='old')
      open(unit=81,file='cu.phi',form='unformatted',status='old')
      open(unit=91,file='cu.f',form='unformatted',status='old')

c  set periodic boundary condition periods very large
      tax=1000.0d0
      tay=1000.0d0
      taz=1000.0d0

c  following call required to read in and set up potentials

      ntype=1
      call POTSET(NTYPE,TAX,TAY,TAZ,IWRT)

      do 10 j=1,4
      itype(j)=1
   10 continue

      nmove=4
      e = ENERGY(NATOM,NMOVE,X,Y,Z,ITYPE)
      write(6,20) itype,e
   20 format(' Energy of 4 atom cluster (types',4i2,') =',f10.6,
     x          ' hartree')
   30 continue
      end
