c **********************************************************************
c This SOFTWARE  has been authored  by an employee   or employees of the
c University  of  California, operator    of the  Los   Alamos  National
c Laboratory  under Contract No. W-7405-ENG-36  with the U.S. Department
c of  Energy.   The U.S. Government  has  rights to use,  reproduce, and
c distribute this SOFTWARE.   The  public may copy,  prepare  derivative
c works and publicly display this SOFTWARE without charge, provided that
c this  Notice  and any statement  of  authorship are  reproduced on all
c copies.  Neither the Government nor the University makes any warranty,
c express or implied, or assumes any liability or responsibility for the
c use  of this SOFTWARE.  If SOFTWARE  is modified to produce derivative
c works, such  modified SOFTWARE should be clearly  marked, so as not to
c confuse it with the version available from LANL.
c
c It is expressly forbidden to distribute this code, in whole or in part,
c either as is or modified.
c **********************************************************************


c   wrksubs_tad1.h  -  work common lengths
      parameter(lwrk1=1200000) ! was 1200 000
      parameter(lwrk2=100000) 
      parameter(lwrk3=1000)   ! was 100 000
      parameter(lwrk4=1000)   ! was 10 000
      parameter(lwrk5=1000)   ! was 20 000
      parameter(lwrk6=1000)   ! was 10 000
      parameter(lwrk7=1000)
      parameter(lwrk8=100000)  ! originally 20 000
      parameter(lwrk9=100000) 
      parameter(lwrk10=100000) 
      parameter(lwrk11=1000)   ! was 100 000
      parameter(lwrk12=1000)   ! was 100 000
      parameter(lwrk13=1125750) ! was 375 000
      parameter(lwrk14=100000)  ! was 375 000
      parameter(lwrk15=1000)  ! was 30 000
