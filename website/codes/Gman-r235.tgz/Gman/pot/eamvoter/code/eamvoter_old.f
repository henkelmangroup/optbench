      subroutine eam_setup(ntyp,amu,azero,potnam,dirnam)
c      subroutine eam_setup(ntyp,amu,azero,potnam)
c sets up eam potential - reads in interp files

c passed in:
c  ntyp    = number of types expected  (passed in)
c  potnam  = array of potnames
c returned:
c  amu     = 1-D array of masses
c  azero   = 1-D array of equilibrium T=0 lattice constants

      implicit real*8(a-h,o-z)
      dimension amu(ntyp),azero(ntyp)
c      character*80 dirnam,potnam(ntyp),filnam
      character*80 potnam(ntyp)
      character*256 dirnam,filnam
      common/potcox/rcut(3,3)
      

c      dirnam='portapot/'
c      write(6,*) 'dirnam =',dirnam
      iwrt=1

      do 8 i=1,ntyp
      call chrpak(dirnam,256,ld)
c      call chrpak(dirnam,80,ld)
      call chrpak(potnam(i),80,lp)
      filnam=dirnam(1:ld)//potnam(i)(1:lp)//'.doc'
c      write(6,*) 'filnam =',filnam
      open(unit=60+i,file=filnam,status='old',form='formatted',err=99)
      filnam=dirnam(1:ld)//potnam(i)(1:lp)//'.rho'
      open(unit=70+i,file=filnam,status='old',form='unformatted',err=99)
      filnam=dirnam(1:ld)//potnam(i)(1:lp)//'.f'
      open(unit=90+i,file=filnam,status='old',form='unformatted',err=99)
      filnam=dirnam(1:ld)//potnam(i)(1:lp)//'.phi'
      open(unit=80+i*i,file=filnam,status='old',form='unformatted',
     x err=99)
      do 6 j=i+1,ntyp
      lpi=lp
      call chrpak(potnam(j),80,lpj)
      filnam=dirnam(1:ld)//potnam(i)(1:lpi)//potnam(j)(1:lpj)//'.phi'
      open(unit=80+i*j,file=filnam,status='old',form='unformatted',
     x err=99)
    6 continue
    8 continue

c      if(iwrt.ge.0) write(6,2) ntyp
c    2 format(' here are the title cards from the',i2,' potentials:')
      do 5 i=1,ntyp
      iu=60+i
      rewind iu
      read(iu,3) title
      read(iu,*) amu(i)
      read(iu,*) azero(i)
c      write (*,*) amu(i)
    3 format(10a8)
c      if(iwrt.ge.0) write(6,4) title
c    4 format(1x,10a8)
    5 continue

      do 10 i=1,ntyp
      call trpdat(70+i,npt,x0,x1,rhoci,y1,yn,iflo,ifhi)
      call trpdat(90+i,npt,x0,x1,xn,y1,yn,iflo,ifhi)
      do 10 j=1,ntyp
      call trpdat(70+j,npt,x0,x1,rhocj,y1,yn,iflo,ifhi)
      call trpdat(80+i*j,npt,x0,x1,phicij,y1,yn,iflo,ifhi)
      rcut(i,j)=max(rhoci,rhocj,phicij)
      write(*,*) "rcut: ",rcut(i,j)
   10 continue

c      if(iwrt.ge.0) then
c        write(6,20) ntyp
c   20   format(' trp arrays for ntyp =',i2,
c     x         ' have been read from units 70+i,80+i*j,90+i')
c      end if

      ietype=0

      return

   99 stop 'open error in eam_setup'
      end


      subroutine chrpak(c,lmax,lc)
c: packs out blanks in a character string whose maximum length is lmax.
c: lc is returned as the packed length.
c:
      character*(*) c
      character*800 ct
      common/chrcm/ct
      k=0
      do 10 i=1,lmax
      if(c(i:i).ne.' ') then
        k=k+1
        if(k.gt.800) stop 'abort - maxed out in chrpak'
        ct(k:k)=c(i:i)
      end if
   10 continue
      lc=k
      c=ct(1:lc)
      return
      end

      function force(natom,x,y,z,itype,tax,tay,taz,fx,fy,fz)
c  this routine computes the energy and also 
c     the force (fx,fy,fz) on all atoms.
c
c
      implicit real*8(a-h,o-z)
      dimension x(natom),y(natom),z(natom),itype(natom)
      dimension fx(natom),fy(natom),fz(natom)
      parameter (nnmax=200)
      dimension jt(nnmax),rj(nnmax),jn(nnmax)
      dimension rtot(natom)
      dimension xj(nnmax),yj(nnmax),zj(nnmax)
      common/potcom/tx,ty,tz,ax,ay,az
      common/potcox/rcut(3,3)
     
      maxn=nnmax
      call taxset(tax,tay,taz)
      e=0.0d0
      do 120 i=1,natom
      write(*,*) "R(",i,"):", x(i),y(i),z(i)
      call rlist1(natom,x,y,z,itype,
     x                          i,nn,jn,jt,rj,maxn)
      it=itype(i)
      call rhatm3(it,nn,rj,jt, rho,ei)   
c                              ! 3-pt interp for higher accuracy
      e=e+ei
      write(*,*) "U(",i,"):", ei*27.21,e*27.21
      rtot(i)=rho
  120 continue

      maxn=nnmax
      do 130 i=1,natom
      call rlist2(natom,x,y,z,itype,
     x                          i,nn,jn,jt,rj,
     x                          xj,yj,zj,maxn)
      it=itype(i)
      rhoi=rtot(i)
      gx=0
      gy=0
      gz=0
      call gatom(natom,it,rhoi,nn,xj,yj,zj,rj,itype,rtot,gx,gy,gz)
      fx(i)= - gx
      fy(i)= - gy
      fz(i)= - gz
      write(*,*) "F(",i,"):", fx(i)*27.21,fy(i)*27.21,fz(i)*27.21
  130 continue
      force=e
      return
      end



      function energy(natom,x,y,z,itype,tax,tay,taz)
c  this routine returns total energy over all atoms
      implicit real*8(a-h,o-z)
      dimension x(natom),y(natom),z(natom),itype(natom)
      parameter (nnmax=200)
      dimension jat1(nnmax),rn1(nnmax),jtyp1(nnmax)

      call taxset(tax,tay,taz)
c
      maxn=nnmax
      e=0.0d0
      do 20 i=1,natom
      call rlist1(natom,x,y,z,itype,
     x                          i,  nn,jat1,jtyp1,rn1,maxn)
      it=itype(i)
      call rhatm3(it,nn,rn1,jtyp1, rho,ei)   
c                              ! 3-pt interp for higher accuracy
      e=e+ei
   20 continue
      energy=e
      return
      end

      subroutine gatom(natom,it,rhoi,nneigh,dx,dy,dz,r,
     x                      itype,rhotot,gx,gy,gz)     
c
c
      implicit real*8(a-h,o-z)
      parameter (nnmax=200)
      dimension dx(200),dy(200),dz(200),r(200)
      dimension itype(natom),rhotot(natom)
c
c  statement functions for interpolation fits
c  note:  these assume that sgcon has been performed to eliminate s() and g()
      rho(rr,it)=trpfun(rr,0,70+it)
      tgrho(rr,it)=trpfun(rr,11,70+it)
      phi(rr,it,jt)=trpfun(rr,0,80+it*jt)
      tgphi(rr,it,jt)=trpfun(rr,1,80+it*jt)/rr
      f(x,it)=trpfun(x,0,90+it)
      fp(x,it)=trpfun(x,1,90+it)
c
c  compute gradient on this atom
c
      gx=0.0d0
      gy=0.0d0
      gz=0.0d0
      fpi=fp(rhoi,it)
      do 20 j=1,nneigh
      
      jt=itype(j)
      tgrad=tgphi(r(j),it,jt) + fpi*tgrho(r(j),jt)
     x                           + fp(rhotot(j),jt)*tgrho(r(j),it)
      gx=gx+tgrad*dx(j)
      gy=gy+tgrad*dy(j)
      gz=gz+tgrad*dz(j)
   20 continue


      return
      end

      subroutine rhatom(ityp,nneigh,r,itype,    
c                              ! supplied
     x                           rhotot,energy)   
c                              ! returned
c  this routine computes the electron density at *one* atom.
c  the calling routine supplies the type of this atom (ityp), the number
c  of neighbors (nneigh), the distance to each neighbor (r(nneigh)),
c  and the type of each neighbor (itype(nneigh)).
c  this routine returns the energy of this atom (energy),
c  and the electron density (rhotot).
c
      implicit real*8(a-h,o-z)
c     dimension r(nneigh),itype(nneigh)
      dimension r(*),itype(*)
      common/abparm/s(2),sinv(2),g(2)
c
c  statement functions for interpolation fits
c  note:  these assume that sgcon has been performed to eliminate s() and g()
      rho(rr,it)=trpfun(rr,0,70+it)
      phi(rr,it,jt)=trpfun(rr,0,80+it*jt)
      f(x,it)=trpfun(x,0,90+it)
c
c   compute energy and rhotot
c
      epair=0.0d0
      it=ityp
      rhotot=0.0d0
      do 40 j=1,nneigh
      jt=itype(j)
      epair=epair + phi(r(j),it,jt)
      rhotot=rhotot+rho(r(j),jt)
   40 continue
c
      energy = f(rhotot,it) + 0.5d0*epair
c
      return
      end

      subroutine rhatm3(ityp,nneigh,r,itype,    
c                              ! supplied
     x                           rhotot,energy)   
c                              ! returned
c like rhatom, but uses 3-point interpolation for higher accuracy
c  this routine computes the electron density at *one* atom.
c  the calling routine supplies the type of this atom (ityp), the number
c  of neighbors (nneigh), the distance to each neighbor (r(nneigh)),
c  and the type of each neighbor (itype(nneigh)).
c  this routine returns the energy of this atom (energy),
c  and the electron density (rhotot).
c
      implicit real*8(a-h,o-z)
c     dimension r(nneigh),itype(nneigh)
      dimension r(*),itype(*)
      common/abparm/s(2),sinv(2),g(2)
c  test stuff:
c      save sig,eps
c      data sig/2.282d0/,eps/1.9097d-2/  
c                              ! h&p lj parms for ni
c      phi(r,it,jt)=4.0d0*eps*((sig/r)**12-(sig/r)**6)
c
c ***  3-point interpolation for higher accuracy ***
      rho(rr,it)=trpfn3(rr,0,70+it)
      phi(rr,it,jt)=trpfn3(rr,0,80+it*jt)
      f(x,it)=trpfn3(x,0,90+it)
c
c   compute energy and rhotot
c
      epair=0.0d0
      it=ityp
      rhotot=0.0d0
      do 40 j=1,nneigh
      jt=itype(j)
      epair=epair + phi(r(j),it,jt)
      rhotot=rhotot+rho(r(j),jt)
   40 continue
c
      energy = f(rhotot,it) + 0.5d0*epair
c
      return
      end
c
      subroutine rlist2(natom,x,y,z,itype,iatom,      
c                              ! supplied
     x                  nn,jn,jt,rj,
     x                  xj,yj,zj,maxn)
c  general neighbor-listing routine for *one* atom (iatom)
c  user supplies:  natom, x(),y(),z(),itype(),
c                  maxn=maximum length for jat1,jtyp1,rn1 arrays
c                  iatom = atom for which neighbor list is to be constructed
c  rlist1 returns:
c                  nn= no. of neighbors for this atom
c                  jat1(),jtyp1(),rn1() - length<=maxn
c              jn(j) = j'th neighbor of atom iatom
c              jt(j) = type of j'th neighbor
c              rj(j) = distance from atom iatom to j'th neighbor
c              xj(j) = displacement in x to j'th neighbor
c              yj(j) = displacement in y to j'th neighbor
c              zj(j) = displacement in z to j'th neighbor
c
      implicit real*8(a-h,o-z)
      dimension x(natom),y(natom),z(natom),itype(natom)
      dimension jn(maxn),jt(maxn),rj(maxn)
      dimension xj(maxn),yj(maxn),zj(maxn)
      common/potcom/tx,ty,tz,ax,ay,az
      common/potcox/rcut(3,3)
c
      k=0
      i=iatom
      it=itype(i)
      do 10 j=1,natom
      if(j.eq.i) go to 10
      dx=x(i)-x(j)
      if(dx.gt.ax) dx=dx-tx
      if(dx.lt.-ax) dx=dx+tx
      dy=y(i)-y(j)
      if(dy.gt.ay) dy=dy-ty
      if(dy.lt.-ay) dy=dy+ty
      dz=z(i)-z(j)
      if(dz.gt.az) dz=dz-tz
      if(dz.lt.-az) dz=dz+tz
      r=sqrt(dx*dx+dy*dy+dz*dz)
      if(r.gt.rcut(it,itype(j))) go to 10
        k=k+1
        jn(k)=j
        jt(k)=itype(j)
        rj(k)=r
        xj(k)=dx
        yj(k)=dy
        zj(k)=dz
   10 continue
      if(k.gt.maxn) stop 'abort - out of space in routine rlist1'
      nn=k
      return
      end

c
c
c

      subroutine rlist1(natom,x,y,z,itype,iatom,      
c                              ! supplied
     x                  nn,jat1,jtyp1,rn1,maxn)
c  general neighbor-listing routine for *one* atom (iatom)
c  user supplies:  natom, x(),y(),z(),itype(),
c                  maxn=maximum length for jat1,jtyp1,rn1 arrays
c                  iatom = atom for which neighbor list is to be constructed
c  rlist1 returns:
c                  nn= no. of neighbors for this atom
c                  jat1(),jtyp1(),rn1() - length<=maxn
c              jat1(j) = j'th neighbor of atom iatom
c              jtyp1(j) = type of j'th neighbor
c              rn(j) = distance from atom iatom to j'th neighbor
c
      implicit real*8(a-h,o-z)
      dimension x(natom),y(natom),z(natom),itype(natom)
      dimension jat1(maxn),jtyp1(maxn),rn1(maxn)
      common/potcom/tx,ty,tz,ax,ay,az
      common/potcox/rcut(3,3)
c
      k=0
      i=iatom
      it=itype(i)
      do 10 j=1,natom
      if(j.eq.i) go to 10
      dx=x(i)-x(j)
      if(dx.gt.ax) dx=dx-tx
      if(dx.lt.-ax) dx=dx+tx
      dy=y(i)-y(j)
      if(dy.gt.ay) dy=dy-ty
      if(dy.lt.-ay) dy=dy+ty
      dz=z(i)-z(j)
      if(dz.gt.az) dz=dz-tz
      if(dz.lt.-az) dz=dz+tz
      r=sqrt(dx*dx+dy*dy+dz*dz)
      if(r.gt.rcut(it,itype(j))) go to 10
        k=k+1
        jat1(k)=j
        jtyp1(k)=itype(j)
        rn1(k)=r
   10 continue
      if(k.gt.maxn) stop 'abort - out of space in routine rlist1'
      nn=k
      return
      end


      subroutine taxset(tax,tay,taz)
      implicit real*8(a-h,o-z)
      common/potcom/tx,ty,tz,ax,ay,az
      tx=tax
      ty=tay
      tz=taz
      ax=tax/2.0d0
      ay=tay/2.0d0
      az=taz/2.0d0
      return
      end

      FUNCTION TRPFUN(x,ideriv,iu)
c:  Returns ideriv'th deriv. of f(x) using 2-point interp on array on unit iu.
c:  ideriv=0,1,2 returns appropriate *continuous* derivative.
c:  ideriv=11 returns f'(x)/x  ;    ideriv=12 returns  f''(x)/x**2 - f'(x)/x**3
c:  Automatically calls trpin at first occurence of this unit.
c:  Multiple interpolation arrays can be stored, referenced by unit number (iu)
c:  NOTE: currently, no other trpfn_ routine can handle ifhi=2 or iflo=2 cases.
c:  (ifhi=2 means linear extrapolation if x.gt.xn)
c:  (iflo=2 means linear extrapolation if x.lt.x1)
c:
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),dum(80000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      common/trplvl/lvltrp
      common/uflags/iuflag(100)

      if(lvltrp.eq.4) then
        trpfun=trpfn4(x,ideriv,iu)
        return
      else if(lvltrp.eq.3) then
        trpfun=trpfn3(x,ideriv,iu)
        return
      else if(lvltrp.eq.10) then
        trpfun=trpfns(x,ideriv,iu)
        return
      end if
      
      if(npt(iu).le.0) call trpin(iu)
      rm=dxi(iu)*(x-x0(iu))
      m=rm

c
c  ideriv=0 cases
c     
      if(ideriv.gt.0) go to 20
      if(m.ge.npt(iu)) then
        if(ifhi(iu).eq.0) then
          trpfun=0.0d0
        else if(ifhi(iu).eq.1) then
          go to 990
        else if(ifhi(iu).eq.2) then
          mn=npt(iu)+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          trpfun = a(mn) + slope*(x-xn(iu))
        end if
      else if(m.lt.1) then
        if(iflo(iu).eq.0) then
          if(m.eq.0) then
            trpfun = rm*a(1+mark(iu))
          else
            trpfun=0.0d0
          end if
        else if(iflo(iu).eq.1) then
          go to 990
        else if(iflo(iu).eq.2) then
          mn=2+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          trpfun = a(mn) + slope*(x-x0(iu))
        end if
      else
        trpfun =a(m+mark(iu)) +
     x             (rm-float(m))*(a(m+1+mark(iu))-a(m+mark(iu)))
      end if
      return
c
c  ideriv>0 cases
c
   20 mm=mark(iu)+m
      if(m.ge.npt(iu)-1) then
        if(ifhi(iu).eq.0) then
          trpfun=0.0d0
        else if(ifhi(iu).eq.1) then
          go to 990
        else if(ifhi(iu).eq.2) then
          mn=npt(iu)+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          if(ideriv.eq.1) trpfun=slope
          if(ideriv.eq.2) trpfun=0.0d0
          if(ideriv.eq.11) trpfun=slope/x
          if(ideriv.eq.12) trpfun=-slope/x**3
        end if
      else if(m.lt.2) then
        if(iflo(iu).eq.0) then
          trpfun=0.0d0
        else if(iflo(iu).eq.1) then
          go to 990
        else if(iflo(iu).eq.2) then
          mn=2+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          if(ideriv.eq.1) trpfun=slope
          if(ideriv.eq.2) trpfun=0.0d0
          if(ideriv.eq.11) trpfun=slope/x
          if(ideriv.eq.12) trpfun=-slope/x**3
        end if
      else if(ideriv.eq.1) then
        gi=a(mm+1)-a(mm-1)
        gi1=a(mm+2)-a(mm)
        trpfun = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)*0.5d0
      else if(ideriv.eq.2) then
        ci=a(mm-1)+a(mm+1)-2.d0*a(mm)
        ci1=a(mm)+a(mm+2)-2.d0*a(mm+1)
        trpfun = ( ci + (rm-float(m))*(ci1-ci) )*dxi(iu)*dxi(iu)
      else if(ideriv.eq.11) then
        gi=a(mm+1)-a(mm-1)
        gi1=a(mm+2)-a(mm)
        grad = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)*0.5d0
        trpfun = grad/x
      else if(ideriv.eq.12) then
        gi=a(mm+1)-a(mm-1)
        gi1=a(mm+2)-a(mm)
        grad  = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)*0.5d0
        ci=a(mm-1)+a(mm+1)-2.d0*a(mm)
        ci1=a(mm)+a(mm+2)-2.d0*a(mm+1)
        curv = ( ci + (rm-float(m))*(ci1-ci) )*dxi(iu)*dxi(iu)
        trpfun = (curv - grad/x)/(x*x)
      end if
      return
c  
  990 write(6,991) x,iu,x0(iu),xn(iu)
  991 format(/'  abort -  r =',1pd12.4,' passed to trpfun(',i2,');'/
     x     '  this is out of range: start =',1pd10.2,' stop =',1pd10.2)
      stop 'abort - out of range in trpfn'
      end 

      FUNCTION TRPFNS(x,ideriv,iu)
c:  returns f(x) using smooth 4-point interp on array on unit iu
c:
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),fp(40000),fpp(40000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      common/trplvl/lvltrp

      if(npt(iu).le.0) call trpin(iu)
      rm=dxi(iu)*(x-x0(iu))
      m=rm
      m=min(npt(iu),max(0,m))
      q=rm-float(m)
      q2=q*q
      q3=q*q2
      mm=mark(iu)+m
      if(ideriv.eq.0) then
        trpfns=a(mm) + q*fp(mm) + 0.5d0*q2*fpp(mm)
     x           + (fpp(mm+1)-fpp(mm))*(-1.5d0*q3+2.5d0*q2*q2-q2*q3)
      else if(ideriv.eq.1) then
        dydq=           fp(mm) + q*fpp(mm)
     x        + (fpp(mm+1)-fpp(mm))*(-4.5d0*q2+10.0d0*q3-5.0d0*q2*q2)
        trpfns=dydq*dxi(iu)
      else if(ideriv.eq.2) then
        d2ydq2=                  fpp(mm)
     x           + (fpp(mm+1)-fpp(mm))*(-9.0d0*q+30.0d0*q2-20.0d0*q3)
        trpfns=d2ydq2*dxi(iu)**2
      else
        write(6,*) 'trpfns - this ideriv not yet programmed'
      end if

      return
      end



      FUNCTION TRPFN3(x,ideriv,iu)
c:  returns f(x) using 3-point interp on array on unit iu (only ideriv=0).
c:  this is like TRPFUN, except that a more accurate 3-point interp is used
c:
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),dum(80000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      common/trplvl/lvltrp
      common/uflags/iuflag(100)


      if(lvltrp.eq.4) then
        trpfn3=trpfn4(x,ideriv,iu)
        return
      else if(lvltrp.eq.10) then
        trpfun=trpfns(x,ideriv,iu)
        return
      end if

      if(npt(iu).le.0) call trpin(iu)
      rm=dxi(iu)*(x-x0(iu))
      m=rm
cc  for debugging - 12/15/98
c      if(iuflag(81).ge.1) then
c        write(6,*) 'trpfun3 debug write:'
c        write(6,*) '  x,ideriv,iu',x,ideriv,iu
c        write(6,*) '  x0(iu)',x0(iu)
c        write(6,*) '  dxi(iu)',dxi(iu)
c        write(6,*) '  ifhi(iu) =',ifhi(iu)
c        write(6,*) '  iflo(iu) =',iflo(iu)
c        write(6,*) '  m,rm',m,rm
c        write(6,*) '  a(0) =',a(mark(iu)+0)
c        write(6,*) '  a(1) =',a(mark(iu)+1)
c        write(6,*) '  a(2) =',a(mark(iu)+2)
c      end if

      if(ideriv.eq.1 .or. ideriv.eq.11) go to 20
      if(ideriv.gt.0) stop 'abort - this ideriv not allowed in trpfn3'
      if(m.ge.npt(iu)) then
        if(ifhi(iu).eq.0) then
          trpfn3=0.0d0
        else if(ifhi(iu).eq.1) then
          go to 990
        else if(ifhi(iu).eq.2) then
          mn=npt(iu)+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          trpfn3 = a(mn) + slope*(x-xn(iu))
        end if
      else if(m.eq.1) then
c        q=(rm-float(m))
c        am=a(mark(iu)+m-1)
c        a0=a(mark(iu)+m)
c        a1=a(mark(iu)+m+1)
c        trpfn3=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
        if(iflo(iu).eq.0) then
          am=0.0d0           
          a0=a(mark(iu)+1)   
          a1=a(mark(iu)+2)
          q=rm-1.0d0
          trpfn3=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
        else if(iflo(iu).eq.1) then
          am=a(mark(iu)+1)
          a0=a(mark(iu)+2)
          a1=a(mark(iu)+3)
          q=rm-2.0d0
          trpfn3=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
        else if(iflo(iu).eq.2) then
          trpfn3=a(mark(iu)+1)+(rm-1.0d0)*(a(mark(iu)+2)-a(mark(iu)+1))
        end if
      else if(m.eq.0) then
        if(iflo(iu).eq.0) then
          am=0.0d0
          a0=a(mark(iu)+1)
          a1=a(mark(iu)+2)
          q=rm-1.0d0
          trpfn3=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
        else if(iflo(iu).eq.1) then
          go to 990
        else if(iflo(iu).eq.2) then
          trpfn3=a(mark(iu)+1)+(rm-1.0d0)*(a(mark(iu)+2)-a(mark(iu)+1))
        end if
      else if(m.lt.0) then
        if(iflo(iu).eq.0) then
          trpfn3=0.0d0
        else if(iflo(iu).eq.1) then
          go to 990
        else if(iflo(iu).eq.2) then
          trpfn3=a(mark(iu)+1)+(rm-1.0d0)*(a(mark(iu)+2)-a(mark(iu)+1))
        end if
        
ccold      else if(m.lt.2) then
ccold        if(m.eq.1) then
ccold       trpfn3 =a(m+mark(iu)) +
ccold  x             (rm-float(m))*(a(m+1+mark(iu))-a(m+mark(iu)))
ccold     else if(m.eq.0 .and. iflo(iu).eq.0) then
ccold       trpfn3 = rm*a(1+mark(iu))
ccold     else if(iflo(iu).eq.2) then
ccold       mn=2+mark(iu)
ccold       slope=(a(mn)-a(mn-1))*dxi(iu)
ccold       trpfn3 = a(mn) + slope*(x-x0(iu))
ccold     else
ccold       trpfn3=0.0d0
ccold       if(iflo(iu).ne.0) go to 990
ccold    end if

      else
        q=(rm-float(m))
        am=a(mark(iu)+m-1)
        a0=a(mark(iu)+m)
        a1=a(mark(iu)+m+1)
        trpfn3=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
      end if
      return
c
   20 mm=mark(iu)+m
      if(ideriv.eq.2 .or. ideriv.eq.12) stop 'trpfn3: ideriv no good'
      if(m.ge.npt(iu)-1) then
        if(ifhi(iu).eq.0) then
          trpfn3=0.0d0
        else if(ifhi(iu).eq.1) then
          go to 990
        else if(ifhi(iu).eq.2) then
          a0=a(mm)
          a1=a(mm+1)
          slope=(a(mark(iu)+npt(iu))-a(mark(iu)+npt(iu)-1))*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        end if
      else if(m.eq.1) then
        if(iflo(iu).eq.0) then
          ioff=0
cc          am=a(mm-1+ioff)
          am=0.0d0
          a0=a(mm+ioff)
          a1=a(mm+1+ioff)
          a2=a(mm+2+ioff)
          p = rm-float(m+ioff)
          gi=(p+0.5)*a1 - 2.0*p*a0 + (p-0.5)*am
          q=p-1.0d0
          gi1=(q+0.5)*a2 - 2.0*q*a1 + (q-0.5)*a0
          slope = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        else if(iflo(iu).eq.1) then
          ioff=1
          am=a(mm-1+ioff)
          a0=a(mm+ioff)
          a1=a(mm+1+ioff)
          a2=a(mm+2+ioff)
          p = rm-float(m+ioff)
          gi=(p+0.5)*a1 - 2.0*p*a0 + (p-0.5)*am
          q=p-1.0d0
          gi1=(q+0.5)*a2 - 2.0*q*a1 + (q-0.5)*a0
          slope = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        else if(iflo(iu).eq.2) then
          a0=a(mark(iu)+1)
          a1=a(mark(iu)+2)
          slope=(a1-a0)*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        end if
      else if(m.eq.0) then
        if(iflo(iu).eq.0) then
          ioff=1
cc          am=a(mm-1+ioff)
          am=0.0d0
          a0=a(mm+ioff)
          a1=a(mm+1+ioff)
          a2=a(mm+2+ioff)
          p = rm-float(m+ioff) 
          gi=(p+0.5)*a1 - 2.0*p*a0 + (p-0.5)*am
          q=p-1.0d0
          gi1=(q+0.5)*a2 - 2.0*q*a1 + (q-0.5)*a0
          slope = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        else if(iflo(iu).eq.1) then
          go to 990
        else if(iflo(iu).eq.2) then
          a0=a(mark(iu)+1)
          a1=a(mark(iu)+2)
          slope=(a1-a0)*dxi(iu)
          if(ideriv.eq.1) trpfn3=slope
          if(ideriv.eq.11) trpfn3=slope/x
        end if
      else if(ideriv.eq.1) then
        p = rm-float(m)
        gi=(p+0.5)*a(mm+1) - 2.0*p*a(mm) + (p-0.5)*a(mm-1)
        q=p-1.0d0 
        gi1=(q+0.5)*a(mm+2) - 2.0*q*a(mm+1) + (q-0.5)*a(mm)
        slope = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)
        trpfn3=slope
      else if(ideriv.eq.11) then
        p = rm-float(m)
        gi=(p+0.5)*a(mm+1) - 2.0*p*a(mm) + (p-0.5)*a(mm-1)
        q=p-1.0d0
        gi1=(q+0.5)*a(mm+2) - 2.0*q*a(mm+1) + (q-0.5)*a(mm)
        slope = ( gi + (rm-float(m))*(gi1-gi) )*dxi(iu)
        trpfn3=slope/x
      else
        stop 'this ideriv not yet implemented in trpfn3'
      end if
      return
c
  990 write(6,991) x,iu,x0(iu),xn(iu)
  991 format(/'  abort -  r =',1pd12.4,' passed to trpfn3(',i2,');'/
     x     '  this is out of range: start =',1pd10.2,' stop =',1pd10.2)
      stop 'abort - out of range in trpfn'
      end

      FUNCTION TRPFN4(x,ideriv,iu)
c:  returns f(x) using 4-point interp on array on unit iu (only ideriv=0).
c:  this is like TRPFUN, except that a more accurate 4-point interp is used
c:        
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),dum(80000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      if(npt(iu).le.0) call trpin(iu)
      rm=dxi(iu)*(x-x0(iu))
      m=rm
      if(m.ge.npt(iu)) then
        if(ifhi(iu).eq.0) then
          trpfn4=0.0d0
        else if(ifhi(iu).eq.1) then
          go to 990
        else if(ifhi(iu).eq.2) then
          mn=npt(iu)+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          if(ideriv.eq.0) then
            trpfn4 = a(mn) + slope*(x-xn(iu))
          else if(ideriv.eq.1) then
            trpfn4 = slope 
          else if(ideriv.eq.11) then
            trpfn4 = slope/x
          else if(ideriv.eq.2) then
            trpfn4 = 0.0d0 
          else if(ideriv.eq.12) then
            trpfn4 = 0.0d0
          end if
        end if
      else if(m.lt.2) then
        if(m.eq.1) then
          trpfn4 =a(m+mark(iu)) +
     x             (rm-float(m))*(a(m+1+mark(iu))-a(m+mark(iu)))
        else if(m.eq.0 .and. iflo(iu).eq.0) then
          trpfn4 = rm*a(1+mark(iu))
        else if(iflo(iu).eq.2) then
          mn=2+mark(iu)
          slope=(a(mn)-a(mn-1))*dxi(iu)
          if(ideriv.eq.0) then
            trpfn4 = a(mn) + slope*(x-x0(iu))
          else if(ideriv.eq.1) then
            trpfn4 = slope
          else if(ideriv.eq.11) then
            trpfn4 = slope/x
          else if(ideriv.eq.2) then
            trpfn4 = 0.0d0
          else if(ideriv.eq.12) then
            trpfn4 = 0.0d0
          end if
        else
          trpfn4=0.0d0
          if(iflo(iu).ne.0) go to 990
        end if
      else
        q=(rm-float(m))
        am=a(mark(iu)+m-1)
        a0=a(mark(iu)+m)
        a1=a(mark(iu)+m+1)
        a2=a(mark(iu)+m+2)
        if(m.eq.npt(iu)-1) then
c         3 pt interp
          if(ideriv.gt.0) stop 'trpfn4 abort -some ideriv>0 dont work'
          trpfn4=a0 + 0.5d0*q*( (a1+am-a0-a0)*q + (a1-am) )
        else
c         4 pt interp
          if(ideriv.eq.0) then
            trpfn4 = (-q*(q-1.0d0)*(q-2.0d0)*am
     x              +(q**2-1.0d0)*(q-2.0d0)*a0*3.0d0
     x              -q*(q+1.0d0)*(q-2.0d0)*a1*3.0d0
     x              +q*(q**2-1.0d0)*a2  )/6.0d0
          else if(ideriv.eq.1) then
            q3 = 3.0d0*q**2
            trpfn4 = (-(q3 - 6.0d0*q + 2.0d0)*am
     x                +(q3 - 4.0d0*q -1.0d0)*a0*3.0d0
     x                -(q3 - 2.0d0*q -2.0d0)*a1*3.0d0
     x                +(q3 - 1.0d0)*a2  )*dxi(iu)/6.0d0
          else if(ideriv.eq.11) then
            q3 = 3.0d0*q**2
            slope = (-(q3 - 6.0d0*q + 2.0d0)*am
     x                +(q3 - 4.0d0*q -1.0d0)*a0*3.0d0
     x                -(q3 - 2.0d0*q -2.0d0)*a1*3.0d0
     x                +(q3 - 1.0d0)*a2  )*dxi(iu)/6.0d0
            trpfn4 = slope/x
          else if(ideriv.eq.2) then
            q6 = 6.0d0*q
            trpfn4 = ( -(q6 - 6.0d0)*am
     x                +(q6 - 4.0d0)*a0*3.0d0
     x                -(q6 - 2.0d0)*a1*3.0d0
     x                +q6*a2  )*dxi(iu)**2/6.0d0
          else if(ideriv.eq.12) then
            q3 = 3.0d0*q**2
            slope = (-(q3 - 6.0d0*q + 2.0d0)*am
     x                +(q3 - 4.0d0*q -1.0d0)*a0*3.0d0
     x                -(q3 - 2.0d0*q -2.0d0)*a1*3.0d0
     x                +(q3 - 1.0d0)*a2  )*dxi(iu)/6.0d0
            q6 = 6.0d0*q
            curv = ( -(q6 - 6.0d0)*am
     x                +(q6 - 4.0d0)*a0*3.0d0
     x                -(q6 - 2.0d0)*a1*3.0d0
     x                +q6*a2  )*dxi(iu)**2/6.0d0
            trpfn4 = (curv - slope/x)/x**2
          end if
        end if
      
        
      end if
      return
        
        
  990 write(6,991) x,iu,x0(iu),xn(iu)
  991 format(/'  abort -  r =',1pd12.4,' passed to trpfn4(',i2,');'/
     x     '  this is out of range: start =',1pd10.2,' stop =',1pd10.2)
      stop 'abort - out of range in trpfn'
      end

      subroutine TRPIN(iu)
ci:  Internal routine. Reads an interpolation array from .trp file
ci:  and stores it in memory, with appropriate pointers so that the
ci:  other TRP routines can access it.
ci:  Called automatically by trpfun at first occurence of this unit.
ci:  Multiple trp arrays can be read in, referenced by unit number.
ci:  Storage is completely independent of the trp-generating routines,
ci:  since they write directly to disk, without storing internally.
ci:
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),fp(40000),fpp(40000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      common/trpcom/mute
c stmt funcs:
c  e.g.,  pslope(i,j)=slope, at point j, of parabola through
c                                     points i,i+1,i+2 in array a
      pval(i,j)=(a(i+2)+a(i)-2.0d0*a(i+1))*float(j-i-1)**2/2.0d0
     x                  + 0.5d0*(a(i+2)-a(i))*float(j-i-1) + a(i+1)
      pslope(i,j)=(a(i+2)+a(i)-2.0d0*a(i+1))*float(j-i-1)
     x                  + 0.5d0*(a(i+2)-a(i))
      pcurv(i)=(a(i+2)+a(i)-2.0d0*a(i+1))

      if(mark(iu).ne.0) stop 'abort - tried to read in trp twice'
      rewind iu
      read(iu) n,x0(iu),xn(iu),dxi(iu),iflo(iu),ifhi(iu)
      if(n+last.gt.40000) stop 'abort - redimension in trpin'
      npt(iu)=n
      mark(iu)=last+1
      last=last+n+1
                last=last+1
      m=mark(iu)
      read(iu) (a(i),i=m+1,m+n)
      rewind iu

c  note points put in a() array off each end of interp array - see trpvec
      a(m)=0.0d0
      a(m+n+1)=0.0d0
      if(ifhi(iu).eq.2) a(m+n+1) = a(m+n) + a(m+n)-a(m+n-1)
c  this following stmt may be slightly wrong - see trpvec
      if(iflo(iu).eq.2) a(m) = a(m+1) + a(m+1)-a(m+2)

      x1=x0(iu)+1.0d0/dxi(iu)

c  setup for newer trpfns routine - smooth, differentiable interp

c fill fp,fpp
      do  10 ii=2,npt(iu)-1
      i=mark(iu)+ii
      fp(i)=(a(i+1)-a(i-1))/2.0d0
      fpp(i)=a(i+1)+a(i-1)-2.0d0*a(i)
   10 continue

      mrk=mark(iu)
c low end
      if(iflo(iu).eq.0) then
        a(mrk)=0.0d0
        fp(mrk)=pslope(mrk+0,mrk+0)
        fpp(mrk)=pcurv(mrk+0)
        fp(mrk+1)=(a(mrk+2)-a(mrk+0))/2.0d0
        fpp(mrk+1)=(a(mrk+2)+a(mrk+0)-2.0d0*a(mrk+1))
      else if(iflo(iu).eq.1) then
        a(mrk)=1.d50         
        fp(mrk)=0.0d0
        fpp(mrk)=0.0d0
        fp(mrk+1)=pslope(mrk+1,mrk+1)
        fpp(mrk+1)=pcurv(mrk+1)
      else if(iflo(iu).eq.2) then
        fp(mrk+1)=pslope(mrk+1,mrk+1)
        fpp(mrk+1)=pcurv(mrk+1)
        a(mrk)=a(mrk+1)-1.0d0*fp(mrk+1)
        fp(mrk)=fp(mrk+1)
      end if
c high end
      nn=mark(iu)+npt(iu)
      if(ifhi(iu).eq.0) then
        a(nn)=0.0d0
        fp(nn)=0.0d0
        fpp(nn)=0.0d0
        fpp(nn+1)=0.0d0
      else if(ifhi(iu).eq.1) then
        a(nn)=1.d60
        fp(nn)=0.0d0
        fpp(nn)=0.0d0
        fpp(nn+1)=0.0d0
      else if(ifhi(iu).eq.2) then
        fp(nn)=pslope(nn-2,nn)
        fpp(nn)=0.0d0
        fpp(nn+1)=0.0d0 
      end if
      
c      if(mute.eq.0) write(6,50) iu,n,iflo(iu),ifhi(iu),x0(iu),xn(iu),
c     x                                   x1,a(m+1),xn(iu),a(m+n)
c   50 format(' trp in: unit=',i2,' npt=',i5,' iflo=',i2,' ifhi=',i2,
c     x                                 '  x0,xn:',1p2d12.4/
c     x       '         x1,y1,xn,yn:',1p4d10.2)
      return
      end 
      


      SUBROUTINE TRPDAT(iu,npoint,xx0,xx1,xxn,yy1,yyn,ifxlo,ifxhi)
c:  this routine can be called by user to get specs on this trp functi0n
c:  xx1 is the smallest usable x value; yy1 = trpfun(iu;xx1;0)
c:  (x can be smaller than xx1 if iflo=0)
c:  xxn = end of range (x must be <xxn unless iflo=0); ynn=trpfun(ynn)
c:
      implicit real*8(a-h,o-z)
      common/holdtr/ a(40000),dum(80000)
      common/umarkt/ npt(99),mark(99),x0(99),xn(99),dxi(99),
     x                       mark1(99),mark2(99),
     x                       iflo(99),ifhi(99),last
      if(npt(iu).le.0) call trpin(iu)
      npoint=npt(iu)
      xx0=x0(iu)
      xx1=x0(iu) + 1.0d0/dxi(iu)
      xxn=xn(iu)             
      yy1=a(mark(iu)+1)      
      yyn=a(mark(iu)+npoint)
      ifxlo=iflo(iu)
      ifxhi=ifhi(iu)
      return
      end
     





