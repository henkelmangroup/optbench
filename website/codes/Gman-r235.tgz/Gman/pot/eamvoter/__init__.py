__doc__ = '''EAM potential from Art Voter.'''

from eamvoter import force, init, A0, Mass
