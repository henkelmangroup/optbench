__doc__ = '''LEPS+HO potential'''

from lepspho import force
