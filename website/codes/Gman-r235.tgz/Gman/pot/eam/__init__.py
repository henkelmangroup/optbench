__doc__ = '''EAM potential from Hannes, of the Voter-Chen form.'''

from eam import force, set, init
