c   version e93:   add gregs SPF routine for chain relaxation
c   EAM version b91:   add FPI forces and potential by calling FPIforce                   
c                                                                                         
C     THIS SUBROUTINE COMPUTES THE FORCES by calling GAGAFE for each type of              
c     interaction.                                                                        

      SUBROUTINE POTINIT()

      implicit real*8 (a-h,o-z)

      include 'commonblks/parameters.cmn'
      include 'commonblks/combaths.cmn'
      include 'commonblks/comgeom.cmn'
      include 'commonblks/comconf.cmn'
      include 'commonblks/comenergy.cmn'
      include 'commonblks/comenperat.cmn'
      include 'commonblks/compotent.cmn'
      include 'commonblks/comluns.cmn'
      include 'commonblks/comintlis.cmn'

      common /unscale/RALOCAL(MAXCOO)

c     -----------------------------------------------------------------------
c     This routine interprets the parameters in the array potpar(i,ipot).                 
c     The association is as follows:                                                      
c            potpar(1,..)  gtrans -  parameter for g transformation                       
c            potpar(2,..)  preexpA -   prexponential # 1 in pair pot.                     
c            potpar(3,..)  alphaA -   decaylength # 1 in pair pot.                        
c            potpar(4,..)  preexpB -   prexponential # 2 in pair pot.                     
c            potpar(5,..)  alphaB -   decaylength # 2 in pair pot.                        
c            potpar(6,..)  scale - scaling parameter for the density                      
c            potpar(7,..)  betaA -  decay length # 1 in the density                       
c            potpar(8,..)  betaB -  decay length # 2 in the density                       
c            potpar(9,..)  eta  -  the power of r in the                                  
c                                   density function (6 in Voter)                         
c            potpar(10,..)  gamma - multiplies the second term in the density             
c                                   (512 in Voter)                                        
c            potpar(11,..) f1 - coeff. of first order term in F(rho)                      
c                                                NB: rho not scaled.                      
c            potpar(12,..) f2 - coeff. of second order term in F(rho)                     
c               ...           ..                   ..                                     
c               ...           ..                   ..                                     
c              etc.                                                                       

c  Phi:                                                                 
c               phi = preexpA * exp(-alphaA*r) + preexpB * exp(-alphaB*r)                 

c  Rho:        rho = scale * (r**eta * (exp(-betaA*r) + gamma * exp(-betaB*r)))
c  I am using Voter's rho=r**6*(exp(-beta*r)+512*exp(-2*beta*r))

c-------------------------------------------------------------------------------          
c     Defining the parameters in potpar manually (for Mg and Pd only)
c     initflag=1 forces the code to construct neigbor list etc.
c     mxipot is the maxium number of pair types (3 for 2 components)
c     isame tells the code that this pair is between the same type of atoms
c     iorder is the order of polynomials used to fit the F(rho) function.
c        note: the polynomial series start from io=1, not zero.
c     indf1 points to the potpar(indf1, ipot) which is the first polynomial
c     coefficient
c     we set IQKMIN=.flase. and nFPI=0 to simply the functionings fo the codes.
      initflag=1
      mxipot=6
      ISAME=0
      indf1=11
c      iorderf=6 
      iorderf=8
c      NATYPE=2
      NATYPE=3
      nncount=0

      alpha=90
      beta=90
      gamma=90

      IQKMIN=.false.
      nFPI=0

c      Type1 Parameters (e.g., N1 Mg atoms)
      rcut(1)=5.4120
      rcut2(1)=rcut(1)**2
      rskin(1)=5.6120
      rskin2(1)=rskin(1)**2

      potpar(1,1)=0.
      potpar(2,1)=2375.42135
      potpar(3,1)=3.090 
      potpar(4,1)=-125.491407
      potpar(5,1)=1.5450       
      potpar(6,1)=1.0          
      potpar(7,1)=3.3470
      potpar(8,1)=6.6940       
      potpar(9,1)=6.0
      potpar(10,1)=512.0       
      potpar(11,1)=5.9253      
      potpar(12,1)=-4.20638    
      potpar(13,1)=23.59708    
      potpar(14,1)=-24.09457    
      potpar(15,1)=12.39549    
      potpar(16,1)=-3.55043    
      potpar(17,1)=0.53904     
      potpar(18,1)=-0.03385    

c  Type2 Parameters (e.g., N2 O atoms)
      rcut(2)=5.4120
      rcut2(2)=rcut(2)**2
      rskin(2)=5.6120
      rskin2(2)=rskin(2)**2

      potpar(1,2)=0.
      potpar(2,2)=2375.42135
      potpar(3,2)=3.090
      potpar(4,2)=-125.491407
      potpar(5,2)=1.5450       
      potpar(6,2)=1.0          
      potpar(7,2)=3.3470
      potpar(8,2)=6.6940       
      potpar(9,2)=6.0
      potpar(10,2)=512.0       
      potpar(11,2)=5.9253      
      potpar(12,2)=-4.20638    
      potpar(13,2)=23.59708    
      potpar(14,2)=-24.09457    
      potpar(15,2)=12.39549    
      potpar(16,2)=-3.55043    
      potpar(17,2)=0.53904     
      potpar(18,2)=-0.03385    

c     rcut(2)=5.0
c     rcut2(2)=rcut(2)**2
c     rskin(2)=5.2
c     rskin2(2)=rskin(2)**2
c
c     potpar(1,2)=0.
c     potpar(2,2)=3058.900936
c     potpar(3,2)=2.90413658
c     potpar(4,2)=-85.35807181
c     potpar(5,2)=1.45206829
c     potpar(6,2)=1.0          
c     potpar(7,2)=3.3470
c     potpar(8,2)=6.6940       
c     potpar(9,2)=6.0
c     potpar(10,2)=512.0       
c     potpar(11,2)=0.0      
c     potpar(12,2)=0.0    
c     potpar(13,2)=0.0    
c     potpar(14,2)=0.0    
c     potpar(15,2)=0.0    
c     potpar(16,2)=0.0    
c     potpar(17,2)=0.0     
c     potpar(18,2)=0.0    

c      Type3 Parameters (e.g., N3 Pd atoms)

      rcut(3)=5.4120
      rcut2(3)=rcut(3)**2
      rskin(3)=5.6120
      rskin2(3)=rskin(3)**2

      potpar(1,3)=0.
      potpar(2,3)=2375.42135
      potpar(3,3)=3.090
      potpar(4,3)=-125.491407
      potpar(5,3)=1.5450       
      potpar(6,3)=1.0          
      potpar(7,3)=3.3470
      potpar(8,3)=6.6940       
      potpar(9,3)=6.0
      potpar(10,3)=512.0       
      potpar(11,3)=5.9253      
      potpar(12,3)=-4.20638    
      potpar(13,3)=23.59708    
      potpar(14,3)=-24.09457    
      potpar(15,3)=12.39549    
      potpar(16,3)=-3.55043    
      potpar(17,3)=0.53904     
      potpar(18,3)=-0.03385    

c     (mixed) Type "4" Parameters (e.g., N1-N2 or MgO pairs)
c     note: atoms in mixed pair contributes to the total denisty but 
c     No embedded potential F(rho) for mised pairs like Mg-O

      rcut(4)=5.4120
      rcut2(4)=rcut(4)**2
      rskin(4)=5.6120
      rskin2(4)=rskin(4)**2

      potpar(1,4)=0.
      potpar(2,4)=2375.42135
      potpar(3,4)=3.090
      potpar(4,4)=-125.491407
      potpar(5,4)=1.5450       
      potpar(6,4)=1.0          
      potpar(7,4)=3.3470
      potpar(8,4)=6.6940       
      potpar(9,4)=6.0
      potpar(10,4)=512.0       
      potpar(11,4)=5.9253      
      potpar(12,4)=-4.20638    
      potpar(13,4)=23.59708    
      potpar(14,4)=-24.09457    
      potpar(15,4)=12.39549    
      potpar(16,4)=-3.55043    
      potpar(17,4)=0.53904     
      potpar(18,4)=-0.03385    

c     (mixed) Type "5" Parameters (e.g., N1-N3 or MgPd pairs)

      rcut(5)=5.4120
      rcut2(5)=rcut(5)**2
      rskin(5)=5.6120
      rskin2(5)=rskin(5)**2

      potpar(1,5)=0.
      potpar(2,5)=2375.42135
      potpar(3,5)=3.090
      potpar(4,5)=-125.491407
      potpar(5,5)=1.5450       
      potpar(6,5)=1.0          
      potpar(7,5)=3.3470
      potpar(8,5)=6.6940       
      potpar(9,5)=6.0
      potpar(10,5)=512.0       
      potpar(11,5)=5.9253      
      potpar(12,5)=-4.20638    
      potpar(13,5)=23.59708    
      potpar(14,5)=-24.09457    
      potpar(15,5)=12.39549    
      potpar(16,5)=-3.55043    
      potpar(17,5)=0.53904     
      potpar(18,5)=-0.03385    

c     (mixed) Type "6" Parameters (e.g., N2-N3 or OPd pairs)

      rcut(6)=5.4120
      rcut2(6)=rcut(6)**2
      rskin(6)=5.6120
      rskin2(6)=rskin(6)**2

      potpar(1,6)=0.
      potpar(2,6)=2375.42135
      potpar(3,6)=3.090
      potpar(4,6)=-125.491407
      potpar(5,6)=1.5450       
      potpar(6,6)=1.0          
      potpar(7,6)=3.3470
      potpar(8,6)=6.6940       
      potpar(9,6)=6.0
      potpar(10,6)=512.0       
      potpar(11,6)=5.9253      
      potpar(12,6)=-4.20638    
      potpar(13,6)=23.59708    
      potpar(14,6)=-24.09457    
      potpar(15,6)=12.39549    
      potpar(16,6)=-3.55043    
      potpar(17,6)=0.53904     
      potpar(18,6)=-0.03385    

      RETURN
      END
