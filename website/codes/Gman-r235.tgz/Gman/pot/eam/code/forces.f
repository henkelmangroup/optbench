c   version Austin/0: Lijun extended the num of atom types from two to three
c   version e93:   add gregs SPF routine for chain relaxation
c   EAM version b91:   add FPI forces and potential by calling FPIforce                   
c                                                                                         
C     THIS SUBROUTINE COMPUTES THE FORCES by calling GAGAFE for each type of              
c     interaction.                                                                        

c      SUBROUTINE FORCE(N1,N2, R,F,U,BX,BY,BZ)
      SUBROUTINE FORCE(N1,N2, N3, R,F,U,BX,BY,BZ)

      implicit real*8 (a-h,o-z)

      include 'commonblks/parameters.cmn'
      include 'commonblks/combaths.cmn'
      include 'commonblks/comgeom.cmn'
      include 'commonblks/comconf.cmn'
      include 'commonblks/comenergy.cmn'
      include 'commonblks/comenperat.cmn'
      include 'commonblks/compotent.cmn'
      include 'commonblks/comluns.cmn'
      include 'commonblks/comintlis.cmn'

      common /unscale/RALOCAL(MAXCOO)

      dimension R(MAXCOO),F(MAXCOO),Rxyz(3),Rij(3)

      AX=BX
      AY=BY
      AZ=BZ

      Rxyz(1)=AX
      Rxyz(2)=AY
      Rxyz(3)=AZ

c      NATYPE=2
      NATYPE=3
c      NATOMS=N1+N2
      NATOMS=N1+N2+N3
      NATMS(1)=N1 
      NATMS(2)=N2
C added
      NATMS(3)=N3

c      write(*,*)'N1 ',N1,' N2 ',N2
      write(*,*)'N1 ',N1,' N2 ',N2, 'N3 ', N3
c     ==============================================
c      Starting from below is same as the 2-type code
c     ==============================================
c      write(*,*)'initflag ',initflag
c      if(initflag.eq.1.or.NATOMS.le.2) then
      if(initflag.eq.1) then
cg         write(*,*)'Skip nn check'
         initflag=2
         indupd=1
      else
cg         write(*,*)'Into nearest check'
         do I=1,NATOMS
            J=3*(I-1)
            Rij(1)=Rold(J+1)-R(J+1)
            Rij(2)=Rold(J+2)-R(J+2)
            Rij(3)=Rold(J+3)-R(J+3)
c            write(*,*) Rij(1),Rij(2),Rij(3)
c            write(*,*)
            Rij(1)=Rij(1)/Rxyz(1)
            Rij(2)=Rij(2)/Rxyz(2)
            Rij(3)=Rij(3)/Rxyz(3)
            R1=1.0
            Rij(1)=mod(Rij(1)+1000.5,R1)-0.5
            Rij(2)=mod(Rij(2)+1000.5,R1)-0.5
            Rij(3)=mod(Rij(3)+1000.5,R1)-0.5
            Rij(1)=Rij(1)*Rxyz(1)
            Rij(2)=Rij(2)*Rxyz(2)
            Rij(3)=Rij(3)*Rxyz(3)
c            write(*,*) Rij(1),Rij(2),Rij(3)
c            write(*,*)
            dR=0
            dR=dR+Rij(1)*Rij(1)
            dR=dR+Rij(2)*Rij(2)
            dR=dR+Rij(3)*Rij(3)
            dR=sqrt(dR)
            if(I.eq.1) then
               dR1=dR
            elseif(I.eq.2) then
               if(dR1.gt.dR) then
                  dR2=dR
               else
                  dR2=dR1;
                  dR1=dR;
               endif
            else
               if(dR1.lt.dR) then
                  dR2=dR1
                  dR1=dR
               elseif(dR2.lt.dR) then
                  dR2=dR
               endif
            endif
         enddo
         if((dR1+dR2).gt.(rskin(1)-rcut(1))) then
cg            write(*,*)'Updating NN List'
            indupd=1
         else
            indupd=0
         endif
      endif

c      indupd=1

      if(indupd.eq.1) then
c         nncount=nncount+1
c            write(*,*) 'NNUpdate: ',nncount
         do I=1,3*NATOMS
            Rold(I)=R(I)
         enddo
      endif

cg      write(*,*)'After nnlist'

      DO I=1,3*NATOMS
         FA(I)=0.
         RALOCAL(I)=R(I)
      enddo

      do i=1,natoms
         Potenpat(i)=0.
      enddo

C  INTERACTIONS BETWEEN ATOMS OF TYPE 'ITYPE' WITH THEMSELVES:                            
      ITPTR=1
      DO 200 ITYPE=1,NATYPE
            iatshift1=(ITPTR-1)/3
            iatshift2=iatshift1
            CALL GAGAFE(NATMS(ITYPE),RALOCAL(ITPTR),FA(ITPTR),
     X            NATMS(ITYPE),RALOCAL(ITPTR),FA(ITPTR),
     X            utotITYPE,virialITYPE,
     X            ITYPE,1)
          UT(ITYPE*(ITYPE+1)/2)=utotITYPE
          virial(ITYPE*(ITYPE+1)/2)=virialITYPE
        ITPTR=ITPTR+3*NATMS(ITYPE)
200     CONTINUE
C                                                                                         
C  INTERACTIONS BETWEEN ATOMS OF TYPE ITYPE AND JTYPE:                                    
C                                                                                         
      IF(NATYPE.LE.1) GO TO 500
      IPOT=NATYPE
      JTPTR=3*NATMS(1)+1
c  =====================================================
c  Starting from below is different from the 2-type code
c  =====================================================
      DO 400 JTYPE=2,NATYPE
        ITPTR=1
        DO 300 ITYPE=1,JTYPE-1
          IPOT=IPOT+1
          iatshift1=(ITPTR-1)/3
          iatshift2=(JTPTR-1)/3
c          write(*, *) 'IPOT=', IPOT
          CALL GAGAFE(NATMS(ITYPE),RALOCAL(ITPTR),FA(ITPTR),
     X            NATMS(JTYPE),RALOCAL(JTPTR),FA(JTPTR),
     X            utotITYPE,virialITYPE,
     X            IPOT,0)
          UT(ITYPE+JTYPE*(JTYPE-1)/2)=utotITYPE
          virial(ITYPE+JTYPE*(JTYPE-1)/2)=virialITYPE
          ITPTR=ITPTR+3*NATMS(ITYPE)
300       CONTINUE
        JTPTR=JTPTR+3*NATMS(JTYPE)
400     CONTINUE

500   CONTINUE

      UTOT=0.
      DO 600 I=1,NATYPE*(NATYPE+1)/2
c       write(*, *) 'UT(', I, ')=', UT(I)
        UTOT=UTOT+UT(I)
600   continue
      
      totpair=utot
      CALL EMBED(FRHOTOT,embvir)
      UTOT = UTOT + FRHOTOT
      do i=1,3*NATOMS
         F(i)=FA(i)
c      write(*, *) 'F(', i, ')= ', F(i)
      end do
      U=UTOT
      
      RETURN
      END
