__doc__ = '''EAM potential for Al from Hannes.'''

from al import init, force
