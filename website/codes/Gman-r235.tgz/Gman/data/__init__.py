__doc__ = '''Gman data point structure.'''
__all__ = ["data"]
from data import *
