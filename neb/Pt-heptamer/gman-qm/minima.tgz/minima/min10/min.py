#!/usr/bin/env python

from Gman import *

p=data.point()

io.loadcon(p,'a.con')
force=pot.set('morse')
opt.cgmin(p,force,fmax=1e-12)
io.savecon(p,'a.con')

io.loadcon(p,'b.con')
opt.cgmin(p,force,fmax=1e-12)
io.savecon(p,'b.con')
